package admissions.common.vo;

import admissions.common.file.vo.CommonFileVo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DataDefaultVo {
    Integer pageNo = 1;
    Integer countPerPage = 15;
    Integer totalCount = 0;
    Integer rowNo = 0;
    private String firstRegistDate = "";
    private String firstRegistUserId = "ROLE_ANONYMOUS";
    private String firstRegistUserIp = "";
    private String firstRegistProgramId = "Unknown";
    private String lastUpdateDate = "";
    private String lastUpdateUserId = "ROLE_ANONYMOUS";
    private String lastUpdateUserIp = "";
    private String lastUpdateProgramId = "Unknown";
    private List<String> checkedList = new ArrayList<String>();

    public List<String> getCheckedList() {
        return Collections.unmodifiableList(checkedList);
    }

    public void setCheckedList(List<String> checkedList) {
        this.checkedList = Collections.unmodifiableList(checkedList);
    }

    List<CommonFileVo> fileList = new ArrayList<CommonFileVo>();

    public List<CommonFileVo> getFileList() {
        return Collections.unmodifiableList(fileList);
    }

    public void setFileList(List<CommonFileVo> fileList) {
        this.fileList = Collections.unmodifiableList(fileList);
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getStartNo() {
        Integer startNo = (pageNo - 1) * countPerPage;
        if (startNo < 0) {
            startNo = 0;
        }
        return startNo;
    }

    public Integer getCountPerPage() {
        return countPerPage;
    }

    public void setCountPerPage(Integer countPerPage) {
        this.countPerPage = countPerPage;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public String getFirstRegistDate() {
        return firstRegistDate;
    }

    public void setFirstRegistDate(String firstRegistDate) {
        this.firstRegistDate = firstRegistDate;
    }

    public String getFirstRegistUserId() {
        return firstRegistUserId;
    }

    public void setFirstRegistUserId(String firstRegistUserId) {
        this.firstRegistUserId = firstRegistUserId;
    }

    public String getFirstRegistUserIp() {
        return firstRegistUserIp;
    }

    public void setFirstRegistUserIp(String firstRegistUserIp) {
        this.firstRegistUserIp = firstRegistUserIp;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getLastUpdateUserId() {
        return lastUpdateUserId;
    }

    public void setLastUpdateUserId(String lastUpdateUserId) {
        this.lastUpdateUserId = lastUpdateUserId;
    }

    public String getLastUpdateUserIp() {
        return lastUpdateUserIp;
    }

    public void setLastUpdateUserIp(String lastUpdateUserIp) {
        this.lastUpdateUserIp = lastUpdateUserIp;
    }

    public String getFirstRegistProgramId() {
        return firstRegistProgramId;
    }

    public void setFirstRegistProgramId(String firstRegistProgramId) {
        this.firstRegistProgramId = firstRegistProgramId;
    }

    public String getLastUpdateProgramId() {
        return lastUpdateProgramId;
    }

    public void setLastUpdateProgramId(String lastUpdateProgramId) {
        this.lastUpdateProgramId = lastUpdateProgramId;
    }

    public Integer getRowNo() {
        return rowNo;
    }

    public void setRowNo(Integer rowNo) {
        this.rowNo = rowNo;
    }
}
