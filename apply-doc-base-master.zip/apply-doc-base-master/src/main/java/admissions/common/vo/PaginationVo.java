package admissions.common.vo;

import java.util.List;

public class PaginationVo
{
	Integer from = 0;
	Integer lastPage = 0;
	Integer perPage = 15;
	Integer currentPage = 0;
	Integer to = 0;
	Integer total = 0;
	
	public void setList(List<?> list, Integer perPage)
	{
		this.perPage = perPage;
		if(!list.isEmpty())
		{
			DataDefaultVo args = (DataDefaultVo) list.get(0);
			total = args.getTotalCount();

			to = (int) Math.round((float) total / (float) perPage + 0.5);
			lastPage = to;
			from = 1;
		}
	}
	
	public Integer getFrom()
	{
		return from;
	}
	public void setFrom(Integer from)
	{
		this.from = from;
	}
	public Integer getLastPage()
	{
		return lastPage;
	}
	public void setLastPage(Integer lastPage)
	{
		this.lastPage = lastPage;
	}
	public Integer getPerPage()
	{
		return perPage;
	}
	public void setPerPage(Integer perPage)
	{
		this.perPage = perPage;
	}
	public Integer getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public Integer getTo()
	{
		return to;
	}
	public void setTo(Integer to)
	{
		this.to = to;
	}
	public Integer getTotal()
	{
		return total;
	}
	public void setTotal(Integer total)
	{
		this.total = total;
	}
}
