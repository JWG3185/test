package admissions.common.mail;

import admissions.common.dao.CommonDao;
import admissions.common.mail.vo.ComTransferEmailReceiverVo;
import admissions.common.mail.vo.ComTransferEmailVo;
import admissions.common.mail.vo.DispatchVo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@Component
public class MailService
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MailService.class);
	
//	@Autowired
//	private JavaMailSender javaMailSender;

    @Autowired
    private SpringTemplateEngine templateEngine;
    
    @Autowired
    private CommonDao commonDao;

    @Value("${ncloud.access-key-id}")
    private String accessKey;
    @Value("${ncloud.secret-key}")
    private String secretKey;
	@Value("${createMailRequest.url}")
	private String createMailRequestUrl;


    /**
     * 네이버 mailer api를 이용한 메일 전송
     */
    @SuppressWarnings("unchecked")
	public void sendEmail(String pkEmailSending) {
        LOGGER.debug("send email start..........");

        //발신 정보 가져옴
		ComTransferEmailVo dispatchVo = (ComTransferEmailVo) commonDao.selectOne("MailMapper.selectDispatchInfo", pkEmailSending);
        //수신 목록
        List<ComTransferEmailReceiverVo> recipientList = (List<ComTransferEmailReceiverVo>) commonDao.selectList("MailMapper.selectRecipientList", pkEmailSending);

		//수신 목록을 API 데이터에 맞게 변경

        //메일 전송
        OutputStreamWriter writer = null;

		try {
			//signature 생성
			String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()).getTime());
			String signature = makeSignature(timestamp);

			//body에 담을 데이터
			JSONObject data = new JSONObject();
			data.put("senderAddress", dispatchVo.getSenderEmailAddress());
			data.put("title", dispatchVo.getEmailTitle());
			data.put("individual", ("N".equals(dispatchVo.getMultimailYn()) ? "true" : "false"));
			data.put("advertising", "false");

			for (ComTransferEmailReceiverVo vo : recipientList) {
				JSONObject recipient = new JSONObject();
				JSONArray recipientJson = new JSONArray();
				recipient.put("address", vo.getReceiverEmailAddress());
				recipient.put("name", vo.getReceiverNm());
				recipient.put("type", vo.getReceiveTypeCd());
				recipientJson.put(recipient);

				data.put("recipients", recipientJson);
				data.put("body", dispatchVo.getEmailContents());

				//createMailRequest
//				URL url = new URL("https://mail.apigw.gov-ntruss.com/api/v1/mails");
				URL url = new URL(createMailRequestUrl);

				HttpsURLConnection huc = (HttpsURLConnection) url.openConnection();
				huc.setRequestMethod("POST");
				huc.setRequestProperty("Content-Type", "application/json");
				huc.setRequestProperty("Accept", "application/json");
				huc.setRequestProperty("x-ncp-apigw-timestamp", timestamp);
				huc.setRequestProperty("x-ncp-iam-access-key", accessKey);
				huc.setRequestProperty("x-ncp-apigw-signature-v2", signature);
				huc.setDoOutput(true);
				huc.setDoInput(true);
				huc.setUseCaches(false);
				huc.setConnectTimeout(2000);
				huc.setReadTimeout(2000);

				writer = new OutputStreamWriter(huc.getOutputStream(), StandardCharsets.UTF_8);
				writer.write(data.toString());
				writer.flush();

				//response
				if (huc.getResponseCode() == HttpsURLConnection.HTTP_CREATED) {
					//발송 성공
					try(BufferedReader br = new BufferedReader(new InputStreamReader(huc.getInputStream(), StandardCharsets.UTF_8)))
					{
						StringBuffer sb = new StringBuffer();
						while(true)
						{
							String line =  br.readLine();
							if(line == null)
							{
								break;
							}
							sb.append(line);
						}

						String jsonString = sb.toString();

						ObjectMapper om = new ObjectMapper();
						Map<String, String> paramMap = om.readValue(jsonString, Map.class);
						paramMap.put("pkEmlSndng", pkEmailSending);

						commonDao.update("MailMapper.updateDispatchResult", paramMap);
					}

				} else {
					//발송 실패
					if (LOGGER.isErrorEnabled()) {
						LOGGER.error(""+huc.getResponseCode());
						LOGGER.error(""+huc.getContent());
						LOGGER.error("send email fail");
					}
				}
			}


		} catch (IOException | JSONException | InvalidKeyException | NoSuchAlgorithmException e) {
			if (LOGGER.isErrorEnabled()) {
				LOGGER.error("send email error: {}", e.getMessage().replaceAll("[\r\n]",""));
			}

		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {

					if (LOGGER.isErrorEnabled()) {
						LOGGER.error(e.getMessage().replaceAll("[\r\n]",""));
					}
				}
			}
		}

        LOGGER.debug("send email end..........");
    }

    /**
     * signature 생성 메서드
     * @return secret key를 암호화 한 String
     * @throws Exception
     */
    private String makeSignature(String timestamp) throws IOException, InvalidKeyException, NoSuchAlgorithmException {
        String space = " ";  // 공백
        String newLine = "\n";  // 줄바꿈
        String method = "POST";  // HTTP 메소드
        String url = "/api/v1/mails";  // 도메인을 제외한 "/" 아래 전체 url (쿼리스트링 포함)

        String message = new StringBuffer()
                .append(method)
                .append(space)
                .append(url)
                .append(newLine)
                .append(timestamp)
                .append(newLine)
                .append(accessKey)
                .toString();

        SecretKeySpec signingKey = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(signingKey);

        byte[] rawHmac = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(rawHmac);
    }
    
    private String replace(String content, ComTransferEmailReceiverVo vo)
	{
    	return content.replace("\n", "<br/>").replace("[이름]", vo.getReceiverNm());
    }
	  
	  /**
	   * 메일 정보를 insert 한다
	   * @param comtransferEmailVo 메일 정보(발신정보, 수신목록)
	   * @param templateName 템플릿(thymeleaf) 파일명
	   * @return
	   */
	  @Transactional
	  public int insertMailInfo(ComTransferEmailVo comtransferEmailVo, String templateName) {
		  
		  	// 컨텐츠맵, 템플릿명이 비어있지 않다면 컨텐츠 생성/세팅 (템플릿엔진)
		  	if(!comtransferEmailVo.getContentMap().isEmpty() && StringUtils.isNotEmpty(templateName)) {
		  		//템플릿에 전달할 데이터 설정
		  		Context context = new Context();
		  		comtransferEmailVo.getContentMap().forEach((key, value)->{
		  			context.setVariable(key, value);
		  		});

		  		String emlContent = templateEngine.process(templateName, context).replaceAll("\n", "");

				comtransferEmailVo.setEmailContents(emlContent);
		  	}
			  
			commonDao.insert("MailMapper.insertDispatch", comtransferEmailVo);
			commonDao.update("MailMapper.insertRecipientList", comtransferEmailVo);
			
			return comtransferEmailVo.getEmailTransferNo();
	  }
	  // 오버로딩
	  @Transactional
	  public int insertMailInfo(DispatchVo dispatchVo) {
			
			commonDao.insert("MailMapper.insertDispatch", dispatchVo);
			commonDao.update("MailMapper.insertRecipientList", dispatchVo);
			
			return dispatchVo.getPkEmlSndng();
	  }
}