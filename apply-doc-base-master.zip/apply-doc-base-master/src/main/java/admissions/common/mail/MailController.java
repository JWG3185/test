package admissions.common.mail;

import admissions.common.mail.vo.DispatchVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.io.IOException;

@Controller
@RequestMapping("/common/mail")
public class MailController {

	@Autowired
	MailService service;

	@PostMapping("/insertMailInfo.do")
	public ModelAndView insertMailInfo(@RequestBody DispatchVo formVo) throws IOException {
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

		service.insertMailInfo(formVo);

		return model;

	}

	@PostMapping("/sendMail.do")
	public ModelAndView fileList(@RequestBody DispatchVo formVo) throws IOException {
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

		int pkEmailSending = service.insertMailInfo(formVo);
		service.sendEmail(Integer.toString(pkEmailSending));

		return model;

	}
}