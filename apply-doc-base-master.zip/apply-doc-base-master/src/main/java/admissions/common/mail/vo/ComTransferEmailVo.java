package admissions.common.mail.vo;

import admissions.common.vo.DataDefaultVo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ComTransferEmailVo extends DataDefaultVo{
    int emailTransferNo = 0;
    String senderEmailAddress = "";
    String senderNm = "";
    String emailTitle = "";
    String emailContents = "";
    String multimailYn = "";
    String receiverCnt = "";
    String sendReserveDate = "";
    String sendYn = "";
    String sendDate = "";
    String sendRequestId = "";

    Map<String, String> contentMap = new ConcurrentHashMap<String, String>();
    List<ComTransferEmailReceiverVo> recipientList = new ArrayList<ComTransferEmailReceiverVo>();

    public List<ComTransferEmailReceiverVo> getRecipientList() {
        return Collections.unmodifiableList(recipientList);
    }

    public void setRecipientList(List<ComTransferEmailReceiverVo> recipientList) {
        this.recipientList = Collections.unmodifiableList(recipientList);
    }

    public Map<String, String> getContentMap() {
        return Collections.unmodifiableMap(contentMap);
    }

    public void setContentMap(Map<String, String> contentMap) {
        this.contentMap = Collections.unmodifiableMap(contentMap);
    }

    public int getEmailTransferNo() {
        return emailTransferNo;
    }
    public void setEmailTransferNo(int emailTransferNo) {
        this.emailTransferNo = emailTransferNo;
    }

    public String getSenderEmailAddress() {
        return senderEmailAddress;
    }
    public void setSenderEmailAddress(String senderEmailAddress) {
        this.senderEmailAddress = senderEmailAddress;
    }

    public String getSenderNm() {
        return senderNm;
    }
    public void setSenderNm(String senderNm) {
        this.senderNm = senderNm;
    }

    public String getEmailTitle() {
        return emailTitle;
    }
    public void setEmailTitle(String emailTitle) {
        this.emailTitle = emailTitle;
    }

    public String getEmailContents() {
        return emailContents;
    }
    public void setEmailContents(String emailContents) {
        this.emailContents = emailContents;
    }

    public String getMultimailYn() {
        return multimailYn;
    }
    public void setMultimailYn(String multimailYn) {
        this.multimailYn = multimailYn;
    }

    public String getReceiverCnt() {
        return receiverCnt;
    }
    public void setReceiverCnt(String receiverCnt) {
        this.receiverCnt = receiverCnt;
    }

    public String getSendReserveDate() {
        return sendReserveDate;
    }
    public void setSendReserveDate(String sendReserveDate) {
        this.sendReserveDate = sendReserveDate;
    }

    public String getSendYn() {
        return sendYn;
    }
    public void setSendYn(String sendYn) {
        this.sendYn = sendYn;
    }

    public String getSendDate() {
        return sendDate;
    }
    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }

    public String getSendRequestId() {
        return sendRequestId;
    }
    public void setSendRequestId(String sendRequestId) {
        this.sendRequestId = sendRequestId;
    }
}
