package admissions.common.mail;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.IExpressionContext;
import org.thymeleaf.context.IWebContext;
import org.thymeleaf.linkbuilder.StandardLinkBuilder;

import java.util.Map;

@Component
public class CustomLinkBuilder extends StandardLinkBuilder {
	
		@Value("${server.servlet.context-path}")
		private String contextPath;

	  @Override
	  protected String computeContextPath(
	      final IExpressionContext context, final String base, final Map<String, Object> parameters) {

	    if (context instanceof IWebContext) {
	      return super.computeContextPath(context, base, parameters);
	    }

	    return "http://192.168.1.224:8200"; //assuming css and images are here

	  }
	  
	}
