package admissions.common.mail.vo;

import admissions.common.vo.DataDefaultVo;

public class ComTransferEmailReceiverVo extends DataDefaultVo{
    String emailTransferNo = "";
    String receiverNo = "";
    String receiverEmailAddress = "";
    String receiverNm = "";
    String receiveTypeCd = "";

    public String getEmailTransferNo() {
        return emailTransferNo;
    }
    public void setEmailTransferNo(String emailTransferNo) {
        this.emailTransferNo = emailTransferNo;
    }

    public String getReceiverNo() {
        return receiverNo;
    }
    public void setReceiverNo(String receiverNo) {
        this.receiverNo = receiverNo;
    }

    public String getReceiverEmailAddress() {
        return receiverEmailAddress;
    }
    public void setReceiverEmailAddress(String receiverEmailAddress) {
        this.receiverEmailAddress = receiverEmailAddress;
    }

    public String getReceiverNm() {
        return receiverNm;
    }
    public void setReceiverNm(String receiverNm) {
        this.receiverNm = receiverNm;
    }

    public String getReceiveTypeCd() {
        return receiveTypeCd;
    }
    public void setReceiveTypeCd(String receiveTypeCd) {
        this.receiveTypeCd = receiveTypeCd;
    }
}
