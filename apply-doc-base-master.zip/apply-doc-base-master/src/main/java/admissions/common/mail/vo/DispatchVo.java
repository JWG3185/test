package admissions.common.mail.vo;

import admissions.common.vo.DataDefaultVo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DispatchVo extends DataDefaultVo{
    private int pkEmlSndng;
    private String emlTitle;
    private String emlContent;
    private String dsptchEmlAddr;
    private String dsptchUserNm;
    private String groupEmlYn;
    private String reservation;
    private String userId = "";
    private String dsptchReservation = "";

    Map<String, String> contentMap = new ConcurrentHashMap<String, String>();
    List<RecipientVo> recipientList = new ArrayList<RecipientVo>();
    
	public String getDsptchReservation() {
		return dsptchReservation;
	}

	public void setDsptchReservation(String dsptchReservation) {
		this.dsptchReservation = dsptchReservation;
	}

	public String getReservation() {
		return reservation;
	}

	public void setReservation(String reservation) {
		this.reservation = reservation;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

    public Map<String, String> getContentMap() {
        return Collections.unmodifiableMap(contentMap);
    }

    public void setContentMap(Map<String, String> contentMap) {
        this.contentMap = Collections.unmodifiableMap(contentMap);
    }

    public List<RecipientVo> getRecipientList() {
		return Collections.unmodifiableList(recipientList);
	}

	public void setRecipientList(List<RecipientVo> recipientList) {
		this.recipientList = Collections.unmodifiableList(recipientList);
	}

	public int getPkEmlSndng() {
        return pkEmlSndng;
    }

    public void setPkEmlSndng(int pkEmlSndng) {
        this.pkEmlSndng = pkEmlSndng;
    }

    public String getEmlTitle() {
        return emlTitle;
    }

    public void setEmlTitle(String emlTitle) {
        this.emlTitle = emlTitle;
    }

    public String getEmlContent() {
        return emlContent;
    }

    public void setEmlContent(String emlContent) {
        this.emlContent = emlContent;
    }

    public String getDsptchEmlAddr() {
        return dsptchEmlAddr;
    }

    public void setDsptchEmlAddr(String dsptchEmlAddr) {
        this.dsptchEmlAddr = dsptchEmlAddr;
    }

    public String getDsptchUserNm() {
        return dsptchUserNm;
    }

    public void setDsptchUserNm(String dsptchUserNm) {
        this.dsptchUserNm = dsptchUserNm;
    }

    public String getGroupEmlYn() {
        return groupEmlYn;
    }

    public void setGroupEmlYn(String groupEmlYn) {
        this.groupEmlYn = groupEmlYn;
    }
}
