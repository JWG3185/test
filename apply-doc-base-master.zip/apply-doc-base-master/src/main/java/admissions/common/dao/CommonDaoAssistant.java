package admissions.common.dao;

import admissions.common.auth.vo.AuthVo;
import admissions.common.vo.DataDefaultVo;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

@Component
public class CommonDaoAssistant
{
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonDaoAssistant.class);

	private Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

	public String getUserId()
	{
		String userId = "ANONYMOUS";

//		LOGGER.debug(authentication.getPrincipal().toString());

		if (authentication != null && authentication.getPrincipal() instanceof AuthVo)
		{
			userId = ((AuthVo) authentication.getPrincipal()).getUserId();
		}

		if(authentication != null && "ANONYMOUS".equals(userId))
		{
			userId = ((WebAuthenticationDetails) authentication.getDetails()).getSessionId();
		}

		return userId;
	}

	public static String getUserIp()
	{
		String remoteIp;
		HttpServletRequest req = null;

		ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		if(servletRequestAttributes != null)
		{
			req = servletRequestAttributes.getRequest();
		}
		
		if(req != null)
		{
			remoteIp = req.getHeader("x-forwarded-for");
			if (StringUtils.isNotEmpty(remoteIp) && remoteIp.contains(",")) {
				remoteIp = req.getHeader("x-forwarded-for").split(",")[0];
			}

			if (StringUtils.isEmpty(remoteIp)) {
				remoteIp = req.getHeader("x-real-ip");
			}

			if (StringUtils.isEmpty(remoteIp)) {
				remoteIp = req.getRemoteAddr();
			}

//			if (StringUtils.isEmpty(remoteIp)) {
//				remoteIp = ((WebAuthenticationDetails) authentication.getDetails()).getRemoteAddress();
//			}


			byte[] lpb = InetAddress.getLoopbackAddress().getAddress();
			StringBuffer sb = new StringBuffer();
			for (int idx = 0; idx < lpb.length; idx++) {
				if (idx > 0) {
					sb.append('.');
				}
				sb.append(lpb[idx] & 0xFF);
			}
			String lpa = sb.toString();

			try {
				if (lpa.equals(remoteIp)) {
					Enumeration<NetworkInterface> niEnum = NetworkInterface.getNetworkInterfaces();
					while (niEnum.hasMoreElements()) {
						NetworkInterface ni = niEnum.nextElement();
						if (ni.isUp() && ni.getDisplayName().indexOf("Loopback") < 0 && ni.getDisplayName().indexOf("Virtual") < 0 && ni.getDisplayName().indexOf("TAP") < 0) {
							Enumeration<InetAddress> iaEnum = ni.getInetAddresses();

							while (iaEnum.hasMoreElements()) {
								InetAddress inetAddress = iaEnum.nextElement();

								if (inetAddress.getHostAddress().indexOf(":") >= 0 || inetAddress.getHostAddress().equals(lpa)) {
									continue;
								}

								if (remoteIp.compareTo(inetAddress.getHostAddress()) < 0) {
									remoteIp = inetAddress.getHostAddress();
								}
							}
						}
					}
				}
			} catch (SocketException e) {
				if (LOGGER.isErrorEnabled()) {
					LOGGER.error(e.getMessage().replaceAll("[\r\n]", ""));
				}
			}
		}
		else
		{
			remoteIp = "0.0.0.0";
		}


		return remoteIp;
	}

	public static Object copyProperties(Object vo)
	{
		CommonDaoAssistant commonDaoAssistant = new CommonDaoAssistant();
		if (vo instanceof DataDefaultVo)
		{
			((DataDefaultVo) vo).setFirstRegistUserId(commonDaoAssistant.getUserId());
			((DataDefaultVo) vo).setFirstRegistUserIp(commonDaoAssistant.getUserIp());
			((DataDefaultVo) vo).setLastUpdateUserId(commonDaoAssistant.getUserId());
			((DataDefaultVo) vo).setLastUpdateUserIp(commonDaoAssistant.getUserIp());
		}

		return vo;
	}
}