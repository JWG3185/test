package admissions.common.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("commonDao")
public class CommonDao
{
	@Autowired
	protected SqlSessionTemplate sqlSession;

	public Object selectOne(String queryId)
	{
		return sqlSession.selectOne(queryId);
	}

	public Object selectOne(String queryId, Object parameterObject)
	{
		return sqlSession.selectOne(queryId, CommonDaoAssistant.copyProperties(parameterObject));
	}

	public List<?> selectList(String queryId, Object parameterObject)
	{
		return sqlSession.selectList(queryId, CommonDaoAssistant.copyProperties(parameterObject));
	}

	public List<?> selectList(String queryId)
	{
		return sqlSession.selectList(queryId);
	}

	public Object insert(String queryId, Object parameterObject)
	{
		return sqlSession.insert(queryId, CommonDaoAssistant.copyProperties(parameterObject));
	}

	public int update(String queryId, Object parameterObject)
	{
		return sqlSession.update(queryId, CommonDaoAssistant.copyProperties(parameterObject));
	}

	public int update(String queryId)
	{
		return sqlSession.update(queryId);
	}

	public int delete(String queryId, Object parameterObject)
	{
		return sqlSession.delete(queryId, CommonDaoAssistant.copyProperties(parameterObject));
	}
}
