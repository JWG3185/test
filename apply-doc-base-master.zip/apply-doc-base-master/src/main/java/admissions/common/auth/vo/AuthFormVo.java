package admissions.common.auth.vo;

public class AuthFormVo
{
	private String userId = "";
	private String userPassword = "";
	private String loginType = "USER";
	private String normalId = "";
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	public String getNormalId() {	return normalId;	}
	public void setNormalId(String normalId) {	this.normalId = normalId;	}
}
