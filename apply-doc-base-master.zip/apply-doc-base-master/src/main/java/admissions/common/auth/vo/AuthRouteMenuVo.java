package admissions.common.auth.vo;

public class AuthRouteMenuVo
{
	private String menuLinkAddress = "";
	private String vueComponentName = "";

	public String getMenuLinkAddress() {
		return menuLinkAddress;
	}

	public void setMenuLinkAddress(String menuLinkAddress) {
		this.menuLinkAddress = menuLinkAddress;
	}

	public String getVueComponentName() {
		return vueComponentName;
	}

	public void setVueComponentName(String vueComponentName) {
		this.vueComponentName = vueComponentName;
	}
}
