package admissions.common.auth;

import admissions.common.auth.vo.AuthLogVo;
import admissions.common.dao.CommonDaoAssistant;
import admissions.system.user.UserService;
import admissions.system.user.vo.UserFormVo;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import java.io.IOException;
import java.util.Enumeration;

public class OAuthLoginFailureHandler implements AuthenticationFailureHandler
{
    private static final Logger LOGGER = LoggerFactory.getLogger(OAuthLoginFailureHandler.class);

    String socialConnectUrl;

    UserService userService;

    AuthService authService;

    String systemDivisionCode;

    public OAuthLoginFailureHandler(String socialConnectUrl, UserService userService, AuthService authService, String systemDivisionCode) {
        this.socialConnectUrl = socialConnectUrl;
        this.userService = userService;
        this.authService = authService;
        this.systemDivisionCode = systemDivisionCode;
    }

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException authenticationException) throws IOException{

        LOGGER.debug("OAuthLoginFailureHandler.onAuthorizationFailure()");

        //TODO. 수정 필요
        String redirectUrl = socialConnectUrl + "/user/login";
//        String redirectUrl = "http://localhost:18000" + "/user/login";
//        String redirectUrl = "https://kdi-applydoc.osolit.net" + "/user/login";

        LOGGER.debug("OAuthLoginFailureHandler.redirectUrl : " + redirectUrl);

        String message = authenticationException.getMessage();
        String loginId = "";

        if(LOGGER.isDebugEnabled())
        {
            LOGGER.debug("loginFailureHandler : {}", message.replaceAll("[\r\n]",""));
        }

        if(message.contains("kakao connect"))
        {
            String username = message.replace(" kakao connect", "");
            loginId = username;
            redirectUrl += "?kakaoConnect=" + username;

            // 가입되지 않은 소셜 메일주소 메일인증처리
            // 소셜로그인 가입시 쿼리파라미터 조작방지 (가입완료시 재확인 위함)
            UserFormVo formVo = new UserFormVo();
            formVo.setEmailAddress(username);
            formVo.setLastUpdateProgramId("SocialLogin");
            formVo.setEmailCertCd(userService.insertValidEmailAddress(formVo));
            userService.validEmailAddressText(formVo);
        }
        else if (message.contains("google connect"))
        {
            String username = message.replace(" google connect", "");
            loginId = username;
            redirectUrl += "?googleConnect=" + username;

            // 가입되지 않은 소셜 메일주소 메일인증처리
            // 소셜로그인 가입시 쿼리파라미터 조작방지 (가입완료시 재확인 위함)
            UserFormVo formVo = new UserFormVo();
            formVo.setEmailAddress(username);
            formVo.setLastUpdateProgramId("SocialLogin");
            formVo.setEmailCertCd(userService.insertValidEmailAddress(formVo));
            userService.validEmailAddressText(formVo);
        }
        else if(message.contains("naver connect"))
        {
            // 네이버 소셜로그인 처리
            String naverConnect = message.replace(" naver connect", ""); // userId
            loginId = "naverSocialJoin";
            redirectUrl += "?naverConnect=" + naverConnect; // 쿼리파라미터로 소셜 메일주소 가입화면 이동
        }

        //로그생성
        AuthLogVo logVo = new AuthLogVo();
        logVo.setLoginId(loginId);
        logVo.setLoginIp(CommonDaoAssistant.getUserIp());
        logVo.setLoginYn("N");
        logVo.setLoginResult(message);
        logVo.setLoginHeader(getLoginHeader(request));
        logVo.setSystemDivisionCode(systemDivisionCode);
        authService.insertLoginLog(logVo);

        response.sendRedirect(redirectUrl);
    }

    private String getLoginHeader(HttpServletRequest request)
    {
        StringBuffer headers = new StringBuffer();

        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String name = headerNames.nextElement();
            String value = request.getHeader(name);
            headers.append(name).append(": ").append(value).append("\r\n");
        }

        return headers.toString();
    }

}