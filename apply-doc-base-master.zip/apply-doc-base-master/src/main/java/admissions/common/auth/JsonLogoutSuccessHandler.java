package admissions.common.auth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Component
public class JsonLogoutSuccessHandler implements LogoutSuccessHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(JsonLogoutSuccessHandler.class);

    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException
    {
        LOGGER.debug("logoutSuccessHandler");

        String message = "success";

        JSONObject basicResponse = new JSONObject();
        try
        {
            basicResponse.put("timestamp", new Date().getTime());
            basicResponse.put("status", HttpStatus.OK.value());
            basicResponse.put("message", message);
            basicResponse.put("path", request.getRequestURI());
        }
        catch(JSONException e)
        {
            if(LOGGER.isErrorEnabled())
            {
                LOGGER.error(e.getMessage().replaceAll("[\r\n]",""));
            }
        }

        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType("application/json");
        response.setStatus(HttpStatus.OK.value());
        response.getWriter().write(basicResponse.toString());
    }
}
