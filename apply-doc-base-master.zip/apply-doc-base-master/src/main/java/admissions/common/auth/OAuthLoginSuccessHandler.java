package admissions.common.auth;

import admissions.common.auth.vo.AuthLogVo;
import admissions.common.auth.vo.AuthVo;
import admissions.common.dao.CommonDaoAssistant;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import java.io.IOException;
import java.util.Enumeration;

public class OAuthLoginSuccessHandler implements AuthenticationSuccessHandler
{
    private static final Logger LOGGER = LoggerFactory.getLogger(OAuthLoginSuccessHandler.class);

    String socialConnectUrl;

    AuthService authService;

    String systemDivisionCode;

    public OAuthLoginSuccessHandler(String socialConnectUrl, AuthService authService, String systemDivisionCode) {
        this.socialConnectUrl = socialConnectUrl;
        this.authService = authService;
        this.systemDivisionCode = systemDivisionCode;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException
    {
        LOGGER.debug("OAuthLoginSuccessHandler.onOAuthAuthenticationSuccess()");

        AuthVo authVo = new AuthVo();
        BeanUtils.copyProperties(authentication.getPrincipal(), authVo);

        String loginId = authVo.getUserId();
        String loginResult = authentication.getAuthorities().toString();

        //로그생성
        AuthLogVo logVo = new AuthLogVo();
        logVo.setLoginId(loginId);
        logVo.setLoginIp(CommonDaoAssistant.getUserIp());
        logVo.setLoginYn("Y");
        logVo.setLoginResult(loginResult);
        logVo.setLoginHeader(getLoginHeader(request));
        logVo.setSystemDivisionCode(systemDivisionCode);
        authService.insertLoginLog(logVo);

        //TODO. 수정 필요
        String redirectUrl = socialConnectUrl + "/user/login";
//        String redirectUrl = "http://localhost:18000" + "/user/login";
//        String redirectUrl = "https://kdi-applydoc.osolit.net" + "/user/login";

        LOGGER.debug("OAuthLoginSuccessHandler.redirectUrl : " + redirectUrl);

        // 세션타임 늘려주는 쿼리파라미터 필요

        response.sendRedirect(redirectUrl);
    }

    private String getLoginHeader(HttpServletRequest request)
    {
        StringBuffer headers = new StringBuffer();

        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String name = headerNames.nextElement();
            String value = request.getHeader(name);
            headers.append(name).append(": ").append(value).append("\r\n");
        }

        return headers.toString();
    }
}
