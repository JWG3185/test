package admissions.common.auth.vo;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.core.user.OAuth2User;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class AuthVo implements UserDetails, OAuth2User
{
	static final long serialVersionUID = 1L;

	private String userId = "";
	private String userPassword = "";
	private String originalId = "";
	private String userNm = "";
	private String engFirstNm = "";
	private String engMiddleNm = "";
	private String engFamilyNm = "";
	private String birthDt = "";
	private String roleName = "";
	private String remoteAddr = "";
	private String exUserYn = "";
	@SuppressWarnings(value = "PMD.AvoidFieldNameMatchingMethodName")
	boolean isAccountNonExpired = false;
	@SuppressWarnings(value = "PMD.AvoidFieldNameMatchingMethodName")
	boolean isAccountNonLocked = false;
	@SuppressWarnings(value = "PMD.AvoidFieldNameMatchingMethodName")
	boolean isCredentialsNonExpired = false;
	Collection<? extends GrantedAuthority> authorities;

	public String getExUserYn() {
		return exUserYn;
	}

	public void setExUserYn(String exUserYn) {
		this.exUserYn = exUserYn;
	}

	public String getOriginalId() {
		return originalId;
	}

	public void setOriginalId(String originalId) {
		this.originalId = originalId;
	}

	public String getRemoteAddr() {
		return remoteAddr;
	}

	public void setRemoteAddr(String remoteAddr) {
		this.remoteAddr = remoteAddr;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleName()
	{
		StringBuffer roleBuffer = new StringBuffer();
		if(authorities != null)
		{
			for(GrantedAuthority authority : authorities)
			{
				if(roleBuffer.length() > 0)
				{
					roleBuffer.append(';');
				}
				roleBuffer.append(authority.getAuthority());
			}
		}
		this.roleName = roleBuffer.toString();
		return roleName;
	}

	public void setRoleCd(String roleName)
	{
		this.roleName = roleName;
	}

	@Override
	public String toString() {
		return "AuthInfoVo [userId=" + userId + ", userPassword=" + userPassword + ", userNm=" + userNm + ", roleName="
				+ roleName + ", isAccountNonExpired=" + isAccountNonExpired + ", isAccountNonLocked="
				+ isAccountNonLocked + ", isCredentialsNonExpired=" + isCredentialsNonExpired + ", authorities="
				+ authorities + "]";
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities()
	{
		return Collections.unmodifiableCollection(authorities);
	}

	public void setAuthorities(List<GrantedAuthority> authorities)
	{
		this.authorities = Collections.unmodifiableList(authorities);
	}

	@Override
	public String getPassword()
	{
		return userPassword;
	}

	@Override
	public String getUsername()
	{
		return userId;
	}

	@Override
	public boolean isAccountNonExpired()
	{
		return isAccountNonExpired;
	}

	@Override
	public boolean isAccountNonLocked()
	{
		return isAccountNonLocked;
	}

	@Override
	public boolean isCredentialsNonExpired()
	{
		return isCredentialsNonExpired;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	public void setAccountNonExpired(boolean isAccountNonExpired)
	{
		this.isAccountNonExpired = isAccountNonExpired;
	}

	public void setAccountNonLocked(boolean isAccountNonLocked)
	{
		this.isAccountNonLocked = isAccountNonLocked;
	}

	public void setCredentialsNonExpired(boolean isCredentialsNonExpired)
	{
		this.isCredentialsNonExpired = isCredentialsNonExpired;
	}

	@Override
	public String getName() {
		return null;
	}

	@Override
	public Map<String, Object> getAttributes() {
		return null;
	}

	public String getEngFirstNm() {
		return engFirstNm;
	}

	public void setEngFirstNm(String engFirstNm) {
		this.engFirstNm = engFirstNm;
	}

	public String getEngMiddleNm() {
		return engMiddleNm;
	}

	public void setEngMiddleNm(String engMiddleNm) {
		this.engMiddleNm = engMiddleNm;
	}

	public String getEngFamilyNm() {
		return engFamilyNm;
	}

	public void setEngFamilyNm(String engFamilyNm) {
		this.engFamilyNm = engFamilyNm;
	}

	public String getBirthDt() {
		return birthDt;
	}

	public void setBirthDt(String birthDt) {
		this.birthDt = birthDt;
	}
}
