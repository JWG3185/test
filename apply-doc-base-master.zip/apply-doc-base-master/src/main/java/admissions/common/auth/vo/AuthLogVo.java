package admissions.common.auth.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthLogVo
{
	String loginLogNo = "";
	String loginId = "";
	String loginIp = "";
	String loginYn = "";
	String loginResult = "";
	String loginHeader = "";

	String systemDivisionCode = "";

	public String getLoginHeader() {
		return loginHeader;
	}

	public void setLoginHeader(String loginHeader) {
		this.loginHeader = loginHeader;
	}

	public String getLoginLogNo() {
		return loginLogNo;
	}

	public void setLoginLogNo(String loginLogNo) {
		this.loginLogNo = loginLogNo;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getLoginIp() {
		return loginIp;
	}

	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}

	public String getLoginYn() {
		return loginYn;
	}

	public void setLoginYn(String loginYn) {
		this.loginYn = loginYn;
	}

	public String getLoginResult() {
		return loginResult;
	}

	public void setLoginResult(String loginResult) {
		this.loginResult = loginResult;
	}

	public String getSystemDivisionCode() { return systemDivisionCode; }

	public void setSystemDivisionCode(String systemDivisionCode) { this.systemDivisionCode = systemDivisionCode; }
}
