package admissions.common.auth;

import admissions.common.auth.vo.AuthButtonVo;
import admissions.common.auth.vo.AuthLogVo;
import admissions.common.auth.vo.AuthVo;
import admissions.common.auth.vo.PathVo;
import admissions.common.dao.CommonDao;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;


@Service
@RequiredArgsConstructor
public class AuthService implements UserDetailsService
{
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthService.class);

	private CommonDao commonDao;

	private String alg = "AES/CBC/PKCS5Padding";

	@Value("${aes.key}")
	private String aesKey;

	@Autowired
	public AuthService(CommonDao commonDao) {
		this.commonDao = commonDao;
	}

	/**
	 * 로그인
	 * 
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
	{
		LOGGER.debug("AuthService.loadUserByUsername(" + username.replaceAll("[\r\n]","") + ")");

		AuthVo authVo = (AuthVo) commonDao.selectOne("AuthMapper.select", username);

		if(authVo == null)
		{
			throw new UsernameNotFoundException( username + " There is no information corresponding to the ID or password you entered.");
		}

		List<GrantedAuthority> authorities = getAuthorities(username);

		if(authorities.size() < 1)
		{
			throw new UsernameNotFoundException( username + "You do not have permission assigned to your ID.");
		}

		authVo.setAuthorities(authorities);

		authVo.setAccountNonExpired(true);
		authVo.setCredentialsNonExpired(true);
		authVo.setAccountNonLocked(true);

		LOGGER.debug(authVo.toString().replaceAll("[\r\n]",""));

		return authVo;
	}

	public List<GrantedAuthority> getAuthorities(String username)
	{
		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority("ROLE_APPLICANT"));
		return authorities;
	}

	/**
	 * get Path from database
	 */
	@SuppressWarnings("unchecked")
	public List<PathVo> selectAuthRouteMenuList(AuthVo authVo)
	{
		return (List<PathVo>) commonDao.selectList("AuthMapper.selectAuthRouteMenuList", authVo);
	}

	/**
	 * button List
	 */
	public AuthButtonVo selectButtonList(AuthButtonVo authButtonVO)
	{
		return (AuthButtonVo) commonDao.selectOne("AuthMapper.selectButtonList", authButtonVO);
	}

	/**
	 * 로그인 로그 저장
	 */
	public void insertLoginLog(AuthLogVo logVo)
	{
		commonDao.insert("AuthMapper.insertLoginLog", logVo);
	}

	/**
	 * BlockingIp Check
	 */
	public boolean checkBlockingIp(String ip)
	{
		boolean result = false;
		Integer cnt = (Integer) commonDao.selectOne("AuthMapper.checkBlockingIp", ip);

		if(LOGGER.isDebugEnabled())
		{
			LOGGER.debug("cnt:" + cnt);
		}

		if(cnt > 0)
		{
			result = true;
		}

		return result;
	}

	public String checkEmailValid(String username) {
		return (String) commonDao.selectOne("AuthMapper.selectEmailValid", username);
	}

	public String encryptAES256(String text) throws Exception {
		String iv = aesKey.substring(0, 16);
		Cipher cipher = Cipher.getInstance(alg);
		SecretKeySpec keySpec = new SecretKeySpec(aesKey.getBytes("UTF-8"), "AES");
		IvParameterSpec ivParamSpec = new IvParameterSpec(iv.getBytes("UTF-8"));
		cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivParamSpec);

		byte[] encrypted = cipher.doFinal(text.getBytes("UTF-8"));
		return Base64.getEncoder().encodeToString(encrypted);
	}
}
