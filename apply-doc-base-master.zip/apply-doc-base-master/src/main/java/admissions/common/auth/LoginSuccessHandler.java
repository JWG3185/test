package admissions.common.auth;

import admissions.common.auth.vo.AuthLogVo;
import admissions.common.auth.vo.AuthVo;
import admissions.common.dao.CommonDaoAssistant;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Enumeration;

public class LoginSuccessHandler implements AuthenticationSuccessHandler
{
    private static final Logger LOGGER = LoggerFactory.getLogger(LoginSuccessHandler.class);

    AuthService authService;

    String systemDivisionCode;

    public LoginSuccessHandler(AuthService authService, String systemDivisionCode)
    {
        this.authService = authService;
        this.systemDivisionCode = systemDivisionCode;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException
    {
        LOGGER.debug("onAuthenticationSuccess");
        LOGGER.debug("systemDivisionCode : " + systemDivisionCode);

        if(request.getHeader("accept").contains("application/json"))
        {
            // json
            JSONObject jsonObject = new JSONObject();
            try
            {
                String clientIp = CommonDaoAssistant.getUserIp();
                String loginResult = authentication.getAuthorities().toString();

                AuthVo authVo = null;
                String username = "";
                if (authentication != null && authentication.getPrincipal() instanceof AuthVo)
                {
                    authVo = (AuthVo) authentication.getPrincipal();
                    username = authVo.getUserId();
                }

//                String originalId =  (String) ((UsernamePasswordAuthenticationToken) authentication).getPrincipal();
//                if(originalId != null && !originalId.equals(""))
//                {
//                    loginResult = "[SuperUser: " + originalId + "]" + loginResult;
//                }

                //로그생성
                AuthLogVo logVo = new AuthLogVo();
                logVo.setLoginId(username);
                logVo.setLoginIp(clientIp);
                logVo.setLoginYn("Y");
                logVo.setLoginResult(loginResult);
                logVo.setLoginHeader(getLoginHeader(request));
                logVo.setSystemDivisionCode(systemDivisionCode);
                authService.insertLoginLog(logVo);


                StringBuffer roleCdBuffer = new StringBuffer();
                for(GrantedAuthority roleCd : authentication.getAuthorities())
                {
                    if(roleCdBuffer.length() > 0)
                    {
                        roleCdBuffer.append(';');
                    }

                    roleCdBuffer.append(roleCd.getAuthority());
                }

                if(authVo != null)
                {
                    jsonObject.put("userId", authVo.getUserId());
                    jsonObject.put("userName", authVo.getUserNm());
                    jsonObject.put("roleCd", roleCdBuffer.toString());
                }

                jsonObject.put("sessionId", request.getSession().getId());
                jsonObject.put("remoteAddr", clientIp);
                jsonObject.put("sessionCreationTime", request.getSession().getCreationTime());
                jsonObject.put("sessionLastAccessedTime", request.getSession().getLastAccessedTime());
                jsonObject.put("sessionMaxInactiveInterval", request.getSession().getMaxInactiveInterval());

                JSONObject basicResponse = new JSONObject();
                basicResponse.put("timestamp", new Date().getTime());
                basicResponse.put("status", HttpStatus.OK.value());
                basicResponse.put("message", jsonObject);
                basicResponse.put("path", request.getRequestURI());
                basicResponse.put("sessionId", request.getSession().getId());

                response.setCharacterEncoding(StandardCharsets.UTF_8.name());
                response.setContentType("application/json");
                response.setStatus(HttpStatus.OK.value());
                response.getWriter().write(basicResponse.toString());
            }
            catch(JSONException e)
            {
                if(LOGGER.isErrorEnabled())
                {
                    LOGGER.error(e.getMessage().replaceAll("[\r\n]",""));
                }
            }
        }
        else{
            response.sendRedirect("/common/auth/info.do");
        }
    }

    private String getLoginHeader(HttpServletRequest request)
    {
        StringBuffer headers = new StringBuffer();

        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String name = headerNames.nextElement();
            String value = request.getHeader(name);
            headers.append(name).append(": ").append(value).append("\r\n");
        }

        return headers.toString();
    }
}
