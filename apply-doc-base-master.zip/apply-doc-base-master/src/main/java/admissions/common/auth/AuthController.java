package admissions.common.auth;

import admissions.common.auth.vo.AuthButtonVo;
import admissions.common.auth.vo.AuthVo;
import admissions.common.dao.CommonDaoAssistant;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.ui.Model;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@RequestMapping("/common/auth")
public class AuthController
{
	final AuthService authService;

	@Value("${server.servlet.session.timeout}")
	private int sessionTime;

	@Value("${proxy.url}")
	private String proxyUrl;

	@Value("${clipreport.url}")
	private String clipreportUrl;

	private String alg = "AES/CBC/PKCS5Padding";
	@Value("${aes.key}")
	private String aesKey;

	public AuthController(AuthService authService) {
		this.authService = authService;
	}


	/**
	 * 세션정보를 리턴한다.
	 * 로그인
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/info.do")
	@RequestMapping(value = "/info.do")
	public ModelAndView info(HttpServletRequest request)
	{
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

		String userId = "";
		String userNm = "";
		String roleCd = "";

		if(request.getSession().getAttribute("SPRING_SECURITY_CONTEXT") != null)
		{
			Authentication authentication = ((SecurityContextImpl) request.getSession().getAttribute("SPRING_SECURITY_CONTEXT")).getAuthentication();

			AuthVo authVo = new AuthVo();
			BeanUtils.copyProperties(authentication.getPrincipal(), authVo);
			authVo.setRemoteAddr(CommonDaoAssistant.getUserIp());

			List<GrantedAuthority> authorities = new ArrayList<>();
			for(GrantedAuthority authority : authentication.getAuthorities())
			{
				authorities.add(authority);
			}
			authVo.setAuthorities(authorities);
			userId = authVo.getUserId();
			userNm = authVo.getUserNm();
			roleCd = authVo.getRoleName();

			if(userId != null && !"".equals(userId))
			{
				Boolean menuListYn = ServletRequestUtils.getBooleanParameter(request, "menuListYn", false);
				if(menuListYn)
				{
					model.addObject("authRouteMenuList", authService.selectAuthRouteMenuList(authVo));
				}

				model.addObject("userId", userId);
				model.addObject("userName", userNm);
				model.addObject("roleCd", roleCd);
			}
		}

		model.addObject("remainTime", sessionTime);
		model.addObject("sessionId", request.getSession().getId());
		model.addObject("remoteAddr", CommonDaoAssistant.getUserIp());
		model.addObject("sessionCreationTime", request.getSession().getCreationTime());
		model.addObject("sessionLastAccessedTime", request.getSession().getLastAccessedTime());
		model.addObject("sessionMaxInactiveInterval", request.getSession().getMaxInactiveInterval());

		return model;
	}
	
	/**
	 * 권한에 따른 버튼리스트 리턴
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/authButtonList.do")
	public ModelAndView buttonList(HttpServletRequest request, @RequestBody AuthButtonVo buttonVo) throws Exception
	{
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
		
		List<String> defaultAuth = new ArrayList<>();
		defaultAuth.add("ROLE_ANONYMOUS");
		
		if(request.getSession().getAttribute("SPRING_SECURITY_CONTEXT") != null)
		{
			Authentication authentication = ((SecurityContextImpl) request.getSession().getAttribute("SPRING_SECURITY_CONTEXT")).getAuthentication();
			buttonVo.setRoleCd(Arrays.asList(((AuthVo) authentication.getPrincipal()).getRoleName().split(";")));
		}
		if(buttonVo.getRoleCd().isEmpty())
		{
			buttonVo.setRoleCd(defaultAuth);
		}
		AuthButtonVo authButtonVo = (AuthButtonVo) authService.selectButtonList(buttonVo);
		
		model.addObject("result",authButtonVo != null && authButtonVo.getRoleCd().size() > 0 ? true : false);
		
		return model;
	}

	@RequestMapping(value = "/serverTime.do")
	public String serverTime(Model model)
	{
		ZonedDateTime nowSeoul = ZonedDateTime.now(ZoneId.of("Asia/Seoul"));
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		model.addAttribute("serverTime", nowSeoul.format(formatter));

		return "serverTime";
	}

	/**
	 * 접속중인 서버(운영, 개발) 정보 반환
	 *
	 * @param request
	 * @return
	 */
	@PostMapping(value = "/serverInfo.do")
	public ModelAndView serverInfo(HttpServletRequest request, @RequestBody Map<String, String> param) throws Exception
	{
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

		String paramSum = param.get("paramSum");
		if(StringUtils.isNotEmpty(paramSum))
		{
			model.addObject("encryptedParamSum", encryptAES256(paramSum));
		}

		model.addObject("proxyUrl", proxyUrl);
		model.addObject("clipreportUrl",clipreportUrl);

		return model;
	}

	private String encryptAES256(String text) throws Exception {
		String iv = aesKey.substring(0, 16);
		Cipher cipher = Cipher.getInstance(alg);
		SecretKeySpec keySpec = new SecretKeySpec(aesKey.getBytes("UTF-8"), "AES");
		IvParameterSpec ivParamSpec = new IvParameterSpec(iv.getBytes("UTF-8"));
		cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivParamSpec);

		byte[] encrypted = cipher.doFinal(text.getBytes("UTF-8"));
		return Base64.getEncoder().encodeToString(encrypted);
	}
}