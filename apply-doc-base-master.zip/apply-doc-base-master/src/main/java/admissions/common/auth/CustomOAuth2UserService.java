package admissions.common.auth;

import admissions.common.auth.vo.AuthVo;
import admissions.system.user.UserService;
import admissions.system.user.vo.UserFormVo;
import admissions.system.user.vo.UserVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

@Service
public class CustomOAuth2UserService extends DefaultOAuth2UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomOAuth2UserService.class);

    @Autowired
    AuthService userDetailService;

    @Autowired
    UserService userService;

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {

        LOGGER.debug("CustomOAuth2UserService.loadUser()");

        OAuth2User oAuth2User = super.loadUser(userRequest);

        String registrationId = userRequest.getClientRegistration().getRegistrationId().toUpperCase(Locale.ROOT);

        LOGGER.debug("registrationId : " + registrationId);

        // 각각의 소셜에서 값 받아오기(키, 이메일)
        Map<String, String> keyMailMap = getKeyAndUpdate(oAuth2User, registrationId);

        // 위에서 받아온 값(키, 이메일)로 가입 여부 확인
        String email = getEmail(keyMailMap.get("key"), registrationId);

        // 미가입시, 구분을 위해 예외처리
        if (StringUtils.isEmpty(email) && "NAVER".equals(registrationId))
        {
            // 네이버는 새로 회원가입
            throw new UsernameNotFoundException(keyMailMap.get("key") + " naver connect");
        }
        else if (StringUtils.isEmpty(email) && "KAKAO".equals(registrationId))
        {
            // 카카오는 로그인한 아이디로 회원가입
            throw new UsernameNotFoundException(keyMailMap.get("email") + " kakao connect");
        }
        else if (StringUtils.isEmpty(email) && "GOOGLE".equals(registrationId))
        {
            // 구글은 로그인한 아이디로 회원가입
            throw new UsernameNotFoundException(keyMailMap.get("email") + " google connect");
        }

        // 키, 이메일로 가입된 아이디가 있으면 로그인
        return (AuthVo) userDetailService.loadUserByUsername(email);
    }

    private Map<String, String> getKeyAndUpdate(OAuth2User oAuth2User, String registrationId) {

        LOGGER.debug("CustomOAuth2UserService.getKeyAndUpdate()");

        String email = "";
        String key = "";

        Map<String, Object> attributes = oAuth2User.getAttributes();

        switch (registrationId) {
            case "NAVER":
                key = (String) ((Map<String, Object>) attributes.get("response")).get("id");
                break;
            case "KAKAO":
                key = (String) ((Map<String, Object>) attributes.get("kakao_account")).get("email");
                email = (String) ((Map<String, Object>) attributes.get("kakao_account")).get("email");
                break;
            case "GOOGLE":
//                key = (String) attributes.get("sub");
                key = (String) attributes.get("email");
                email = (String) attributes.get("email");
                break;
            default:
                break;
        }

        // 이메일이 비어있지 않고(카카오, 구글)
        if (StringUtils.isNotEmpty(email)) {
            UserFormVo formVo = new UserFormVo();
            formVo.setEmailAddress(email);
            UserVo tempVo = userService.selectUser(formVo);
            // 해당 이메일로 가입된 유저가 있다면 키값 업데이트
            if (tempVo != null) {
                BeanUtils.copyProperties(tempVo, formVo);
                formVo.setLastUpdateProgramId("SocialLogin");
                switch (registrationId) {
                    case "KAKAO":
                        formVo.setKakaoConnect(key);
                        break;
                    case "GOOGLE":
                        formVo.setGoogleConnect(key);
                        break;
                    default:
                        break;
                }
                userService.update(formVo);
            }
        }

        Map<String, String> keyMailMap = new HashMap<>();
        keyMailMap.put("key", key);
        keyMailMap.put("email", email);

        return keyMailMap;
    }

    private String getEmail(String key, String registrationId) {
        LOGGER.debug("CustomOAuth2UserService.getEmail()");
        String email = "";
        UserFormVo formVo = new UserFormVo();

        switch (registrationId) {
            case "NAVER":
                formVo.setNaverConnect(key);
                break;
            case "KAKAO":
                formVo.setKakaoConnect(key);
                break;
            case "GOOGLE":
                formVo.setGoogleConnect(key);
                break;
            default:
                break;
        }

        UserVo userVo = userService.selectUserIdByKey(formVo);

        if (userVo != null) {
            email = userVo.getUserId();
        }

        return email;
    }
}