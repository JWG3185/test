package admissions.common.auth.vo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AuthButtonVo {
	private String menuNo = "";
	private String buttonNm = "";
	private String path = "";

	List<String> roleCd = new ArrayList<>();

	public String getButtonNm() {
		return buttonNm;
	}

	public String getMenuNo() {
		return menuNo;
	}

	public void setMenuNo(String menuNo) {
		this.menuNo = menuNo;
	}

	public void setButtonNm(String buttonNm) {
		this.buttonNm = buttonNm;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public List<String> getRoleCd() {
		return Collections.unmodifiableList(roleCd);
	}

	public void setRoleCd(List<String> roleCd) {
		this.roleCd = Collections.unmodifiableList(roleCd);
	}
}