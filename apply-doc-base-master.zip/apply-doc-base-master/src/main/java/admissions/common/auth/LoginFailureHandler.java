package admissions.common.auth;

import admissions.common.auth.vo.AuthLogVo;
import admissions.common.dao.CommonDaoAssistant;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Enumeration;

public class LoginFailureHandler implements AuthenticationFailureHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoginFailureHandler.class);

    AuthService authService;

    String systemDivisionCode;

    public LoginFailureHandler(AuthService authService, String systemDivisionCode)
    {
        this.authService = authService;
        this.systemDivisionCode = systemDivisionCode;
    }

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException authenticationException) throws IOException, ServletException
    {
        LOGGER.debug("systemDivisionCode : " + systemDivisionCode);

        String loginIp = CommonDaoAssistant.getUserIp();
        String message = authenticationException.getMessage();

        //로그생성
        AuthLogVo logVo = new AuthLogVo();
        logVo.setLoginId(request.getParameter("username"));
        logVo.setLoginIp(loginIp);
        logVo.setLoginYn("N");
        logVo.setLoginResult(message);
        logVo.setLoginHeader(getLoginHeader(request));
        logVo.setSystemDivisionCode(systemDivisionCode);
        authService.insertLoginLog(logVo);

        JSONObject basicResponse = new JSONObject();
        try
        {
            basicResponse.put("timestamp", new Date().getTime());
            basicResponse.put("status", HttpStatus.UNAUTHORIZED.value());
            basicResponse.put("message", message);
            basicResponse.put("path", request.getRequestURI());
        }
        catch(JSONException e)
        {
            if(LOGGER.isErrorEnabled())
            {
                LOGGER.error(e.getMessage().replaceAll("[\r\n]",""));
            }
        }

        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType("application/json");
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.getWriter().write(basicResponse.toString());
    }

    private String getLoginHeader(HttpServletRequest request)
    {
        StringBuffer headers = new StringBuffer();

        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String name = headerNames.nextElement();
            String value = request.getHeader(name);
            headers.append(name).append(": ").append(value).append("\r\n");
        }

        return headers.toString();
    }
}
