package admissions.common.auth;

import admissions.common.auth.vo.AuthVo;
import admissions.common.dao.CommonDaoAssistant;
import admissions.system.user.UserService;
import admissions.system.user.vo.UserFormVo;
import admissions.system.user.vo.UserVo;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

@Controller
@RequestMapping("/social")
public class SocialAuthController {

    private static final Logger LOGGER = LoggerFactory.getLogger(SocialAuthController.class);

    // 카카오
    @Value("${spring.security.oauth2.client.registration.kakao.client-id}")
    private String kakaoClientId;
    @Value("${spring.security.oauth2.client.registration.kakao.client-secret}")
    private String kakaoSecret;
    @Value("${spring.security.oauth2.client.provider.kakao.authorization-uri}")
    private String kakaoAuthorizationUri;
    @Value("${spring.security.oauth2.client.provider.kakao.token-uri}")
    private String kakaoTokenUri;
    @Value("${spring.security.oauth2.client.provider.kakao.user-info-uri}")
    private String kakaoInfoUri;
    @Value("${spring.security.oauth2.client.registration.kakao.scope[0]}")
    private String kakaoScope;
    @Value("${social.kakao.redirect-uri}")
    private String kakaoRedirectnUri;


    // 네이버
    @Value("${spring.security.oauth2.client.registration.naver.client-id}")
    private String naverClientId;
    @Value("${spring.security.oauth2.client.registration.naver.client-secret}")
    private String naverSecret;
    @Value("${spring.security.oauth2.client.provider.naver.authorization-uri}")
    private String naverAuthorizationUri;
    @Value("${spring.security.oauth2.client.provider.naver.token-uri}")
    private String naverTokenUri;
    @Value("${spring.security.oauth2.client.provider.naver.user-info-uri}")
    private String naverInfoUri;
    @Value("${social.naver.redirect-uri}")
    private String naverRedirectnUri;
    @Value("${spring.security.oauth2.client.registration.naver.scope[0]}")
    private String naverScope;
//    @Value("${social.state}")
//    private String state;


    // 구글
    @Value("${spring.security.oauth2.client.registration.google.client-id}")
    private String googleClientId;
    @Value("${spring.security.oauth2.client.registration.google.client-secret}")
    private String googleSecret;
    @Value("${social.google.redirect-uri}")
    private String googleRedirectnUri;
    @Value("${spring.security.oauth2.client.registration.google.scope[0]}")
    private String googleScope;
    private String googleAuthorizationUri = "https://accounts.google.com/o/oauth2/v2/auth";
    private String googleTokenUri = "https://oauth2.googleapis.com/token";
    private String googleInfoUri = "https://www.googleapis.com/userinfo/v2/me";


    @Autowired
    UserService userService;

    @GetMapping("/{socialType}")
    public String updateUserInfo(@PathVariable("socialType") String socialType, Model model) throws UnsupportedEncodingException {
        String url = "";

        if ("Kakao".equals(socialType))
        {
            url = kakaoAuthorizationUri + "?response_type=code&redirect_uri=" + kakaoRedirectnUri
                    + "&scope=" + kakaoScope + "&client_id=" + kakaoClientId;
        }
        else if ("Google".equals(socialType))
        {
            url =  googleAuthorizationUri + "?response_type=code&redirect_uri=" + googleRedirectnUri
                    + "&scope=" + googleScope + "&client_id=" + googleClientId;
        }
        else if ("Naver".equals(socialType))
        {
            url = naverAuthorizationUri + "?response_type=code&redirect_uri=" + naverRedirectnUri
                    + "&client_id=" + naverClientId;
                    // + "&state=" + URLEncoder.encode(state, "UTF-8");
        }

        return "redirect:" + url;
    }

    @GetMapping("/auth/{socialType}")
    public String updateUserInfo(String code, @PathVariable("socialType") String socialType, Model model, HttpServletRequest request) {

        if (!StringUtils.hasText(code)) {
            return "socialAuthFail";
        }

        String jsonToken = "";
        String token = "";
        String profile = "";
        String key = "";
        try {
            jsonToken = requestAccessToken(socialType, generateAuthCodeRequest(socialType, code));
            token = extractAccessToken(jsonToken);
            profile = requestProfile(socialType, generateProfileRequest(token));
            key = extractKey(socialType, profile);

            LOGGER.debug("jsonToken : " + jsonToken);
            LOGGER.debug("token : " + token);
            LOGGER.debug("profile : " + profile);
            LOGGER.debug("key : " + key);

            UserFormVo tempVo = new UserFormVo();


            if("kakao".equals(socialType))
            {
                tempVo.setKakaoConnect(key);
                UserVo vo = userService.selectUserIdByKey(tempVo);
                if (vo != null)
                {
                    return "socialAuthDuplication";
                }
            }
            else if ("google".equals(socialType))
            {
                tempVo.setGoogleConnect(key);
                UserVo vo = userService.selectUserIdByKey(tempVo);
                if (vo != null)
                {
                    return "socialAuthDuplication";
                }
            }
            else if ("naver".equals(socialType))
            {
                tempVo.setNaverConnect(key);
                UserVo vo = userService.selectUserIdByKey(tempVo);
                if (vo != null)
                {
                    return "socialAuthDuplication";
                }
            }

            // 현재 로그인한 회원 아이디 가져오기
            Authentication authentication = ((SecurityContextImpl) request.getSession().getAttribute("SPRING_SECURITY_CONTEXT")).getAuthentication();
            AuthVo authVo = new AuthVo();
            BeanUtils.copyProperties(authentication.getPrincipal(), authVo);

            LOGGER.debug("authVo.getUserId() : " + authVo.getUserId());

            UserFormVo formVo = new UserFormVo();
            formVo.setEmailAddress(authVo.getUserId());

            // 로그인한 회원 정보 가져오기
            UserVo userVo = userService.selectUser(formVo);
            BeanUtils.copyProperties(userVo, formVo);

            switch (socialType) {
                case "kakao":
                    formVo.setKakaoConnect(key);
                    formVo.setGoogleConnect("");
                    formVo.setNaverConnect("");
                    break;
                case "google":
                    formVo.setKakaoConnect("");
                    formVo.setGoogleConnect(key);
                    formVo.setNaverConnect("");
                    break;
                case "naver":
                    formVo.setKakaoConnect("");
                    formVo.setGoogleConnect("");
                    formVo.setNaverConnect(key);
                    break;
                default:
                    break;
            }
            formVo.setLastUpdateProgramId("SocialLogin");
            formVo.setLastUpdateUserId(authVo.getUserId());

            LOGGER.debug("formVo.toString() : " + formVo.toString());

            userService.update(formVo);

        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        return "socialAuthSuccess";
    }

    private HttpEntity<MultiValueMap<String, String>> generateAuthCodeRequest(String socialType, String code) throws UnsupportedEncodingException {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "authorization_code");
        params.add("code", code);

        switch (socialType) {
            case "kakao":
                params.add("client_id", kakaoClientId);
                params.add("client_secret", kakaoSecret);
                params.add("redirect_uri", kakaoRedirectnUri);
                break;
            case "google":
                params.add("client_id", googleClientId);
                params.add("client_secret", googleSecret);
                params.add("redirect_uri", googleRedirectnUri);
                break;
            case "naver":
                params.add("client_id", naverClientId);
                params.add("client_secret", naverSecret);
                params.add("redirect_uri", naverRedirectnUri);
//                params.add("state", state);
                break;
            default:
                break;
        }

        return new HttpEntity<>(params, headers);
    }

    private String requestAccessToken(String socialType, HttpEntity request) {
        RestTemplate restTemplate = new RestTemplate();

        if ("kakao".equals(socialType))
        {
            return restTemplate.exchange(kakaoTokenUri, HttpMethod.POST, request, String.class)
                    .getBody();
        }
        else if ("google".equals(socialType))
        {
            return restTemplate.exchange(googleTokenUri, HttpMethod.POST, request, String.class)
                    .getBody();
        }
        else    //  네이버
        {
            return restTemplate.exchange(naverTokenUri, HttpMethod.POST, request, String.class)
                    .getBody();
        }

    }

    public static String extractAccessToken(String json) {
        try {
            // 주어진 JSON 문자열을 JSONObject로 파싱
            JSONObject jsonObject = new JSONObject(json);

            // "access_token" 필드에서 access_token 추출
            String accessToken = jsonObject.getString("access_token");

            return accessToken;
        } catch (Exception e) {
            e.printStackTrace();
            return null; // 오류 발생 시 null 반환 또는 예외 처리 방법을 수정할 수 있습니다.
        }
    }

    private HttpEntity<MultiValueMap<String, String>> generateProfileRequest(String accessToken)
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer "+ accessToken);
        headers.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
        return new HttpEntity<>(headers);
    }

    private String requestProfile(String socialType, HttpEntity request) {
        RestTemplate restTemplate = new RestTemplate();

        if ("kakao".equals(socialType))
        {
            return restTemplate.exchange(kakaoInfoUri, HttpMethod.POST, request, String.class)
                    .getBody();
        }
        else if ("google".equals(socialType))
        {
            return restTemplate.exchange(googleInfoUri, HttpMethod.GET, request, String.class)
                    .getBody();
        }
        else    //  네이버
        {
            return restTemplate.exchange(naverInfoUri, HttpMethod.GET, request, String.class)
                    .getBody();
        }
    }

    public static String extractKey(String socialType, String json) {
        String key = "";
        // 주어진 JSON 문자열을 JSONObject로 파싱
        JSONObject jsonObject = new JSONObject(json);

        switch (socialType) {
            case "kakao":
                key = jsonObject.getJSONObject("kakao_account").getString("email");
                break;
            case "google":
                key = jsonObject.getString("email");
                break;
            case "naver":
                key = jsonObject.getJSONObject("response").getString("id");
                break;
            default:
                break;
        }

        return key;
    }

    @GetMapping("/cancelSocial/{socialType}")
    public String updateUserInfo(@PathVariable("socialType") String socialType, HttpServletRequest request, Model model) throws UnsupportedEncodingException {

        // 현재 로그인한 회원 아이디 가져오기
        Authentication authentication = ((SecurityContextImpl) request.getSession().getAttribute("SPRING_SECURITY_CONTEXT")).getAuthentication();
        AuthVo authVo = new AuthVo();
        BeanUtils.copyProperties(authentication.getPrincipal(), authVo);

        UserFormVo formVo = new UserFormVo();
        formVo.setEmailAddress(authVo.getUserId());

        switch (socialType) {
            case "Kakao":
                formVo.setKakaoConnect("N");
                formVo.setKakaoConnectDate("N");
                break;
            case "Google":
                formVo.setGoogleConnect("N");
                formVo.setGoogleConnectDate("N");
                break;
            case "Naver":
                formVo.setNaverConnect("N");
                formVo.setNaverConnectDate("N");
                break;
            default:
                break;
        }

        formVo.setLastUpdateProgramId("CancelSocial");
        formVo.setLastUpdateUserId(authVo.getUserId());
        userService.cancelSocialAccount(formVo);

        return "socialAuthCancel";
    }

}

