package admissions.common.config;

import admissions.common.auth.*;
import admissions.system.user.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;


import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityConfig.class);

    @Autowired
    AuthService authService;

    @Autowired
    private UserService userService;

    @Value("${systemDivisionCode.applicationForAdmission}")
    private String systemDivisionCode;

    @Value("${social.connect.url}")
    private String socialConnectUrl;

    private final CustomOAuth2UserService customOAuth2UserService;

    public SecurityConfig(CustomOAuth2UserService customOAuth2UserService){
        this.customOAuth2UserService = customOAuth2UserService;
    }

    @Bean
    public CorsConfigurationSource corsConfig() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(List.of("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD", "CONNECT"));
        configuration.setAllowCredentials(false);
        configuration.setAllowedHeaders(List.of("*"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        LOGGER.debug("SecurityConfig.securityFilterChain()");

        http
                .csrf(AbstractHttpConfigurer::disable)

                .cors(cors -> cors.configurationSource(corsConfig()))

                .authorizeHttpRequests(request -> request
                    .requestMatchers("/static/**", "/actuator/**", "/", "/*", "/error","/common/auth/info.do", "/system/user/**", "/ws/**").permitAll()
                    .requestMatchers(new AntPathRequestMatcher("classpath:/static/**")).permitAll()
                    .anyRequest().authenticated()
                )

                .formLogin(login -> login
                        .loginProcessingUrl("/common/auth/login.do")
                        .successHandler(new LoginSuccessHandler(authService, systemDivisionCode))
                        .failureHandler(new LoginFailureHandler(authService, systemDivisionCode))
                        .permitAll()
                )

                .logout(logout -> logout
                        .logoutUrl("/common/auth/logout.do")
                        .logoutSuccessHandler(new JsonLogoutSuccessHandler())
                        .invalidateHttpSession(true)
                )
        ;

        http
                .oauth2Login(oauth2 -> oauth2
                        .authorizationEndpoint(authorizationEndpointConfig -> authorizationEndpointConfig
                                .baseUri("/oauth2/authorize"))
                        .redirectionEndpoint(redirectionEndpointConfig -> redirectionEndpointConfig
                                .baseUri("/login/oauth2/code/**"))
                        .userInfoEndpoint(userInfoEndpointConfig -> userInfoEndpointConfig
                                .userService(customOAuth2UserService))
                        .successHandler(new OAuthLoginSuccessHandler(socialConnectUrl, authService, systemDivisionCode))
                        .failureHandler(new OAuthLoginFailureHandler(socialConnectUrl, userService, authService, systemDivisionCode))
                )
        ;

        return http.build();
    }
}