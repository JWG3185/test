package admissions.common.config;

import admissions.common.auth.AuthService;
import admissions.common.interceptor.IpAddressInterceptor;
import admissions.common.interceptor.JsonResponseInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final AuthService authService;

    public WebConfig(AuthService authService) {
        this.authService = authService;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry)
    {
        registry.addInterceptor(new IpAddressInterceptor(authService))
                .addPathPatterns("/**/*.do");
        registry.addInterceptor(new JsonResponseInterceptor())
                .addPathPatterns("/**/*.do");
    }
}
