package admissions.common.config;

import admissions.common.auth.AuthService;
import admissions.common.auth.vo.AuthFormVo;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@RequiredArgsConstructor
public class AuthenticationFilterConfig extends UsernamePasswordAuthenticationFilter {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationFilterConfig.class);
	private final ObjectMapper objectMapper = new ObjectMapper();
	AuthService authService;
	PasswordEncoder passwordEncoder;

	public AuthenticationFilterConfig(AuthService authService, PasswordEncoder passwordEncoder) {
		this.authService = authService;
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException
	{
		String requestBody = null
				;
		try {
			requestBody = IOUtils.toString(request.getReader());

			LOGGER.debug("requestBody: " + requestBody);
		} catch (IOException e) {
			e.printStackTrace();
		}

		String username = null;
		String password = null;

		boolean isJsonString = false;

		AuthFormVo authFormVo = null;

		if(requestBody.length() > 0)
		{
			try {
				authFormVo = objectMapper.readValue(requestBody, AuthFormVo.class);
				isJsonString = true;
			}
			catch (Exception e)
			{
				LOGGER.info("message is not json string");
			}
		}

		if(isJsonString)
		{
			username = authFormVo.getUserId().trim();
			password = authFormVo.getUserPassword().trim();
		}
		else{
			Map<String, String> params = parseQueryString(requestBody);

			username = params.get("username");
			password = params.get("password");
		}

		LOGGER.debug("username = " + username);
		LOGGER.debug("password = " + password);
		LOGGER.debug("request.getRequestURI() = " + request.getRequestURI());

		UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);

		LOGGER.debug("authRequest........{}", authRequest);

		setDetails(request, authRequest);

		return this.getAuthenticationManager().authenticate(authRequest);
	}

	private static Map<String, String> parseQueryString(String query) {
		Map<String, String> params = new HashMap<>();
		for (String param : query.split("&")) {
			String[] pair = param.split("=");
			if (pair.length > 1) {
				String key = URLDecoder.decode(pair[0], StandardCharsets.UTF_8);
				String value = URLDecoder.decode(pair[1], StandardCharsets.UTF_8);
				params.put(key, value);
			}
		}
		return params;
	}
}