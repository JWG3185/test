package admissions.common.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;
import java.util.Objects;

@Configuration
public class DatabaseConfig
{
	@Autowired
	@Qualifier(value = "dataSource")
	private DataSource datasource;

	@Bean
	@Primary
	public SqlSessionFactory sqlSessionFactory() throws Exception
	{
		SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
		sqlSessionFactory.setDataSource(datasource);

		sqlSessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:/**/mapper/*.xml"));
		Objects.requireNonNull(sqlSessionFactory.getObject()).getConfiguration().setMapUnderscoreToCamelCase(true);
		Objects.requireNonNull(sqlSessionFactory.getObject()).getConfiguration().setJdbcTypeForNull(JdbcType.VARCHAR);
		return sqlSessionFactory.getObject();
	}

	@Bean
	@Primary
	public SqlSessionTemplate sqlSession() throws Exception
	{
		return new SqlSessionTemplate(sqlSessionFactory());
	}
}