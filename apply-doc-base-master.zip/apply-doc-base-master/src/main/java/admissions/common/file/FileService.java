package admissions.common.file;

import admissions.common.dao.CommonDao;
import admissions.common.file.vo.CommonFileVo;
import admissions.common.vo.DataDefaultVo;
import jakarta.servlet.http.Part;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.plexus.util.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Component
public class FileService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FileService.class);

    @Value("${file.upload.dir}")
    private String uploadDir;

    @Autowired
    private CommonDao commonDao;

    /**
     * 파일을 저장한다.
     */
    public CommonFileVo doUpload(Part part, String fileGroupNo) throws NoSuchAlgorithmException, IOException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("fileGroupNo: {}", fileGroupNo.replaceAll("[\r\n]", ""));
        }
        String savePath = makeGroupDir(fileGroupNo);
        String extension = part.getSubmittedFileName().substring(part.getSubmittedFileName().lastIndexOf(".") + 1).toLowerCase(Locale.ENGLISH);
        String saveName = getSaveName(part.getSubmittedFileName()) + "." + extension;

        //여기서 저장
        part.write(savePath + File.separator + saveName);

        long size = part.getSize();
        String size2 = "";
        if (size < Math.pow(1024, 1)) {
            size2 = size + " Bytes";
        } else if (size < Math.pow(1024, 2)) {
            size2 = Math.round((float) size / (float) 1024) + "KB";
        } else if (size < Math.pow(1024, 3)) {
            size2 = Math.round((float) size / (float) Math.pow(1024, 2)) + "MB";
        } else if (size < Math.pow(1024, 4)) {
            size2 = Math.round((float) size / (float) Math.pow(1024, 3)) + "GB";
        } else if (size < Math.pow(1024, 5)) {
            size2 = Math.round((float) size / (float) Math.pow(1024, 4)) + "TB";
        }
        String fileType = part.getContentType();

        CommonFileVo commonFileVo = new CommonFileVo();
        commonFileVo.setFileGroupNo(fileGroupNo);
        commonFileVo.setFileNo("tmp");
        commonFileVo.setFileNm(part.getSubmittedFileName());
        commonFileVo.setFileExtensionNm(extension);
        commonFileVo.setServerFileSaveNm(saveName);
        commonFileVo.setServerFileSavePath(savePath);
        commonFileVo.setFileSize(size);
        commonFileVo.setFileSizeNm(size2);
        commonFileVo.setMimeTypeNm(fileType);

        return commonFileVo;
    }

    private String makeGroupDir(String fileGroupNo) {
        LOGGER.debug("mkdir() called");

        FileUtils.mkdir(uploadDir);

        if ("tmp".equals(fileGroupNo)) {
            String groupDir = uploadDir + File.separator + fileGroupNo;
            FileUtils.mkdir(groupDir);

            return groupDir;
        } else {
            Calendar cal = Calendar.getInstance();
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH) + 1;
            String groupDir = uploadDir + File.separator + year + "-" + String.format("%02d", month) + File.separator + fileGroupNo;
            FileUtils.mkdir(uploadDir + File.separator + year + "-" + String.format("%02d", month));
            FileUtils.mkdir(groupDir);

            return groupDir;
        }
    }

    /**
     * 파일 명 생성
     *
     * @param origName
     * @return
     * @throws NoSuchAlgorithmException
     */
    private String getSaveName(String origName) throws NoSuchAlgorithmException {
        String returnName = "";

        String origNameDate = origName + new Date().getTime();

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(origNameDate.getBytes(StandardCharsets.UTF_8));

        byte byteData[] = md.digest();
        String sb = IntStream.range(0, byteData.length).mapToObj(index -> Integer.toString((byteData[index] & 0xff) + 0x100, 16).substring(1)).collect(Collectors.joining());

        String encodeName = StringUtils.upperCase(sb);

        while (encodeName.length() > 4) {
            returnName += (returnName.length() == 0 ? "" : "-") + encodeName.substring(0, 4);
            encodeName = encodeName.substring(4);
        }

        if (encodeName.length() > 0) {
            returnName += "-" + encodeName;
        }

        return returnName;
    }

    /**
     * 파일 목록을 저장한다.
     *
     * @param list
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public String doSave(List<?> list, String origFileGroupNo) {
        String fileGroupNo = null;
        String serverFileSavePath = null;

        //파일 그룹
        if (origFileGroupNo.isEmpty() && !list.isEmpty()) {
            if (list.get(0) instanceof CommonFileVo) {
                fileGroupNo = ((CommonFileVo) list.get(0)).getFileGroupNo();
            } else if (list.get(0) instanceof HashMap) {
                fileGroupNo = (String) ((HashMap) list.get(0)).get("fileGroupNo");
            }

            if ("tmp".equals(fileGroupNo) || "null".equals(fileGroupNo) || StringUtils.isEmpty(fileGroupNo)) {
                CommonFileVo fileGroupNoVo = new CommonFileVo();
                fileGroupNoVo.setFirstRegistProgramId(((DataDefaultVo) list.get(0)).getFirstRegistProgramId());
                fileGroupNoVo.setFirstRegistUserId(((DataDefaultVo) list.get(0)).getFirstRegistUserId());
                commonDao.insert("FileMapper.insertFileGroup", fileGroupNoVo);

                fileGroupNo = fileGroupNoVo.getFileGroupNo();
            }
            //저장 폴더 위치 확인
            serverFileSavePath = makeGroupDir(fileGroupNo);
        } else {
            fileGroupNo = origFileGroupNo;
            serverFileSavePath = makeGroupDir(fileGroupNo);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("fileGroupSeq: {}", fileGroupNo.replaceAll("[\r\n]", ""));
        }

        if (StringUtils.isNotEmpty(fileGroupNo)) {
            //기존파일만 남김
            CommonFileVo deleteFileVo = new CommonFileVo();
            deleteFileVo.setFileGroupNo(fileGroupNo);
            List<String> fileNoList = new ArrayList<String>();
            for (Object obj : list) {
                String fileNo = "";

                if (obj instanceof CommonFileVo) {
                    fileNo = ((CommonFileVo) obj).getFileNo();
                } else if (obj instanceof HashMap) {
                    fileNo = (String) ((HashMap) obj).get("fileNo");
                }

                if (!fileNo.equals("tmp")) {
                    fileNoList.add(fileNo);
                }
            }
            if (fileNoList.isEmpty()) {
                fileNoList.add("0");
            }
            deleteFileVo.setFileNoList(fileNoList);

            List<CommonFileVo> deleteFileList = (List<CommonFileVo>) commonDao.selectList("FileMapper.selectNotExist", deleteFileVo);

            if (!deleteFileList.isEmpty()) {
                for (CommonFileVo fileVo : deleteFileList) {
                    final String savePath = fileVo.getServerFileSavePath();
                    final String saveName = fileVo.getServerFileSaveNm();
                    final String filePath = savePath + File.separator + saveName;

                    try {
                        FileUtils.forceDelete(filePath);
                    } catch (IOException e) {
                        if (LOGGER.isErrorEnabled()) {
                            LOGGER.error("file can't be deleted with IOException : {}", e.getMessage());
                        }
                    }
                }
            }

            commonDao.delete("FileMapper.deleteNotExist", deleteFileVo);
        }

        //신규 파일 등록
        for (Object obj : list) {
            CommonFileVo fileVo = new CommonFileVo();

            if (obj instanceof CommonFileVo) {
                fileVo = (CommonFileVo) obj;
            } else if (HashMap.class.isInstance(obj.getClass())) {
                HashMap map = (HashMap) obj;
                fileVo.setFileExtensionNm((String) map.get("fileExtentionNm"));
                fileVo.setFileGroupNo((String) map.get("fileGroupNo"));
                fileVo.setFileNm((String) map.get("fileNm"));
                fileVo.setFileNo((String) map.get("fileNo"));
                fileVo.setFileSize((Integer) map.get("fileSize"));
                fileVo.setFileSizeNm((String) map.get("fileSizeNm"));
                fileVo.setMimeTypeNm((String) map.get("fileType"));
                fileVo.setServerFileSaveNm((String) map.get("serverFileSaveNm"));
                fileVo.setServerFileSaveIp("localhost");
                fileVo.setServerFileSavePath((String) map.get("serverFileSavePath"));

                fileVo.setFirstRegistProgramId(((DataDefaultVo) list.get(0)).getFirstRegistProgramId());
                fileVo.setFirstRegistUserId(((DataDefaultVo) list.get(0)).getFirstRegistUserId());
            }

            if (!"tmp".equals(fileVo.getFileNo())) {
                continue;
            }

            fileVo.setFileGroupNo(fileGroupNo);

            File tmpFile = FileUtils.getFile(fileVo.getServerFileSavePath() + File.separator + fileVo.getServerFileSaveNm());
            File saveFile = FileUtils.getFile(serverFileSavePath + File.separator + fileVo.getServerFileSaveNm());

            try {
                FileUtils.rename(tmpFile, saveFile);
                if (fileVo.getServerFileSavePath().endsWith("tmp")) {
                    String tmpPath = Paths.get(saveFile.getAbsolutePath()).getParent().toString();
                    fileVo.setServerFileSavePath(tmpPath);
                    fileVo.setServerFileSaveIp("localhost");
                }
            } catch (IOException e) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error("tmpFile can't saveFile with IOException : {}", e.getMessage());
                }
            }

            commonDao.insert("FileMapper.insertFile", fileVo);
        }

        if (StringUtils.isNotEmpty(fileGroupNo)) {
            //파일이 없으면 FileGroupNo 비우기
            List<CommonFileVo> resultList = (List<CommonFileVo>) commonDao.selectList("FileMapper.selectList", fileGroupNo);
            if (resultList.isEmpty()) {
                commonDao.delete("FileMapper.deleteGroupFromFileGroupNo", fileGroupNo);

                if (StringUtils.isNotEmpty(fileGroupNo)) {
                    String groupDir = uploadDir + File.separator + fileGroupNo;
                    if (FileUtils.fileExists(groupDir)) {
                        try {
                            FileUtils.forceDelete(groupDir);
                        } catch (IOException e) {
                            if (LOGGER.isErrorEnabled()) {
                                LOGGER.error("file can't be deleted with IOException : {}", e.getMessage());
                            }
                        }
                    }
                }

                fileGroupNo = "";
            }
        }

        return fileGroupNo;
    }

    /**
     * 파일 목록 조회
     */
    public List<?> selectList(String fileGroupNo) {
        return commonDao.selectList("FileMapper.selectList", fileGroupNo);
    }

    /**
     * 파일 조회
     */
    public CommonFileVo selectFile(CommonFileVo vo) {
        return (CommonFileVo) commonDao.selectOne("FileMapper.selectFile", vo);
    }

    /**
     * 파일 삭제 및 레코드 삭제
     */
    public void deleteFileGroup(String fileGroupNo) {

        if (fileGroupNo.isEmpty()) {
            return;
        }

        List<CommonFileVo> deleteFileList = (List<CommonFileVo>) commonDao.selectList("FileMapper.selectList", fileGroupNo);

        if (!deleteFileList.isEmpty()) {
            for (CommonFileVo fileVo : deleteFileList) {
                final String saveFileIp = fileVo.getServerFileSaveIp();
                final String savePath = fileVo.getServerFileSavePath();
                final String saveName = fileVo.getServerFileSaveNm();
                final String filePath = savePath + File.separator + saveName;

                if (FileUtils.fileExists(filePath)) {
                    try {
                        FileUtils.forceDelete(filePath);
                    } catch (IOException e) {
                        if (LOGGER.isErrorEnabled()) {
                            LOGGER.error("file can't be deleted with IOException : {}", e.getMessage());
                        }
                    }
                }
            }
        }

        commonDao.delete("FileMapper.deleteFileFromFileGroupNo", fileGroupNo);
        commonDao.delete("FileMapper.deleteGroupFromFileGroupNo", fileGroupNo);
    }

    /**
     * 파일 삭제 및 레코드 삭제
     */
    public void deleteFile(String fileGroupNo, String fileNo) {
        CommonFileVo commonFileVo = new CommonFileVo();
        commonFileVo.setFileGroupNo(fileGroupNo);
        commonFileVo.setFileNo(fileNo);
        CommonFileVo fileVo = (CommonFileVo) commonDao.selectOne("FileMapper.selectFileFromFileNo", commonFileVo);

        if (fileVo != null) {
            final String saveFileIp = fileVo.getServerFileSaveIp();
            final String savePath = fileVo.getServerFileSavePath();
            final String saveName = fileVo.getServerFileSaveNm();
            final String filePath = savePath + File.separator + saveName;

            if (FileUtils.fileExists(filePath)) {
                try {
                    FileUtils.forceDelete(filePath);
                } catch (IOException e) {
                    if (LOGGER.isErrorEnabled()) {
                        LOGGER.error("file can't be deleted with IOException : {}", e.getMessage());
                    }
                }
            }
            commonDao.delete("FileMapper.deleteFileFromFileNo", fileNo);
        }
    }
}
