package admissions.common.file;

import admissions.common.file.vo.CommonFileVo;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.plexus.util.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Controller
@RequestMapping("/common/file")
public class FileController {
	private static final Logger LOGGER = LoggerFactory.getLogger(FileController.class);
	@Autowired
	FileService fileService;

	@Value("${file.upload.dir}")
	private String uploadDir;

	/**
	 * 다중 파일 데이터를 등록한다.
	 */
	@PostMapping(value = "/upload.do")
	public ModelAndView upload(HttpServletRequest request) throws Exception {
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

		String fileGroupNo = ServletRequestUtils.getStringParameter(request, "fileGroupNo");

		if (StringUtils.isEmpty(fileGroupNo) || "undefined".equals(fileGroupNo)) {
			fileGroupNo = "tmp";
		}

		List<CommonFileVo> fileList = new ArrayList<CommonFileVo>();
		for (Part part : request.getParts()) {
			if (part.getContentType() == null) {
				continue;
			}
			fileList.add(fileService.doUpload(part, fileGroupNo));
		}
		model.addObject("fileList", fileList);

		return model;
	}

	/**
	 * 일반 파일 다운로드
	 */
	@PostMapping("/download.do")
	public void doDownload(HttpServletResponse response, final String fileGroupNo, final String serverFileSavePath, final String serverFileSaveNm, final String fileNm) throws IOException
	{
		CommonFileVo paramVo = new CommonFileVo();
		paramVo.setFileGroupNo(fileGroupNo);
		paramVo.setServerFileSaveNm(serverFileSaveNm);
		paramVo.setFileNm(fileNm);
		paramVo.setServerFileSavePath(serverFileSavePath);

		CommonFileVo fileVo = fileService.selectFile(paramVo);

		if(fileVo != null)
		{
			final String savePath = fileVo.getServerFileSavePath();
			final String saveName = fileVo.getServerFileSaveNm();
			final String fileName = fileVo.getFileNm();

			File file = FileUtils.getFile(savePath + File.separator + saveName);

			final int fileSize = Long.valueOf(Files.size(file.toPath())).intValue();

			if(file.exists() && file.isFile())
			{
				try (InputStream is = Files.newInputStream(file.toPath(), StandardOpenOption.READ))
				{
					IOUtils.copy(is, response.getOutputStream());

					response.setContentType("application/octet-stream");
					response.setContentLength(fileSize);
					response.setHeader("Content-Disposition", "attachment; fileName=\"" + fileName + "\";");
					response.setHeader("Content-Transfer-Encoding", "binary");
					response.getOutputStream().flush();
					response.getOutputStream().close();
				}
			}
		}
		/* tmp 파일 다운로드 추가 */
		else if("tmp".equals(fileGroupNo)) {
			final String savePath = serverFileSavePath;
			final String saveName = serverFileSaveNm;
			final String fileName = fileNm;

			final File file = FileUtils.getFile(savePath + File.separator + saveName);
			final int fileSize = Long.valueOf(Files.size(file.toPath())).intValue();

			if(file.exists() && file.isFile())
			{
				try (InputStream is = Files.newInputStream(file.toPath(), StandardOpenOption.READ))
				{
					IOUtils.copy(is, response.getOutputStream());

					response.setContentType("application/octet-stream");
					response.setContentLength(fileSize);
					response.setHeader("Content-Disposition", "attachment; fileName=\"" + fileName + "\";");
					response.setHeader("Content-Transfer-Encoding", "binary");
					response.getOutputStream().flush();
					response.getOutputStream().close();
				}
			}
		}
		/* tmp 파일 다운로드 추가 */
	}

	/**
	 * zip 파일 다운로드
	 */
	@SuppressWarnings("unchecked")
	@PostMapping(value = "/downloadAll.do")
	public void doDownloadAll(HttpServletResponse response, String fileGroupNo) throws IOException {

		//String dirPath = uploadDir + File.separator + fileGroupNo;
		response.setStatus(HttpServletResponse.SC_OK);
		response.setContentType("application/zip");
		response.setHeader("Content-Disposition", "attachment; filename=\"all_in_One.zip\";");

		try(ZipOutputStream zipOut = new ZipOutputStream(response.getOutputStream()))
		{
			List<CommonFileVo> saveFileList = (List<CommonFileVo>) fileService.selectList(fileGroupNo);

			List<File> fileList = new ArrayList<File>();
			for(CommonFileVo fileVo : saveFileList)
			{
				final String savePath = fileVo.getServerFileSavePath();
				final String saveName = fileVo.getServerFileSaveNm();
				File file = FileUtils.getFile(savePath + File.separator + saveName);
				fileList.add(file);
			}

			for (File file : fileList) {
				zipOut.putNextEntry(new ZipEntry(
						saveFileList.stream().filter(fileInfo -> file.getName().equals(fileInfo.getServerFileSaveNm()))
								.findAny().orElse(null).getFileNm()));

				try(InputStream is = Files.newInputStream(file.toPath(), StandardOpenOption.READ))
				{
					StreamUtils.copy(is, zipOut);
				}
			}
		}
	}

	/**
	 * 파일 이미지 불러오기
	 */
	@GetMapping("/imgLoad.do")
	public void imgLoad(HttpServletRequest request ,HttpServletResponse response, String fileGroupNo, String serverFileSaveNm)
			throws IOException
	{
		// 브라우저 별 한글 인코딩
		String header = request.getHeader("User-Agent");
		String encodedServerFileSaveNm = serverFileSaveNm;
		if (header.contains("Edge")){
			encodedServerFileSaveNm = URLEncoder.encode(serverFileSaveNm, "UTF-8").replaceAll("\\+", "%20");
		} else if (header.contains("MSIE") || header.contains("Trident")) { // IE 11버전부터 Trident로 변경되었기때문에 추가해준다.
			encodedServerFileSaveNm = URLEncoder.encode(serverFileSaveNm, "UTF-8").replaceAll("\\+", "%20");
		} else if (header.contains("Chrome")) {
			encodedServerFileSaveNm = new String(serverFileSaveNm.getBytes("UTF-8"), "ISO-8859-1");
		} else if (header.contains("Opera")) {
			encodedServerFileSaveNm = new String(serverFileSaveNm.getBytes("UTF-8"), "ISO-8859-1");
		} else if (header.contains("Firefox")) {
			encodedServerFileSaveNm = new String(serverFileSaveNm.getBytes("UTF-8"), "ISO-8859-1");
		}
		
		if("tmp".equals(fileGroupNo))
		{
			String dirPath = uploadDir + File.separator + fileGroupNo + File.separator + encodedServerFileSaveNm;

			final File file = FileUtils.getFile(dirPath);
			final int fileSize = Long.valueOf(Files.size(file.getAbsoluteFile().toPath())).intValue();

			if(file.exists() && file.isFile())
			{
				try (InputStream is = Files.newInputStream(file.toPath(), StandardOpenOption.READ))
				{
					IOUtils.copy(is, response.getOutputStream());

					response.setContentLength(fileSize);
					response.setHeader("Content-Disposition", "inline;");
					response.setHeader("Content-Transfer-Encoding", "binary");
					response.getOutputStream().flush();
					response.getOutputStream().close();
				}
			}
		}
		else{
			CommonFileVo commonFileVo = new CommonFileVo();
			commonFileVo.setFileGroupNo(fileGroupNo);
			commonFileVo.setServerFileSaveNm(encodedServerFileSaveNm);
			CommonFileVo fileVo = fileService.selectFile(commonFileVo);

			if(fileVo != null)
			{
				final String savePath = fileVo.getServerFileSavePath();
				final String saveName = fileVo.getServerFileSaveNm();
				final String mimeType = fileVo.getMimeTypeNm();

				File file = FileUtils.getFile(savePath + File.separator + saveName);
				final int fileSize = Long.valueOf(Files.size(file.getAbsoluteFile().toPath())).intValue();

				if(file.exists() && file.isFile())
				{
					try (InputStream is = Files.newInputStream(file.toPath(), StandardOpenOption.READ))
					{
						IOUtils.copy(is, response.getOutputStream());

						response.setContentType(mimeType);
						response.setContentLength(fileSize);
						response.setHeader("Content-Disposition", "inline;");
						response.setHeader("Content-Transfer-Encoding", "binary");
						response.getOutputStream().flush();
						response.getOutputStream().close();
					}
				}
			}
		}
	}

    /**
     * 파일 pdf 불러오기
     */
    @GetMapping(value="/pdfLoad.do", produces=MediaType.APPLICATION_PDF_VALUE)
    public void pdfLoad(HttpServletRequest request ,HttpServletResponse response, String fileGroupNo, String serverFileSaveNm)
            throws IOException
    {
        // 브라우저 별 한글 인코딩
        String header = request.getHeader("User-Agent");
        if (header.contains("Edge")){
            serverFileSaveNm = URLEncoder.encode(serverFileSaveNm, "UTF-8").replaceAll("\\+", "%20");
        } else if (header.contains("MSIE") || header.contains("Trident")) { // IE 11버전부터 Trident로 변경되었기때문에 추가해준다.
            serverFileSaveNm = URLEncoder.encode(serverFileSaveNm, "UTF-8").replaceAll("\\+", "%20");
        } else if (header.contains("Chrome")) {
            serverFileSaveNm = new String(serverFileSaveNm.getBytes("UTF-8"), "ISO-8859-1");
        } else if (header.contains("Opera")) {
            serverFileSaveNm = new String(serverFileSaveNm.getBytes("UTF-8"), "ISO-8859-1");
        } else if (header.contains("Firefox")) {
            serverFileSaveNm = new String(serverFileSaveNm.getBytes("UTF-8"), "ISO-8859-1");
        }

        if("tmp".equals(fileGroupNo))
        {
            String dirPath = uploadDir + File.separator + fileGroupNo + File.separator + serverFileSaveNm;

            final File file = FileUtils.getFile(dirPath);
            final int fileSize = Long.valueOf(Files.size(file.getAbsoluteFile().toPath())).intValue();

            if(file.exists() && file.isFile())
            {
                try (InputStream is = Files.newInputStream(file.toPath(), StandardOpenOption.READ))
                {
                    response.setContentLength(fileSize);
                    response.setHeader("Content-Disposition", "inline;");
                    response.setHeader("Content-Transfer-Encoding", "binary");

                     IOUtils.copy(is, response.getOutputStream());

                    response.getOutputStream().flush();
                    response.getOutputStream().close();
                }
            }
        }
        else{
            CommonFileVo commonFileVo = new CommonFileVo();
            commonFileVo.setFileGroupNo(fileGroupNo);
            commonFileVo.setServerFileSaveNm(serverFileSaveNm);
            CommonFileVo fileVo = fileService.selectFile(commonFileVo);

            if(fileVo != null)
            {
                final String savePath = fileVo.getServerFileSavePath();
                final String saveName = fileVo.getServerFileSaveNm();
                final String mimeType = fileVo.getMimeTypeNm();

                final File file = FileUtils.getFile(savePath + File.separator + saveName);
                final int fileSize = Long.valueOf(Files.size(file.getAbsoluteFile().toPath())).intValue();

                if(file.exists() && file.isFile())
                {
                    try (InputStream is = Files.newInputStream(file.toPath(), StandardOpenOption.READ))
                    {
                        response.setContentType(mimeType);
                        response.setContentLength(fileSize);
//						response.setHeader("Content-Type", mimeType);
                        response.setHeader("Content-Disposition", "inline;");
                        response.setHeader("Content-Transfer-Encoding", "binary");

                        IOUtils.copy(is, response.getOutputStream());

                        response.getOutputStream().flush();
                        response.getOutputStream().close();

                    }
                }
            }
        }
    }

	@PostMapping("/fileList.do")
	public ModelAndView fileList(HttpServletRequest request, String fileGroupNo) throws IOException
	{
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
		model.addObject("fileList", fileService.selectList(fileGroupNo));
		return model;
	}

	/**
	 * 서버 내 정적 resource를 다운로드 하기 위한 컨트롤러.
	 * resources/doc/ 아래 파일이 존재해야하며, 해당 파일의 확장자를 포함하여 보내야함
	 * @param filename
	 * @return
	 * @throws IOException
	 */
	@PostMapping("/downloadTemplate.do")
	public ResponseEntity<Resource> downloadTemplate(String filename) throws IOException {
		Resource resource = new ClassPathResource("doc/" + filename); // 다운로드할 파일의 경로

		try (InputStream inputStream = resource.getInputStream()) {
			// 파일의 MIME 타입 설정
			String mimeType = URLConnection.guessContentTypeFromName(resource.getFilename());
			if (mimeType == null) {
				mimeType = "application/octet-stream";
			}

			// 데이터를 로드한 후 InputStream 닫기
			byte[] data = IOUtils.toByteArray(inputStream);

			return ResponseEntity.ok()
					.contentType(MediaType.parseMediaType(mimeType))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
					.body(new ByteArrayResource(data));
		}
	}
}