package admissions.common.file.vo;

import admissions.common.vo.DataDefaultVo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CommonFileVo extends DataDefaultVo
{
	private String fileNo = "";
	private String fileGroupNo = "";
	private String fileNm = "";
	private String fileExtensionNm = "";
	private String serverFileSavePath = "";
	private String serverFileSaveNm = "";
	private String serverFileSaveIp = "";

	public String getServerFileSaveIp() {
		return serverFileSaveIp;
	}

	public void setServerFileSaveIp(String serverFileSaveIp) {
		this.serverFileSaveIp = serverFileSaveIp;
	}

	long fileSize = 0;
	private String fileSizeNm = "";
	private String mimeTypeNm = "";

	private List<String> fileNoList = new ArrayList<String>();

	public String getFileNo() {
		return fileNo;
	}

	public void setFileNo(String fileNo) {
		this.fileNo = fileNo;
	}

	public String getFileGroupNo() {
		return fileGroupNo;
	}

	public void setFileGroupNo(String fileGroupNo) {
		this.fileGroupNo = fileGroupNo;
	}

	public String getFileNm() {
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public String getFileExtensionNm() {
		return fileExtensionNm;
	}

	public void setFileExtensionNm(String fileExtensionNm) {
		this.fileExtensionNm = fileExtensionNm;
	}

	public String getServerFileSavePath() {
		return serverFileSavePath;
	}

	public void setServerFileSavePath(String serverFileSavePath) {
		this.serverFileSavePath = serverFileSavePath;
	}

	public String getServerFileSaveNm() {
		return serverFileSaveNm;
	}

	public void setServerFileSaveNm(String serverFileSaveNm) {
		this.serverFileSaveNm = serverFileSaveNm;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileSizeNm() {
		return fileSizeNm;
	}

	public void setFileSizeNm(String fileSizeNm) {
		this.fileSizeNm = fileSizeNm;
	}

	public String getMimeTypeNm() {
		return mimeTypeNm;
	}

	public void setMimeTypeNm(String mimeTypeNm) {
		this.mimeTypeNm = mimeTypeNm;
	}

	public List<String> getFileNoList() {
		return Collections.unmodifiableList(fileNoList);
	}

	public void setFileNoList(List<String> fileNoList) {
		this.fileNoList = Collections.unmodifiableList(fileNoList);
	}
}