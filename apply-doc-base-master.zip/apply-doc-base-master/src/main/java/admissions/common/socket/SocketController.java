package admissions.common.socket;

import admissions.common.socket.vo.SocketFormVo;
import admissions.common.socket.vo.SocketVo;
import admissions.common.socket.vo.SpringSessionVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class SocketController
{
	private static final Logger LOGGER = LoggerFactory.getLogger(SocketController.class);

	final
	SimpMessagingTemplate template;

	final
	SocketService socketService;

	public SocketController(SimpMessagingTemplate template, SocketService socketService) {
		this.template = template;
		this.socketService = socketService;
	}

	@MessageMapping("/ws/receive")
	public void receiver(SocketFormVo socketFormVo)
	{
		String userId = socketFormVo.getUserId();
		String sessionId = socketFormVo.getSessionId();
		String command = socketFormVo.getCommand();

		if(StringUtils.isNotEmpty(command) && "isValidUser".equals(command))
		{
			SpringSessionVo springSessionVo = socketService.isValidUser(socketFormVo);

			SocketVo socketVo = new SocketVo();
			socketVo.setSessionId(sessionId);
			socketVo.setCommand(command);
			socketVo.setUserId("");
			socketVo.setRemainTime(-1);

			if(springSessionVo != null)
			{
				socketVo.setUserId(springSessionVo.getPrincipalName());
				socketVo.setRemainTime(springSessionVo.getRemainTime());
			}

			template.convertAndSend("/ws/send" + sessionId, socketVo);
		}
	}
}