package admissions.common.socket;

import admissions.common.dao.CommonDao;
import admissions.common.socket.vo.SessionSchedulerVo;
import admissions.common.socket.vo.SocketFormVo;
import admissions.common.socket.vo.SpringSessionVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SocketService
{
	private static final Logger LOGGER = LoggerFactory.getLogger(SocketService.class);

	private final CommonDao commonDao;

	public SocketService(CommonDao commonDao) {
		this.commonDao = commonDao;
	}
	
	/**
	 * 잔여시간조회
	 */
	public SessionSchedulerVo selectRemainTime(SessionSchedulerVo sessionSchedulerVo)
	{
		LOGGER.debug("selectRemainTime()");
		return (SessionSchedulerVo) commonDao.selectOne("SocketMapper.selectRemainTime", sessionSchedulerVo);
	}

	/**
	 * 세션 테이블에서 사용자 유효한지 조회
	 */
	public SpringSessionVo isValidUser(SocketFormVo socketFormVo)
	{
		return (SpringSessionVo) commonDao.selectOne("SocketMapper.selectIsValidUser", socketFormVo);
	}
}
