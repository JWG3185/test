package admissions.common.interceptor;

import admissions.common.auth.vo.AuthVo;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.util.HashMap;

@Component
public class JsonResponseInterceptor implements HandlerInterceptor
{
    private static final Logger LOGGER = LoggerFactory.getLogger(JsonResponseInterceptor.class);

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView model) throws Exception {
        JsonResponseWrapper responseWrapper = new JsonResponseWrapper(response);

        if(model.getView() instanceof MappingJackson2JsonView)
        {
            if(request.getSession().getAttribute("SPRING_SECURITY_CONTEXT") != null)
            {
                Authentication authentication = ((SecurityContextImpl) request.getSession().getAttribute("SPRING_SECURITY_CONTEXT")).getAuthentication();
                AuthVo authVo = (AuthVo) authentication.getPrincipal();

                HashMap authMap = new HashMap();
                authMap.put("userId", authVo.getUserId());
                authMap.put("userName", authVo.getUserNm());
                authMap.put("roleName", authVo.getRoleName());
                authMap.put("remainTime", request.getSession().getMaxInactiveInterval());

                model.addObject("authVo", authMap);
            }
            else{
                model.addObject("authVo", null);
            }

        }
        LOGGER.debug(request.getRequestURI());
    }
}
