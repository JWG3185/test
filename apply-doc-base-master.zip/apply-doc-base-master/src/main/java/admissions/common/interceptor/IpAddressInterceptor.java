package admissions.common.interceptor;

import admissions.common.auth.AuthService;
import admissions.common.dao.CommonDaoAssistant;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class IpAddressInterceptor implements HandlerInterceptor {
    private static final Logger LOGGER = LoggerFactory.getLogger(IpAddressInterceptor.class);

    AuthService authService;

    public IpAddressInterceptor(AuthService authService)
    {
        this.authService = authService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception
    {
        LOGGER.debug("IpAddressInterceptor.preHandle() / start ");

        boolean result = true;

        if(request.getSession().getAttribute("SPRING_SECURITY_CONTEXT") == null)
        {
            String clientIp = CommonDaoAssistant.getUserIp();
            //IP Check
            boolean isBlockIp = authService.checkBlockingIp(clientIp);
            LOGGER.debug("Query ip result:{}", isBlockIp);

            result = !isBlockIp;
            LOGGER.debug("result:{}", result);
        }

        LOGGER.debug("IpAddressInterceptor.preHandle() / end");

        if(!result)
        {
//            response.sendRedirect("/blockip.html");
            response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE);
            //TODO. Block ip일 때 접근제한에 대한 메세지를 보여줄 수 있도록 json 출력하거나, 아이피 제한 안내 html 페이지로 이동 시켜야 함.
        }

        return result;
    }
}
