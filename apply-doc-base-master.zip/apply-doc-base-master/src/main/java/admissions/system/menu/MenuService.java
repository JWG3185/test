package admissions.system.menu;

import admissions.common.dao.CommonDao;
import admissions.system.menu.vo.MenuFormVo;
import admissions.system.menu.vo.MenuVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class MenuService
{
	@Autowired
	CommonDao commonDao;

	/**
	 * left 메뉴 목록
	 */
	@SuppressWarnings("unchecked")
	public List<MenuVo> selectLeftMenuList(MenuFormVo formVo)
	{
		return (List<MenuVo>) commonDao.selectList("MenuMapper.selectLeftMenuList", formVo);
	}
	/**
	 * 상위 메뉴 목록
	 */
	@SuppressWarnings("unchecked")
	public List<MenuVo> selectTopMenuList(MenuFormVo formVo)
	{
		return (List<MenuVo>) commonDao.selectList("MenuMapper.selectTopMenuList", formVo);
	}
}
