package admissions.system.menu.vo;

import admissions.common.vo.DataDefaultVo;

public class MenuFormVo extends DataDefaultVo
{
	private String upperMenuNo = "";
	private String menuNo = "";
	private String menuNm = "";
	private String menuDivCd = "";
	private String menuDivNm = "";
	private String sortOrder = "";
	private String menuLinkAddress = "";
	private String useYn = "";
	private String displayYn = "Y";
	private String menuLevel = "";
	private String userId = "";
	private String iconCd = "";
	private String menuEngNm = "";

	String vueComponentName = "";
	String topPath = "";

	public String getIconCd() {
		return iconCd;
	}

	public void setIconCd(String iconCd) {
		this.iconCd = iconCd;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMenuDivNm() {
		return menuDivNm;
	}
	public void setMenuDivNm(String menuDivNm) {
		this.menuDivNm = menuDivNm;
	}
	public String getMenuLevel() {
		return menuLevel;
	}
	public void setMenuLevel(String menuLevel) {
		this.menuLevel = menuLevel;
	}
	public String getDisplayYn() {
		return displayYn;
	}
	public void setDisplayYn(String displayYn) {
		this.displayYn = displayYn;
	}
	
	public String getMenuNo() {
		return menuNo;
	}
	public void setMenuNo(String menuNo) {
		this.menuNo = menuNo;
	}
	public String getUpperMenuNo() {
		return upperMenuNo;
	}
	public void setUpperMenuNo(String upperMenuNo) {
		this.upperMenuNo = upperMenuNo;
	}
	public String getMenuNm() {
		return menuNm;
	}
	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}
	public String getMenuDivCd() {
		return menuDivCd;
	}
	public void setMenuDivCd(String menuDivCd) {
		this.menuDivCd = menuDivCd;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getMenuLinkAddress() {
		return menuLinkAddress;
	}
	public void setMenuLinkAddress(String menuLinkAddress) {
		this.menuLinkAddress = menuLinkAddress;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getMenuEngNm() {
		return menuEngNm;
	}

	public void setMenuEngNm(String menuEngNm) {
		this.menuEngNm = menuEngNm;
	}

	public String getTopPath() {
		return topPath;
	}

	public void setTopPath(String topPath) {
		this.topPath = topPath;
	}

	public String getVueComponentName() {
		return vueComponentName;
	}

	public void setVueComponentName(String vueComponentName) {
		this.vueComponentName = vueComponentName;
	}

}
