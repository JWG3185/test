package admissions.system.menu;

import admissions.system.menu.vo.MenuFormVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

@RestController
@RequestMapping("/system/menu/")
public class MenuController
{
	private static final String JSON_VIEW = "jsonView";

	@Autowired
	private MenuService menuService;

	/**
	 * left menu list
	 */
	@PostMapping("selectLeftMenuList.do")
	public ModelAndView selectLeftMenuList(@RequestBody MenuFormVo formVo)
	{
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
		model.addObject("menuList", menuService.selectLeftMenuList(formVo));

		return model;
	}

	/**
	 * upper menu list
	 */
	@PostMapping("selectTopMenuList.do")
	public ModelAndView selectTopMenuList(@RequestBody MenuFormVo formVo)
	{
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
		model.addObject("menuList", menuService.selectTopMenuList(formVo));

		return model;
	}
}
