package admissions.system.code;

import admissions.common.dao.CommonDao;
import admissions.system.code.vo.CodeFormVo;
import admissions.system.code.vo.CodeVo;
import admissions.system.code.vo.UnivVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CodeService
{
	@Autowired
	private CommonDao commonDao;

	/**
	 * ClassCdList
	 */
	@SuppressWarnings("unchecked")
	public List<CodeVo> selectClassCdList(CodeFormVo formVo)
	{
		return (List<CodeVo>) commonDao.selectList("CodeMapper.selectClassCdList", formVo);
	}

	/**
	 * 코드 목록을 리턴한다.
	 */
	@SuppressWarnings("unchecked")
	public List<CodeVo> selectList(CodeFormVo formVo)
	{
		return (List<CodeVo>) commonDao.selectList("CodeMapper.selectList", formVo);
	}

	/**
	 * 부서 코드 목록을 리턴한다.
	 */
	@SuppressWarnings("unchecked")
	public List<CodeVo> selectDeptList(CodeFormVo formVo)
	{
		return (List<CodeVo>) commonDao.selectList("CodeMapper.selectDeptList", formVo);
	}

	/**
	 * 대학의 국가 목록을 리턴한다.
	 */
	@SuppressWarnings("unchecked")
	public List<UnivVo> selectUnivNationList(UnivVo formVo)
	{
		return (List<UnivVo>) commonDao.selectList("CodeMapper.selectUnivNationList", formVo);
	}

	/**
	 * 대학교 / 대학원 목록을 리턴한다.
	 */
	@SuppressWarnings("unchecked")
	public List<UnivVo> selectUnivList(UnivVo formVo)
	{
		return (List<UnivVo>) commonDao.selectList("CodeMapper.selectUnivList", formVo);
	}
}