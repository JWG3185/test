package admissions.system.code.vo;

import admissions.common.vo.DataDefaultVo;

public class CodeFormVo extends DataDefaultVo
{
	private String comClassCd = "";
	private String comClassNm = "";
	private String comCd = "";
	private String cdNm = "";
	private String sortOrder = "";
	private String useYn = "";
	private String connectComCd = "";
	private String connectClassCd = "";
	private String cdEngNm = "";
	private String pagingYn = "N";

	public String getComClassCd() {
		return comClassCd;
	}

	public void setComClassCd(String comClassCd) {
		this.comClassCd = comClassCd;
	}

	public String getComClassNm() {
		return comClassNm;
	}

	public void setComClassNm(String comClassNm) {
		this.comClassNm = comClassNm;
	}

	public String getComCd() {
		return comCd;
	}

	public void setComCd(String comCd) {
		this.comCd = comCd;
	}

	public String getCdNm() {
		return cdNm;
	}

	public void setCdNm(String cdNm) {
		this.cdNm = cdNm;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getConnectComCd() {
		return connectComCd;
	}

	public void setConnectComCd(String connectComCd) {
		this.connectComCd = connectComCd;
	}

	public String getConnectClassCd() {
		return connectClassCd;
	}

	public void setConnectClassCd(String connectClassCd) {
		this.connectClassCd = connectClassCd;
	}

	public String getCdEngNm() {
		return cdEngNm;
	}

	public void setCdEngNm(String cdEngNm) {
		this.cdEngNm = cdEngNm;
	}

	public String getPagingYn() {
		return pagingYn;
	}

	public void setPagingYn(String pagingYn) {
		this.pagingYn = pagingYn;
	}
}