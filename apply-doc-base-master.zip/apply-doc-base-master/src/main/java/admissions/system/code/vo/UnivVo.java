package admissions.system.code.vo;

import admissions.common.vo.DataDefaultVo;

public class UnivVo extends DataDefaultVo {
    private String nationCd = "";
    private String nationEngNm = "";
    private String nationNm = "";
    private String cdNm = "";
    private String cdEngNm = "";
    private String sortOrder = "";
    private String univCd = "";
    private String univNm = "";
    private String univEngNm = "";

    public String getNationCd() {
        return nationCd;
    }

    public void setNationCd(String nationCd) {
        this.nationCd = nationCd;
    }

    public String getNationEngNm() {
        return nationEngNm;
    }

    public void setNationEngNm(String nationEngNm) {
        this.nationEngNm = nationEngNm;
    }

    public String getNationNm() {
        return nationNm;
    }

    public void setNationNm(String nationNm) {
        this.nationNm = nationNm;
    }

    public String getCdNm() {
        return cdNm;
    }

    public void setCdNm(String cdNm) {
        this.cdNm = cdNm;
    }

    public String getCdEngNm() {
        return cdEngNm;
    }

    public void setCdEngNm(String cdEngNm) {
        this.cdEngNm = cdEngNm;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getUnivCd() {
        return univCd;
    }

    public void setUnivCd(String univCd) {
        this.univCd = univCd;
    }

    public String getUnivNm() {
        return univNm;
    }

    public void setUnivNm(String univNm) {
        this.univNm = univNm;
    }

    public String getUnivEngNm() {
        return univEngNm;
    }

    public void setUnivEngNm(String univEngNm) {
        this.univEngNm = univEngNm;
    }
}