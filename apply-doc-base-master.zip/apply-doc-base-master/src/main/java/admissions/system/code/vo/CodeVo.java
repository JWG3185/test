package admissions.system.code.vo;

import admissions.common.vo.DataDefaultVo;

public class CodeVo extends DataDefaultVo
{
	private String comClassCd = "";
	private String comClassNm = "";
	private String comCd = "";
	private String cdNm = "";
	private String sortOrder = "";
	private String useYn = "";
	private String connectComCd = "";
	private String connectClassCd = "";
	private String cdEngNm = "";
	private String pagingYn = "N";
	private String comGroup1Cd = "";
	private String comGroup2Cd = "";
	private String comGroup3Cd = "";

	public String getComGroup1Cd() {
		return comGroup1Cd;
	}

	public void setComGroup1Cd(String comGroup1Cd) {
		this.comGroup1Cd = comGroup1Cd;
	}

	public String getComGroup2Cd() {
		return comGroup2Cd;
	}

	public void setComGroup2Cd(String comGroup2Cd) {
		this.comGroup2Cd = comGroup2Cd;
	}

	public String getComGroup3Cd() {
		return comGroup3Cd;
	}

	public void setComGroup3Cd(String comGroup3Cd) {
		this.comGroup3Cd = comGroup3Cd;
	}

	public String getComClassCd() {
		return comClassCd;
	}

	public void setComClassCd(String comClassCd) {
		this.comClassCd = comClassCd;
	}

	public String getComClassNm() {
		return comClassNm;
	}

	public void setComClassNm(String comClassNm) {
		this.comClassNm = comClassNm;
	}

	public String getComCd() {
		return comCd;
	}

	public void setComCd(String comCd) {
		this.comCd = comCd;
	}

	public String getCdNm() {
		return cdNm;
	}

	public void setCdNm(String cdNm) {
		this.cdNm = cdNm;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getConnectComCd() {
		return connectComCd;
	}

	public void setConnectComCd(String connectComCd) {
		this.connectComCd = connectComCd;
	}

	public String getConnectClassCd() {
		return connectClassCd;
	}

	public void setConnectClassCd(String connectClassCd) {
		this.connectClassCd = connectClassCd;
	}

	public String getCdEngNm() {
		return cdEngNm;
	}

	public void setCdEngNm(String cdEngNm) {
		this.cdEngNm = cdEngNm;
	}

	public String getPagingYn() {
		return pagingYn;
	}

	public void setPagingYn(String pagingYn) {
		this.pagingYn = pagingYn;
	}
}