package admissions.system.code;

import admissions.common.vo.PaginationVo;
import admissions.system.code.vo.UnivVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.util.List;

@Controller
@RequestMapping("/code/")
public class CodeController
{
	private static final String JSON_VIEW = "jsonView";

	@Autowired
    CodeService codeService;

	/**
	 * 대학의 국가 목록
	 */
	@PostMapping("selectUnivNationList.do")
	public ModelAndView selectUnivNationList(@RequestBody UnivVo formVo) {
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
		model.addObject("univNationList", codeService.selectUnivNationList(formVo));
		return model;
	}

	/**
	 * 대학 목록
	 */
	@PostMapping("selectUnivList.do")
	public ModelAndView selectUnivList(@RequestBody UnivVo formVo)
	{
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
		List<UnivVo> univList = codeService.selectUnivList(formVo);
		model.addObject("univList", univList);

		PaginationVo pagination = new PaginationVo();
		pagination.setList(univList, formVo.getCountPerPage());
		pagination.setCurrentPage(formVo.getPageNo());
		model.addObject("pagination", pagination);

		return model;
	}

}
