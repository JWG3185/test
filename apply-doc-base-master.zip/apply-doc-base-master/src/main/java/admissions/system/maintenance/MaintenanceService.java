package admissions.system.maintenance;

import admissions.common.dao.CommonDao;
import admissions.system.maintenance.vo.MaintenaceVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author
 */
@Service
public class MaintenanceService
{

	private static final Logger LOGGER = LoggerFactory.getLogger(MaintenanceService.class);
	@Autowired
	CommonDao commonDao;

	public MaintenaceVo select(){
		return (MaintenaceVo) commonDao.selectOne("MaintenanceMapper.select");
	}
}
