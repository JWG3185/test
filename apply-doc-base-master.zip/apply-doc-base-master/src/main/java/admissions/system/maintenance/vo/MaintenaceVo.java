package admissions.system.maintenance.vo;

import admissions.common.vo.DataDefaultVo;

public class MaintenaceVo extends DataDefaultVo {
  private String maintenanceYn = "";
  private String maintenanceStartDt = "";
  private String maintenanceStartTm = "";
  private String maintenanceEndDt = "";
  private String maintenanceEndTm = "";
  private String fileGroupNo = "";

  public String getMaintenanceYn() {
    return maintenanceYn;
  }

  public void setMaintenanceYn(String maintenanceYn) {
    this.maintenanceYn = maintenanceYn;
  }

  public String getMaintenanceStartDt() {
    return maintenanceStartDt;
  }

  public void setMaintenanceStartDt(String maintenanceStartDt) {
    this.maintenanceStartDt = maintenanceStartDt;
  }

  public String getMaintenanceStartTm() {
    return maintenanceStartTm;
  }

  public void setMaintenanceStartTm(String maintenanceStartTm) {
    this.maintenanceStartTm = maintenanceStartTm;
  }

  public String getMaintenanceEndDt() {
    return maintenanceEndDt;
  }

  public void setMaintenanceEndDt(String maintenanceEndDt) {
    this.maintenanceEndDt = maintenanceEndDt;
  }

  public String getMaintenanceEndTm() {
    return maintenanceEndTm;
  }

  public void setMaintenanceEndTm(String maintenanceEndTm) {
    this.maintenanceEndTm = maintenanceEndTm;
  }

  public String getFileGroupNo() {
    return fileGroupNo;
  }

  public void setFileGroupNo(String fileGroupNo) {
    this.fileGroupNo = fileGroupNo;
  }
}
