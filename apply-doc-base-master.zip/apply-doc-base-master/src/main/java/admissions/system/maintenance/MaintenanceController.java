package admissions.system.maintenance;

import admissions.system.maintenance.vo.MaintenaceVo;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.io.IOException;

@RestController
@RequestMapping("/system/maintenance")
public class MaintenanceController
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MaintenanceController.class);
	private static final String JSON_VIEW = "jsonView";

	@Autowired
	private MaintenanceService maintenanceService;

	@PostMapping("/maintenance.do")
	public ModelAndView maintenanceInfo()
			throws IOException {
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
		MaintenaceVo maintenance = maintenanceService.select();

		if(ObjectUtils.isNotEmpty(maintenance))
		{
			model.addObject(maintenance);
		}

		return model;
	}
}
