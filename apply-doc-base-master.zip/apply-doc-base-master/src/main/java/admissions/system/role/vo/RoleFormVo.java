package admissions.system.role.vo;

import admissions.common.vo.DataDefaultVo;

public class RoleFormVo extends DataDefaultVo
{
	private String roleCd = "";
	private String roleNm = "";
	private String menuNo = "";
	private String userId = "";
	private String internalIpYn = "";
	private String checked = "";
	private String userCnt = "";
	private String menuCnt = "";

	public String getInternalIpYn() {
		return internalIpYn;
	}

	public void setInternalIpYn(String internalIpYn) {
		this.internalIpYn = internalIpYn;
	}

	public String getUserCnt() {
		return userCnt;
	}

	public void setUserCnt(String userCnt) {
		this.userCnt = userCnt;
	}

	public String getMenuCnt() {
		return menuCnt;
	}

	public void setMenuCnt(String menuCnt) {
		this.menuCnt = menuCnt;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getChecked() {
		return checked;
	}
	public void setChecked(String checked) {
		this.checked = checked;
	}
	public String getMenuNo() {
		return menuNo;
	}
	public void setMenuNo(String menuNo) {
		this.menuNo = menuNo;
	}
	public String getRoleCd() {
		return roleCd;
	}
	public void setRoleCd(String roleCd) {
		this.roleCd = roleCd;
	}
	public String getRoleNm() {
		return roleNm;
	}
	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}


}
