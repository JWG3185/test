package admissions.system.role;

import admissions.common.dao.CommonDao;
import admissions.system.role.vo.RoleFormVo;
import admissions.system.role.vo.RoleVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
public class RoleService
{
    @Autowired
    CommonDao commonDao;

    /**
     * Role 목록
     */
    @SuppressWarnings("unchecked")
    public List<RoleVo> selectList(RoleFormVo formVo) {
        return (List<RoleVo>) commonDao.selectList("RoleMapper.selectList", formVo);
    }


    /**
     * Role 수정
     */
    @Transactional
    public void updateList(List<RoleFormVo> formList)
    {
		for(RoleFormVo formVo : formList)
		{
			commonDao.update("RoleMapper.update", formVo);
		}
    }

    /**
     * Role 목록삭제
     */
    @Transactional
    public void deleteList(RoleFormVo formVo)
    {
        commonDao.delete("RoleMapper.deleteMenuList", formVo);
        commonDao.delete("RoleMapper.deleteUserList", formVo);
        commonDao.delete("RoleMapper.deleteList", formVo);
    }
}
