package admissions.system.loginlog;

import admissions.common.dao.CommonDao;
import admissions.system.loginlog.vo.LoginLogFormVo;
import admissions.system.loginlog.vo.LoginLogVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class LoginLogService
{
	@Autowired
	CommonDao commonDao;

	/**
	 * LoginLog List
	 */
	@SuppressWarnings("unchecked")
	public List<LoginLogVo> selectList(LoginLogFormVo formVo)
	{
		return (List<LoginLogVo>) commonDao.selectList("LoginLogMapper.selectList", formVo);
	}
}
