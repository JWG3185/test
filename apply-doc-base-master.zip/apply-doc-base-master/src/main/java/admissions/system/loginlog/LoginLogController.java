package admissions.system.loginlog;

import admissions.common.vo.PaginationVo;
import admissions.system.loginlog.vo.LoginLogFormVo;
import admissions.system.loginlog.vo.LoginLogVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.util.List;

@RestController
@RequestMapping("/system/loginLog/")
public class LoginLogController
{
	@Autowired
	LoginLogService loginLogService;
	
	/**
	 * LoginLog selectList
	 */
	@PostMapping("selectList.do")
	public ModelAndView selectList(@RequestBody LoginLogFormVo formVo)
	{
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
		List<LoginLogVo> loginLogList = loginLogService.selectList(formVo);
		model.addObject("loginLogList", loginLogList);

		PaginationVo pagination = new PaginationVo();
		pagination.setList(loginLogList, formVo.getCountPerPage());
		pagination.setCurrentPage(formVo.getPageNo());
		model.addObject("pagination", pagination);
		
		return model;
	}
}