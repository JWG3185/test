package admissions.system.loginlog.vo;

import admissions.common.vo.DataDefaultVo;

public class LoginLogVo extends DataDefaultVo
{
	private String loginLogNo = "";
	private String loginDt = "";
	private String loginTms = "";
	private String loginId = "";
	private String loginIp = "";
	private String loginYn = "";
	private String loginRsltContents = "";
	private String loginHeaderInfo = "";
	private String systemDivCd = "";
	private String systemDivisionContent = "";

	public String getLoginLogNo() {
		return loginLogNo;
	}
	public void setLoginLogNo(String loginLogNo) {
		this.loginLogNo = loginLogNo;
	}
	public String getLoginDt() {
		return loginDt;
	}
	public void setLoginDt(String loginDt) {
		this.loginDt = loginDt;
	}
	public String getLoginTms() {
		return loginTms;
	}
	public void setLoginTms(String loginTms) {
		this.loginTms = loginTms;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getLoginIp() {
		return loginIp;
	}
	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}
	public String getLoginYn() {
		return loginYn;
	}
	public void setLoginYn(String loginYn) {
		this.loginYn = loginYn;
	}
	public String getLoginRsltContents() { return loginRsltContents; }
	public void setLoginRsltContents(String loginRsltContents) { this.loginRsltContents = loginRsltContents; }
	public String getLoginHeaderInfo() { return loginHeaderInfo; }
	public void setLoginHeaderInfo(String loginHeaderInfo) { this.loginHeaderInfo = loginHeaderInfo; }

	public String getSystemDivisionContent() { return systemDivisionContent; }
	public void setSystemDivisionContent(String systemDivisionContent) { this.systemDivisionContent = systemDivisionContent; }

	public String getSystemDivCd() {
		return systemDivCd;
	}

	public void setSystemDivCd(String systemDivCd) {
		this.systemDivCd = systemDivCd;
	}
}
