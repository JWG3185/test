package admissions.system.loginlog.vo;

import admissions.common.vo.DataDefaultVo;

public class LoginLogFormVo extends DataDefaultVo
{
	private String loginLogNo = "";
	private String loginDt = "";
	private String loginTm = "";
	private String loginId = "";
	private String loginIp = "";
	private String loginYn = "";
	private String loginResult = "";
	private String systemDivisionCode = "";
	
	private String startDt = "";
	private String endDt = "";
	
	public String getLoginLogNo() {
		return loginLogNo;
	}
	public void setLoginLogNo(String loginLogNo) {
		this.loginLogNo = loginLogNo;
	}
	public String getLoginDt() {
		return loginDt;
	}
	public void setLoginDt(String loginDt) {
		this.loginDt = loginDt;
	}
	public String getLoginTm() {
		return loginTm;
	}
	public void setLoginTm(String loginTm) {
		this.loginTm = loginTm;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getLoginIp() {
		return loginIp;
	}
	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}
	public String getLoginYn() {
		return loginYn;
	}
	public void setLoginYn(String loginYn) {
		this.loginYn = loginYn;
	}
	public String getLoginResult() {
		return loginResult;
	}
	public void setLoginResult(String loginResult) {
		this.loginResult = loginResult;
	}
	public String getStartDt() {
		return startDt.replaceAll("-", "");
	}
	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}
	public String getEndDt() {
		return endDt.replaceAll("-", "");
	}
	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}

	public String getSystemDivisionCode() { return systemDivisionCode; }
	public void setSystemDivisionCode(String systemDivisionCode) { this.systemDivisionCode = systemDivisionCode; }
}
