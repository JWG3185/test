package admissions.system.user.vo;

import admissions.common.vo.DataDefaultVo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UserFormVo extends DataDefaultVo {
    private String userNo = "";
    private String roleCd = "";
    private String userId = "";
    private String userNm = "";
    private String userPassword = "";
    private String mobileNo = "";
    private String emailAddress = "";
    private String birthDt = "";

    //이메일주소 인증관련
    private String emailCertCd = "";
    private String certValidDate = "";
    private String certYn = "";
    private String individualinfoAgreeYn = "";
    private String marketingAgreeYn = "";
    private String countryCd = "";
    private List<String> checkedList = new ArrayList<String>();
    private String naverConnect = "";
    private String kakaoConnect = "";
    private String googleConnect = "";
    private String naverConnectDate = "";
    private String kakaoConnectDate = "";
    private String googleConnectDate = "";
    private String engFirstNm = "";
    private String engMiddleNm = "";
    private String engFamilyNm = "";
//    private String locale = "";
    // 구글 리캡챠 관련
    private String response = "";

    public String getNaverConnect() {
        return naverConnect;
    }

    public void setNaverConnect(String naverConnect) {
        this.naverConnect = naverConnect;
    }

    public String getKakaoConnect() {
        return kakaoConnect;
    }

    public void setKakaoConnect(String kakaoConnect) {
        this.kakaoConnect = kakaoConnect;
    }

    public String getGoogleConnect() {
        return googleConnect;
    }

    public void setGoogleConnect(String googleConnect) {
        this.googleConnect = googleConnect;
    }

    public String getNaverConnectDate() { return naverConnectDate; }

    public void setNaverConnectDate(String naverConnectDate) { this.naverConnectDate = naverConnectDate; }

    public String getKakaoConnectDate() { return kakaoConnectDate; }

    public void setKakaoConnectDate(String kakaoConnectDate) { this.kakaoConnectDate = kakaoConnectDate; }

    public String getGoogleConnectDate() { return googleConnectDate; }

    public void setGoogleConnectDate(String googleConnectDate) { this.googleConnectDate = googleConnectDate; }

    public String getMarketingAgreeYn() {
        return marketingAgreeYn;
    }

    public void setMarketingAgreeYn(String marketingAgreeYn) {
        this.marketingAgreeYn = marketingAgreeYn;
    }

    public String getIndividualinfoAgreeYn() {
        return individualinfoAgreeYn;
    }

    public void setIndividualinfoAgreeYn(String individualinfoAgreeYn) {
        this.individualinfoAgreeYn = individualinfoAgreeYn;
    }

    public String getCertValidDate() {
        return certValidDate;
    }

    public void setCertValidDate(String certValidDate) {
        this.certValidDate = certValidDate;
    }

    public String getCertYn() {
        return certYn;
    }

    public void setCertYn(String certYn) {
        this.certYn = certYn;
    }

    public String getEmailCertCd() {
        return emailCertCd;
    }

    public void setEmailCertCd(String emailCertCd) {
        this.emailCertCd = emailCertCd;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserNm() {
        return userNm;
    }

    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getCountryCd() {
        return countryCd;
    }

    public void setCountryCd(String countryCd) {
        this.countryCd = countryCd;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getBirthDt() {
        return birthDt;
    }

    public void setBirthDt(String birthDt) {
        this.birthDt = birthDt;
    }

    public String getRoleCd() {
        return roleCd;
    }

    public void setRoleCd(String roleCd) {
        this.roleCd = roleCd;
    }

    @Override
    public List<String> getCheckedList() {
        return Collections.unmodifiableList(checkedList);
    }

    @Override
    public void setCheckedList(List<String> checkedList) {
        this.checkedList = Collections.unmodifiableList(checkedList);
    }

    public String getEngFirstNm() {
        return engFirstNm;
    }

    public void setEngFirstNm(String engFirstNm) {
        this.engFirstNm = engFirstNm;
    }

    public String getEngMiddleNm() {
        return engMiddleNm;
    }

    public void setEngMiddleNm(String engMiddleNm) {
        this.engMiddleNm = engMiddleNm;
    }

    public String getEngFamilyNm() {
        return engFamilyNm;
    }

    public void setEngFamilyNm(String engFamilyNm) {
        this.engFamilyNm = engFamilyNm;
    }

//    public String getLocale() {
//        return locale;
//    }

//    public void setLocale(String locale) {
//        this.locale = locale;
//    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    @Override
    public String toString() {
        return "UserFormVo{" +
                "userNo='" + userNo + '\'' +
                ", roleCd='" + roleCd + '\'' +
                ", userId='" + userId + '\'' +
                ", userNm='" + userNm + '\'' +
                ", userPassword='" + userPassword + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                ", emailAddress='" + emailAddress + '\'' +
                ", birthDt='" + birthDt + '\'' +
                ", emailCertCd='" + emailCertCd + '\'' +
                ", certValidDate='" + certValidDate + '\'' +
                ", certYn='" + certYn + '\'' +
                ", individualinfoAgreeYn='" + individualinfoAgreeYn + '\'' +
                ", marketingAgreeYn='" + marketingAgreeYn + '\'' +
                ", countryCd='" + countryCd + '\'' +
                ", checkedList=" + checkedList +
                ", naverConnect='" + naverConnect + '\'' +
                ", kakaoConnect='" + kakaoConnect + '\'' +
                ", googleConnect='" + googleConnect + '\'' +
                ", engFirstNm='" + engFirstNm + '\'' +
                ", engMiddleNm='" + engMiddleNm + '\'' +
                ", engFamilyNm='" + engFamilyNm + '\'' +
                ", lastUpdateUserId='" + getLastUpdateUserId() + '\'' +
                ", lastUpdateProgramId='" + getLastUpdateProgramId() + '\'' +
                ", lastUpdateUserIp='" + getLastUpdateUserIp() + '\'' +
                ", lastUpdateDate='" + getLastUpdateDate() + '\'' +
                '}';
    }
}