package admissions.system.user;

import admissions.common.auth.AuthService;
import admissions.system.user.vo.UserFormVo;
import admissions.system.user.vo.UserVo;
import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.io.IOException;

@RestController
@RequestMapping("/system/user/")
public class UserController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private AuthService authService;

    @Value("${reCAPTCHA.sitekey}")
    private String sitekey;

    /**
     * select user
     */
    @PostMapping("selectOne.do")
    public ModelAndView selectOne(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        UserVo user = (UserVo) userService.selectUser(formVo);
        model.addObject("user", user);
        return model;
    }

    /**
     * find id
     */
    @PostMapping("findId.do")
    public ModelAndView findId(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        UserFormVo vo = userService.findId(formVo);
        if (vo != null) {
            model.addObject("userId", vo.getUserId());
        }
        return model;
    }

    /**
     * find password
     *
     * @throws IOException
     * @throws MessagingException
     */
    @PostMapping("findPassword.do")
    public ModelAndView findPassword(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        Boolean result = false;
        UserFormVo user = userService.findUser(formVo);
        if (user != null) {
            try {
                //user.setLocale(formVo.getLocale());
                user.setFirstRegistProgramId(formVo.getFirstRegistProgramId());
                userService.findPassword(user);
                result = true;
            } catch (MessagingException | IOException e) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error(e.getMessage().replaceAll("[\r\n]", ""));
                }
            }
        }
        model.addObject("result", result);
        return model;
    }

    /**
     * user create
     */
    @PostMapping("insert.do")
    public ModelAndView insert(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        userService.insert(formVo);

        return model;
    }

    /**
     * user info edit
     */
    @PostMapping("updateInfo.do")
    public ModelAndView updateInfo(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        userService.updateInfo(formVo);

        return model;
    }

    /**
     * user id(email) edit
     */
    @PostMapping("updateId.do")
    public ModelAndView updateId(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        userService.updateId(formVo);

        return model;
    }

    /**
     * user password 체크
     */
    @PostMapping("passwordMatch.do")
    public ModelAndView passwordCheck(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("result", userService.passwordMatch(formVo));

        return model;
    }

    /**
     * user password edit
     */
    @PostMapping("updatePassword.do")
    public ModelAndView updatePassword(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        userService.updatePassword(formVo);

        return model;
    }

    /**
     * 사용자 삭제
     *
     * @param formVo
     */
    @PostMapping("deleteUser.do")
    public ModelAndView deleteUser(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        userService.deleteUser(formVo);
        return model;
    }

    /**
     * 이메일주소 인증메일 발송요청
     */
    @PostMapping("sendValidEmailAddress.do")
    public ModelAndView sendValidEmailAddress(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        UserFormVo vo = userService.sendValidEmailAddress(formVo);
        model.addObject("certValidDate", vo.getCertValidDate());
        return model;
    }

    /**
     * 이메일주소 인증번호 검증
     */
    @PostMapping("validEmailAddressText.do")
    public ModelAndView validEmailAddressText(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        UserFormVo vo = userService.validEmailAddressText(formVo);
        model.addObject("certYn", vo.getCertYn());
        model.addObject("emailAddress", vo.getEmailAddress());
        return model;
    }

    /**
     * 이메일 인증여부 검사
     */
    @PostMapping("validEmailAddress.do")
    public ModelAndView validEmailAddress(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("validYn", authService.checkEmailValid(formVo.getEmailAddress()));
        return model;
    }

    /**
     * 네이버 키 유효검사
     */
    @PostMapping("validKey.do")
    public ModelAndView validKey(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("validYn", userService.validKey(formVo));
        return model;
    }

    /**
     * 구글 리캡챠 사이트 키 조회
     */
    @PostMapping("selectCaptchaSitekey.do")
    public ModelAndView selectCaptchaSitekey() {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("sitekey", sitekey);
        return model;
    }

    /**
     * 구글 리캡챠 유효성 검사
     */
    @PostMapping("checkRecaptcha.do")
    public ModelAndView checkRecaptcha(@RequestBody UserFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("captchaData", userService.checkRecaptcha(formVo));
        return model;
    }
}
