package admissions.system.user;

import admissions.common.dao.CommonDao;
import admissions.common.mail.MailService;
import admissions.common.mail.vo.ComTransferEmailReceiverVo;
import admissions.common.mail.vo.ComTransferEmailVo;
import admissions.system.user.vo.UserFormVo;
import admissions.system.user.vo.UserVo;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.UUID.randomUUID;

/**
 * @author
 */
@Service
public class UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
    @Autowired
    CommonDao commonDao;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    MailService mailService;

    @Value("${proxy.url}")
    String proxyUrl;

    String dsptchEmlAddr = "help_adm@osolit.net";
    String dsptchUserNm = "UST사용자서비스";
    String groupEmlYn = "N";

    @Value("${reCAPTCHA.secret}")
    private String secret;

    @Value("${reCAPTCHA.url}")
    private String captchaUrl;

    /**
     * User 조회
     */
    public UserVo selectUser(UserFormVo formVo) {
        return (UserVo) commonDao.selectOne("UserMapper.selectUser", formVo);
    }

    /**
     * User 조회
     */
    public UserVo selectUserIdByKey(UserFormVo formVo) {
        return (UserVo) commonDao.selectOne("UserMapper.selectUserIdByKey", formVo);
    }

    /**
     * User 찾기
     */
    public UserFormVo findUser(UserFormVo formVo) {
        return (UserFormVo) commonDao.selectOne("UserMapper.findUser", formVo);
    }

    /**
     * User ID 찾기
     */
    public UserFormVo findId(UserFormVo formVo) {
        return (UserFormVo) commonDao.selectOne("UserMapper.findId", formVo);
    }

    /**
     * User Password 찾기
     *
     * @throws IOException
     * @throws MessagingException
     */
    @Transactional
    public void findPassword(UserFormVo formVo) throws MessagingException, IOException {
        // 임시 비밀번호 생성(UUID이용)
        String tempPw = randomUUID().toString().replace("-", "");//-를 제거
        //String locale = formVo.getLocale();
        tempPw = tempPw.substring(0, 10);
        // 임시 비밀번호로 변경
        formVo.setUserPassword(passwordEncoder.encode(tempPw));
        commonDao.update("UserMapper.updatePassword", formVo);


        // 메읿 발송 프로세스
        // String emlTitle = "ko".equals(locale) ? "UST 사용자 비밀번호 찾기" : "UST Find User Password";
        String emlTitle = "UST Find User Password";

        ComTransferEmailVo mailVo = new ComTransferEmailVo();
        mailVo.setEmailTitle(emlTitle);
        mailVo.setSenderEmailAddress(dsptchEmlAddr);
        mailVo.setSenderNm(dsptchUserNm);
        mailVo.setMultimailYn(groupEmlYn);
        mailVo.setSendRequestId(formVo.getEmailAddress());
        mailVo.setFirstRegistUserId(formVo.getEmailAddress());
        mailVo.setFirstRegistUserIp(formVo.getFirstRegistUserIp());
        mailVo.setFirstRegistProgramId(formVo.getFirstRegistProgramId());

        // 발신 내용 설정
        HashMap<String, String> contentMap = new HashMap<String, String>();
        contentMap.put("proxyUrl", proxyUrl);
        // contentMap.put("locale", locale);
        contentMap.put("password", tempPw);
        mailVo.setContentMap(contentMap);

        // 수신 설정
        List<ComTransferEmailReceiverVo> recipientList = new ArrayList<ComTransferEmailReceiverVo>();
        ComTransferEmailReceiverVo recipientVo = new ComTransferEmailReceiverVo();
        recipientVo.setReceiverNm(formVo.getUserNm());
        recipientVo.setReceiverEmailAddress(formVo.getEmailAddress());
        recipientVo.setReceiveTypeCd("R");
        // 수신 목록 세팅
        recipientList.add(recipientVo);
        mailVo.setRecipientList(recipientList);

        // 메일 정보 입력
        int pkEmailSendng = mailService.insertMailInfo(mailVo, "mail/findPassword");

        //이메일 발송
        mailService.sendEmail(String.valueOf(pkEmailSendng));
    }

    /**
     * User 등록
     */
    @Transactional
    public void insert(UserFormVo formVo) {
        formVo.setUserPassword(passwordEncoder.encode(formVo.getUserPassword()));
        formVo.setBirthDt(formVo.getBirthDt().replaceAll("-", ""));
        commonDao.insert("UserMapper.insert", formVo);

        if (!formVo.getKakaoConnect().isEmpty() || !formVo.getGoogleConnect().isEmpty() || !formVo.getNaverConnect().isEmpty())
        {
            commonDao.update("UserMapper.update", formVo);
        }

        UserVo vo= (UserVo) commonDao.selectOne("UserMapper.selectUser", formVo);

        UserFormVo logVo= new UserFormVo();
        BeanUtils.copyProperties(vo, logVo);
        logVo.setFirstRegistProgramId(formVo.getFirstRegistProgramId());
        commonDao.insert("UserMapper.updateIdLog", logVo);

    }

    /**
     * User 소셜 로그인 연동
     */
    @Transactional
    public void update(UserFormVo formVo) {
        formVo.setBirthDt(formVo.getBirthDt().replaceAll("-", ""));
        commonDao.update("UserMapper.update", formVo);
    }

    /**
     * User 소셜 로그인 연동 취소
     */
    @Transactional
    public void cancelSocialAccount(UserFormVo formVo) {
        commonDao.update("UserMapper.cancelSocialAccount", formVo);
    }

    /**
     * User Info 수정
     */
    @Transactional
    public void updateInfo(UserFormVo formVo) {
        commonDao.update("UserMapper.updateInfo", formVo);
    }

    /**
     * User Id(email) 수정
     */
    @Transactional
    public void updateId(UserFormVo formVo) {
        commonDao.insert("UserMapper.updateIdLog", formVo);
        commonDao.update("UserMapper.updateId", formVo);
    }

    /**
     * User Password 체크
     */
    @Transactional
    public Boolean passwordMatch(UserFormVo formVo) {
        UserFormVo vo = (UserFormVo) commonDao.selectOne("UserMapper.selectPassword", formVo);
        return passwordEncoder.matches(formVo.getUserPassword(), vo.getUserPassword());
    }

    /**
     * User Password 수정
     */
    @Transactional
    public void updatePassword(UserFormVo formVo) {
        formVo.setUserPassword(passwordEncoder.encode(formVo.getUserPassword()));
        commonDao.update("UserMapper.updatePassword", formVo);
    }

    /**
     * User Delete
     */
    public void deleteUser(UserFormVo formVo) {
        commonDao.delete("UserMapper.deleteUser", formVo);
    }

    /**
     * 이메일주소 인증메일 발송
     */
    @Transactional
    public UserFormVo sendValidEmailAddress(UserFormVo formVo)
    {
        UserFormVo retrurnVo = new UserFormVo();

        int duplicateCount = (int) commonDao.selectOne("UserMapper.selectDuplicateEmailCount", formVo);
        if(duplicateCount > 0)
        {
            retrurnVo.setCertValidDate("duplicate");
        }
        else
        {
            String emailCertCd = "NOALGORITHM";
            try {
                SecureRandom ran = SecureRandom.getInstanceStrong();
                int randomInt = ran.nextInt(1000000);
                emailCertCd = String.valueOf(randomInt);
                formVo.setEmailCertCd(emailCertCd);

                int certCount = (int) commonDao.selectOne("UserMapper.selectCertEmailCount", formVo);
                if(certCount > 0)
                {
                    commonDao.update("UserMapper.updateValidText", formVo);
                }
                else{
                    commonDao.insert("UserMapper.insertValidText", formVo);
                }

                //Send a mail
                retrurnVo = sendValidEmail(formVo);
            }
            catch (NoSuchAlgorithmException e)
            {
                e.printStackTrace();
            }

        }
        return retrurnVo;
    }

    @Transactional
    public UserFormVo sendValidEmail(UserFormVo formVo)
    {
        UserFormVo resultVo = (UserFormVo) commonDao.selectOne("UserMapper.selectValidDate", formVo);

        //이메일 발송 정보
        String emlTitle = "Member registration email address authentication";

        ComTransferEmailVo comTransferEmailVo = new ComTransferEmailVo();
        comTransferEmailVo.setEmailTitle(emlTitle);

        // Content 추가
        HashMap<String, String> contentMap = new HashMap<String, String>();
        contentMap.put("proxyUrl", proxyUrl);
        contentMap.put("emailCertCd", resultVo.getEmailCertCd());

        comTransferEmailVo.setContentMap(contentMap);
        comTransferEmailVo.setSenderEmailAddress(dsptchEmlAddr);
        comTransferEmailVo.setSenderNm(dsptchUserNm);
        comTransferEmailVo.setMultimailYn(groupEmlYn);
        comTransferEmailVo.setSendRequestId(formVo.getUserId());
        comTransferEmailVo.setFirstRegistProgramId(formVo.getFirstRegistProgramId());

        List<ComTransferEmailReceiverVo> receiverVoList = new ArrayList<ComTransferEmailReceiverVo>();
        ComTransferEmailReceiverVo comTransferEmailReceiverVo = new ComTransferEmailReceiverVo();
        if ("".equals(formVo.getUserNm())) {
            comTransferEmailReceiverVo.setReceiverNm(formVo.getEngFirstNm() + formVo.getEngMiddleNm() + formVo.getEngFamilyNm());
        } else {
            comTransferEmailReceiverVo.setReceiverNm(formVo.getUserNm());
        }
        comTransferEmailReceiverVo.setReceiverEmailAddress(formVo.getEmailAddress());
        comTransferEmailReceiverVo.setReceiveTypeCd("R");
        receiverVoList.add(comTransferEmailReceiverVo);
        comTransferEmailVo.setRecipientList(receiverVoList);

        int pkEmailSending = mailService.insertMailInfo(comTransferEmailVo, "mail/sendCertNo");

        //이메일 발송
        mailService.sendEmail(String.valueOf(pkEmailSending));

        return resultVo;
    }


    /**
     * 이메일인증 검증
     */
    @Transactional
    public UserFormVo validEmailAddressText(UserFormVo formVo) {
        commonDao.update("UserMapper.updateValidResult", formVo);

        return (UserFormVo) commonDao.selectOne("UserMapper.selectValidDate", formVo);
    }

    public String validKey(UserFormVo formVo) {
        return (String) commonDao.selectOne("UserMapper.validKey", formVo);
    }

    /**
     * 구글 리캡챠 유효성 검사
     */
    @Transactional
    public Map<String, Object> checkRecaptcha(UserFormVo formVo) {
        Map<String, Object> responseObject = new HashMap<>();

        try {
            URL url = new URL(captchaUrl);

            String postData = "secret=" + secret + "&response=" + formVo.getResponse();

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length", Integer.toString(postData.length()));
            conn.setUseCaches(false);

            try (DataOutputStream dos = new DataOutputStream(conn.getOutputStream())) {
                dos.writeBytes(postData);
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                StringBuilder responseStringBuilder = new StringBuilder();
                String line;

                while ((line = br.readLine()) != null) {
                    responseStringBuilder.append(line);
                }

                // JSON 문자열을 자바 객체로 변환
                ObjectMapper objectMapper = new ObjectMapper();
                responseObject = objectMapper.readValue(responseStringBuilder.toString(), Map.class);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return responseObject;
    }

    @Transactional
    public String insertValidEmailAddress(UserFormVo formVo) {
        String emailCertCd = "NOALGORITHM";
        try {
            SecureRandom ran = SecureRandom.getInstanceStrong();
            int randomInt = ran.nextInt(1000000);
            emailCertCd = String.valueOf(randomInt);
            formVo.setEmailCertCd(emailCertCd);

            int certCount = (int) commonDao.selectOne("UserMapper.selectCertEmailCount", formVo);
            if(certCount > 0)
            {
                commonDao.update("UserMapper.updateValidText", formVo);
            }
            else{
                commonDao.insert("UserMapper.insertValidText", formVo);
            }

        } catch (java.security.NoSuchAlgorithmException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage().replaceAll("[\r\n]", ""));
            }
        }

        return emailCertCd;
    }
}
