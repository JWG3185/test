package admissions.system.user.vo;

import admissions.common.vo.DataDefaultVo;

public class UserVo extends DataDefaultVo
{
	private String userNo = "";
	private String userId = "";
	private String userNm = "";
	private String mobileNo = "";
	private String telNo = "";
	private String emailAddress = "";
	private String birthDt = "";
	private String roleNm = "";
	private String profDiv = "";
	private String profDivNm = "";

	private String engFirstNm = "";
	private String engMiddleNm = "";
	private String engFamilyNm = "";

	private String naverConnect = "";
	private String kakaoConnect = "";
	private String googleConnect = "";
	private String naverConnectDate = "";
	private String kakaoConnectDate = "";
	private String googleConnectDate = "";



	public String getTelNo() {
		return telNo;
	}

	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getBirthDt() {
		return birthDt;
	}
	public void setBirthDt(String birthDt) {
		this.birthDt = birthDt;
	}
	public String getRoleNm() {
		return roleNm;
	}
	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}
	public String getProfDiv() {
		return profDiv;
	}
	
	public void setProfDiv(String profDiv) {
		this.profDiv = profDiv;
	}

	public String getProfDivNm() {
		return profDivNm;
	}
	public void setProfDivNm(String profDivNm) {
		this.profDivNm = profDivNm;
	}

	public String getEngFirstNm() {
		return engFirstNm;
	}

	public void setEngFirstNm(String engFirstNm) {
		this.engFirstNm = engFirstNm;
	}

	public String getEngMiddleNm() {
		return engMiddleNm;
	}

	public void setEngMiddleNm(String engMiddleNm) {
		this.engMiddleNm = engMiddleNm;
	}

	public String getEngFamilyNm() {
		return engFamilyNm;
	}

	public void setEngFamilyNm(String engFamilyNm) {
		this.engFamilyNm = engFamilyNm;
	}

	public String getUserNo() {
		return userNo;
	}

	public void setUserNo(String userNo) {
		this.userNo = userNo;
	}

	public String getNaverConnect() {
		return naverConnect;
	}

	public void setNaverConnect(String naverConnect) {
		this.naverConnect = naverConnect;
	}

	public String getKakaoConnect() {
		return kakaoConnect;
	}

	public void setKakaoConnect(String kakaoConnect) {
		this.kakaoConnect = kakaoConnect;
	}

	public String getGoogleConnect() {
		return googleConnect;
	}

	public void setGoogleConnect(String googleConnect) {
		this.googleConnect = googleConnect;
	}

	public String getNaverConnectDate() { return naverConnectDate; }

	public void setNaverConnectDate(String naverConnectDate) { this.naverConnectDate = naverConnectDate; }

	public String getKakaoConnectDate() { return kakaoConnectDate; }

	public void setKakaoConnectDate(String kakaoConnectDate) { this.kakaoConnectDate = kakaoConnectDate; }

	public String getGoogleConnectDate() { return googleConnectDate; }

	public void setGoogleConnectDate(String googleConnectDate) { this.googleConnectDate = googleConnectDate; }
}
