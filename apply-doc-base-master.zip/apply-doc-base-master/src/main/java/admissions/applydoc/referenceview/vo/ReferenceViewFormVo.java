package admissions.applydoc.referenceview.vo;

import admissions.common.vo.DataDefaultVo;

public class ReferenceViewFormVo extends DataDefaultVo {
	private String recruitYear = "";
	private String recruitPeriodCd = "";
	private String recruitDegree = "";
	private String screenClassCd = "";
	private String recruitScreenCd = "";
	private String campusSchoolCd = "";
	private String recruitMajorCd = "";
	private String detailMajorCd = "";
	private String supportDegreeCd = "";
	private String screenNoOrName = "";
	private String writeYn = "";

	public String getRecruitYear() {
		return recruitYear;
	}

	public void setRecruitYear(String recruitYear) {
		this.recruitYear = recruitYear;
	}

	public String getRecruitPeriodCd() {
		return recruitPeriodCd;
	}

	public void setRecruitPeriodCd(String recruitPeriodCd) {
		this.recruitPeriodCd = recruitPeriodCd;
	}

	public String getRecruitDegree() {
		return recruitDegree;
	}

	public void setRecruitDegree(String recruitDegree) {
		this.recruitDegree = recruitDegree;
	}

	public String getScreenClassCd() {
		return screenClassCd;
	}

	public void setScreenClassCd(String screenClassCd) {
		this.screenClassCd = screenClassCd;
	}

	public String getRecruitScreenCd() {
		return recruitScreenCd;
	}

	public void setRecruitScreenCd(String recruitScreenCd) {
		this.recruitScreenCd = recruitScreenCd;
	}

	public String getCampusSchoolCd() {
		return campusSchoolCd;
	}

	public void setCampusSchoolCd(String campusSchoolCd) {
		this.campusSchoolCd = campusSchoolCd;
	}

	public String getRecruitMajorCd() {
		return recruitMajorCd;
	}

	public void setRecruitMajorCd(String recruitMajorCd) {
		this.recruitMajorCd = recruitMajorCd;
	}

	public String getDetailMajorCd() {
		return detailMajorCd;
	}

	public void setDetailMajorCd(String detailMajorCd) {
		this.detailMajorCd = detailMajorCd;
	}

	public String getSupportDegreeCd() {
		return supportDegreeCd;
	}

	public void setSupportDegreeCd(String supportDegreeCd) {
		this.supportDegreeCd = supportDegreeCd;
	}

	public String getScreenNoOrName() {
		return screenNoOrName;
	}

	public void setScreenNoOrName(String screenNoOrName) {
		this.screenNoOrName = screenNoOrName;
	}

	public String getWriteYn() {
		return writeYn;
	}

	public void setWriteYn(String writeYn) {
		this.writeYn = writeYn;
	}
}
