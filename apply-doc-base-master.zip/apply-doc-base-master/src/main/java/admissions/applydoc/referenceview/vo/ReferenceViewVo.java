package admissions.applydoc.referenceview.vo;

import admissions.common.vo.DataDefaultVo;

public class ReferenceViewVo extends DataDefaultVo {
    private String rcmndDiscernNm = "";
    private String screenNo = "";
    private String supportNo = "";
    private String engNm = "";
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String recruitDegree = "";
    private String screenClassCd = "";
    private String screenClassNm = "";
    private String recruitScreenCd = "";
    private String recruitScreenNm = "";
    private String recruitMajorCd = "";
    private String recruitMajorKorNm = "";
    private String recruitMajorEngNm = "";
    private String supportDegreeCd = "";
    private String supportDegreeNm = "";
    private String rcmnderName = "";
    private String rcmnderEmailAddress = "";
    private String writeYn = "";
    private String writeYnNm = "";
    private String belongNm = "";
    private String deptNm = "";
    private String positionNm = "";
    private String homepageAddress = "";
    private String telNo = "";
    private String faxNo = "";
    private String postAddress = "";
    private String aplcntRelationshipContents = "";
    private String aplcntStrengthContents = "";
    private String aplcntWeaknessContents = "";
    private String aplcntRelativeEvaluationContents = "";
    private String aplcntObjectvRevwContents = "";
    private String aplcntDiligenceContents = "";
    private String aplcntSummaryContents = "";
    private String addRecommendationFileNo = "";
    private String rcmndGradeScore = "";
    private String writeDate = "";
    private String scheduleCheck = "";
    private String aplcntEmailAddress = "";

	public String getRcmndDiscernNm() {
		return rcmndDiscernNm;
	}

	public void setRcmndDiscernNm(String rcmndDiscernNm) {
		this.rcmndDiscernNm = rcmndDiscernNm;
	}

	public String getScreenNo() {
		return screenNo;
	}

	public void setScreenNo(String screenNo) {
		this.screenNo = screenNo;
	}

	public String getSupportNo() {
		return supportNo;
	}

	public void setSupportNo(String supportNo) {
		this.supportNo = supportNo;
	}

	public String getEngNm() {
		return engNm;
	}

	public void setEngNm(String engNm) {
		this.engNm = engNm;
	}

	public String getRecruitYear() {
		return recruitYear;
	}

	public void setRecruitYear(String recruitYear) {
		this.recruitYear = recruitYear;
	}

	public String getRecruitPeriodCd() {
		return recruitPeriodCd;
	}

	public void setRecruitPeriodCd(String recruitPeriodCd) {
		this.recruitPeriodCd = recruitPeriodCd;
	}

	public String getRecruitDegree() {
		return recruitDegree;
	}

	public void setRecruitDegree(String recruitDegree) {
		this.recruitDegree = recruitDegree;
	}

	public String getScreenClassCd() {
		return screenClassCd;
	}

	public void setScreenClassCd(String screenClassCd) {
		this.screenClassCd = screenClassCd;
	}

	public String getScreenClassNm() {
		return screenClassNm;
	}

	public void setScreenClassNm(String screenClassNm) {
		this.screenClassNm = screenClassNm;
	}

	public String getRecruitScreenCd() {
		return recruitScreenCd;
	}

	public void setRecruitScreenCd(String recruitScreenCd) {
		this.recruitScreenCd = recruitScreenCd;
	}

	public String getRecruitScreenNm() {
		return recruitScreenNm;
	}

	public void setRecruitScreenNm(String recruitScreenNm) {
		this.recruitScreenNm = recruitScreenNm;
	}

	public String getRecruitMajorCd() {
		return recruitMajorCd;
	}

	public void setRecruitMajorCd(String recruitMajorCd) {
		this.recruitMajorCd = recruitMajorCd;
	}

	public String getRecruitMajorKorNm() {
		return recruitMajorKorNm;
	}

	public void setRecruitMajorKorNm(String recruitMajorKorNm) {
		this.recruitMajorKorNm = recruitMajorKorNm;
	}

	public String getRecruitMajorEngNm() {
		return recruitMajorEngNm;
	}

	public void setRecruitMajorEngNm(String recruitMajorEngNm) {
		this.recruitMajorEngNm = recruitMajorEngNm;
	}

	public String getSupportDegreeCd() {
		return supportDegreeCd;
	}

	public void setSupportDegreeCd(String supportDegreeCd) {
		this.supportDegreeCd = supportDegreeCd;
	}

	public String getSupportDegreeNm() {
		return supportDegreeNm;
	}

	public void setSupportDegreeNm(String supportDegreeNm) {
		this.supportDegreeNm = supportDegreeNm;
	}

	public String getRcmnderName() {
		return rcmnderName;
	}

	public void setRcmnderName(String rcmnderName) {
		this.rcmnderName = rcmnderName;
	}

	public String getRcmnderEmailAddress() {
		return rcmnderEmailAddress;
	}

	public void setRcmnderEmailAddress(String rcmnderEmailAddress) {
		this.rcmnderEmailAddress = rcmnderEmailAddress;
	}

	public String getWriteYn() {
		return writeYn;
	}

	public void setWriteYn(String writeYn) {
		this.writeYn = writeYn;
	}

	public String getWriteYnNm() {
		return writeYnNm;
	}

	public void setWriteYnNm(String writeYnNm) {
		this.writeYnNm = writeYnNm;
	}

	public String getBelongNm() {
		return belongNm;
	}

	public void setBelongNm(String belongNm) {
		this.belongNm = belongNm;
	}

	public String getDeptNm() {
		return deptNm;
	}

	public void setDeptNm(String deptNm) {
		this.deptNm = deptNm;
	}

	public String getPositionNm() {
		return positionNm;
	}

	public void setPositionNm(String positionNm) {
		this.positionNm = positionNm;
	}

	public String getHomepageAddress() {
		return homepageAddress;
	}

	public void setHomepageAddress(String homepageAddress) {
		this.homepageAddress = homepageAddress;
	}

	public String getTelNo() {
		return telNo;
	}

	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getPostAddress() {
		return postAddress;
	}

	public void setPostAddress(String postAddress) {
		this.postAddress = postAddress;
	}

	public String getAplcntRelationshipContents() {
		return aplcntRelationshipContents;
	}

	public void setAplcntRelationshipContents(String aplcntRelationshipContents) {
		this.aplcntRelationshipContents = aplcntRelationshipContents;
	}

	public String getAplcntStrengthContents() {
		return aplcntStrengthContents;
	}

	public void setAplcntStrengthContents(String aplcntStrengthContents) {
		this.aplcntStrengthContents = aplcntStrengthContents;
	}

	public String getAplcntWeaknessContents() {
		return aplcntWeaknessContents;
	}

	public void setAplcntWeaknessContents(String aplcntWeaknessContents) {
		this.aplcntWeaknessContents = aplcntWeaknessContents;
	}

	public String getAplcntRelativeEvaluationContents() {
		return aplcntRelativeEvaluationContents;
	}

	public void setAplcntRelativeEvaluationContents(String aplcntRelativeEvaluationContents) {
		this.aplcntRelativeEvaluationContents = aplcntRelativeEvaluationContents;
	}

	public String getAplcntObjectvRevwContents() {
		return aplcntObjectvRevwContents;
	}

	public void setAplcntObjectvRevwContents(String aplcntObjectvRevwContents) {
		this.aplcntObjectvRevwContents = aplcntObjectvRevwContents;
	}

	public String getAplcntDiligenceContents() {
		return aplcntDiligenceContents;
	}

	public void setAplcntDiligenceContents(String aplcntDiligenceContents) {
		this.aplcntDiligenceContents = aplcntDiligenceContents;
	}

	public String getAplcntSummaryContents() {
		return aplcntSummaryContents;
	}

	public void setAplcntSummaryContents(String aplcntSummaryContents) {
		this.aplcntSummaryContents = aplcntSummaryContents;
	}

	public String getAddRecommendationFileNo() {
		return addRecommendationFileNo;
	}

	public void setAddRecommendationFileNo(String addRecommendationFileNo) {
		this.addRecommendationFileNo = addRecommendationFileNo;
	}

	public String getRcmndGradeScore() {
		return rcmndGradeScore;
	}

	public void setRcmndGradeScore(String rcmndGradeScore) {
		this.rcmndGradeScore = rcmndGradeScore;
	}

	public String getWriteDate() {
		return writeDate;
	}

	public void setWriteDate(String writeDate) {
		this.writeDate = writeDate;
	}

	public String getScheduleCheck() {
		return scheduleCheck;
	}

	public void setScheduleCheck(String scheduleCheck) {
		this.scheduleCheck = scheduleCheck;
	}

	public String getAplcntEmailAddress() {
		return aplcntEmailAddress;
	}

	public void setAplcntEmailAddress(String aplcntEmailAddress) {
		this.aplcntEmailAddress = aplcntEmailAddress;
	}
}
