package admissions.applydoc.referenceview;

import admissions.applydoc.referenceview.vo.ReferenceViewFormVo;
import admissions.applydoc.referenceview.vo.ReferenceViewVo;
import admissions.common.dao.CommonDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReferenceViewService {
    @Autowired
    CommonDao commonDao;

    /**
     * 추천서 지원자 목록
     *
     * @param formVo
     * @return
     */
    public List<ReferenceViewVo> selectApplicantList(ReferenceViewFormVo formVo) {
        return (List<ReferenceViewVo>) commonDao.selectList("ReferenceViewMapper.selectApplicantList", formVo);
    }

    /**
     * 추천서 기본 정보
     *
     * @param rcmndDiscern
     * @return
     */
    public ReferenceViewVo selectBasicInfo(String rcmndDiscern) {
        return (ReferenceViewVo) commonDao.selectOne("ReferenceViewMapper.selectBasicInfo", rcmndDiscern);
    }

    /**
     * 추천서 제출(저장)
     *
     * @param vo
     */
    public void updateReference(ReferenceViewVo vo) {
        commonDao.update("ReferenceViewMapper.updateReference", vo);
    }
}
