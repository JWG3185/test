package admissions.applydoc.referenceview;

import admissions.applydoc.referenceview.vo.ReferenceViewFormVo;
import admissions.applydoc.referenceview.vo.ReferenceViewVo;
import admissions.common.mail.MailService;
import admissions.common.mail.vo.ComTransferEmailReceiverVo;
import admissions.common.mail.vo.ComTransferEmailVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/student/reference/")
public class ReferenceViewController {
    private static final String JSON_VIEW = "jsonView";

    @Autowired
    ReferenceViewService referenceViewService;

    @Autowired
    MailService mailService;

    @Value("${proxy.url}")
    private String proxyUrl;

    /**
     * 추천서 지원자 목록
     *
     * @param formVo
     * @return
     */
    @PostMapping("selectApplicantList.do")
    public ModelAndView selectApplicantList(@RequestBody ReferenceViewFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        model.addObject("list", referenceViewService.selectApplicantList(formVo));

        return model;
    }

    /**
     * 추천서 기본정보
     *
     * @param reqMap
     * @return
     */
    @PostMapping("selectBasicInfo.do")
    public ModelAndView selectBasicInfo(@RequestBody Map<String, Object> reqMap) {
		ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        String rcmndDiscern = reqMap.get("rcmndDiscern").toString();
        ReferenceViewVo info = referenceViewService.selectBasicInfo(rcmndDiscern);

        if (info != null) {
            model.addObject("vo", info);
        } else {
            model.setStatus(HttpStatus.NO_CONTENT);
        }

        return model;
    }

    /**
     * 추천서 제출(저장)
     *
     * @param vo
     * @return
     */
    @PostMapping("updateReference.do")
    public ModelAndView updateReference(@RequestBody ReferenceViewVo vo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        referenceViewService.updateReference(vo);
        return model;
    }

    @PostMapping("sendEmailToApl.do")
    public ModelAndView sendEmailToApl(@RequestBody ReferenceViewVo vo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        ComTransferEmailVo mailVo = new ComTransferEmailVo();
        mailVo.setEmailTitle("[KDI] Your recommendation has been submitted.");
        mailVo.setSenderEmailAddress("help_adm@osolit.net");
        mailVo.setSenderNm("UST Admission");
        mailVo.setMultimailYn("N");
        mailVo.setFirstRegistProgramId(vo.getFirstRegistProgramId());
        mailVo.setFirstRegistUserId(vo.getRcmnderEmailAddress());

        HashMap<String, String> contentMap = new HashMap<>();
        contentMap.put("proxyUrl", proxyUrl);
        contentMap.put("noVal", "noVal");
        mailVo.setContentMap(contentMap);

        List<ComTransferEmailReceiverVo> receiverVoList = new ArrayList<>();
        ComTransferEmailReceiverVo receiverVo = new ComTransferEmailReceiverVo();
        receiverVo.setReceiverEmailAddress(vo.getAplcntEmailAddress());
        receiverVo.setReceiverNm(vo.getEngNm());
        receiverVo.setReceiveTypeCd("R");
        receiverVoList.add(receiverVo);
        mailVo.setRecipientList(receiverVoList);
        mailVo.setReceiverCnt("1");

        int emailTransferNo = mailService.insertMailInfo(mailVo, "compReference");

        mailService.sendEmail(String.valueOf(emailTransferNo));

        return model;
    }
}
