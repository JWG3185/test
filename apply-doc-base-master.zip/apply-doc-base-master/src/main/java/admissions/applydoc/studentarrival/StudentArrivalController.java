package admissions.applydoc.studentarrival;

import admissions.applydoc.applicant.ApplicantService;
import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantSurveyAnswerVo;
import admissions.applydoc.applicant.vo.ApplicantSurveyVo;
import admissions.applydoc.resultdocument.ResultDocumentService;
import admissions.applydoc.resultdocument.vo.AfrmVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Controller
@RequestMapping("/student/arrival/")
public class StudentArrivalController {

    @Autowired
    StudentArrivalService studentArrivalService;
    @Autowired
    ResultDocumentService resultDocumentService;
    @Autowired
    ApplicantService applicantService;

    /**
     *
     * @param
     * @return
     */
    @PostMapping("selectQstList.do")
    public ModelAndView selectQstList(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        model.addObject("applicant", applicantService.selectApplicant(formVo));
        AfrmVo afrmVo = resultDocumentService.selectApplicantAfrm(formVo);
        model.addObject("afrm", afrmVo);

        List<ApplicantSurveyVo> surveyQstList = studentArrivalService.selectQstList(formVo);
        model.addObject("surveyQstList", surveyQstList);

        List<ApplicantSurveyVo> surveyClsList = new ArrayList<ApplicantSurveyVo>();
        HashMap<String, String> hm = new HashMap<String, String>();
        for (ApplicantSurveyVo vo : surveyQstList) {
            if (!hm.containsKey(vo.getSurveyClassNo())) {
                hm.put(vo.getSurveyClassNo(), vo.getSurveyClassNm());
                surveyClsList.add(vo);
            }
        }
        model.addObject("surveyClsList", surveyClsList);

        if (surveyQstList.size() > 0) {
            formVo.setSurveyNo(surveyQstList.get(0).getSurveyNo());
            List<ApplicantSurveyAnswerVo> answerList = studentArrivalService.selectAnswerList(formVo);
            model.addObject("answerList", answerList);
        }

        return model;
    }

    /**
     * 설문 답변 저장
     */
    @PostMapping("save.do")
    public ModelAndView saveSurvey(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        studentArrivalService.save(formVo);
        return model;
    }

}
