package admissions.applydoc.studentarrival;

import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantSurveyAnswerVo;
import admissions.applydoc.applicant.vo.ApplicantSurveyVo;
import admissions.common.dao.CommonDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class StudentArrivalService {
    @Autowired
    CommonDao commonDao;

    /**
     * 설문 질의 목록
     */
    public List<ApplicantSurveyVo> selectQstList(ApplicantFormVo formVo) {
        return (List<ApplicantSurveyVo>) commonDao.selectList("StudentArrivalMapper.selectQstList", formVo);
    }

    /**
     * 설문 답변 목록
     */
    public List<ApplicantSurveyAnswerVo> selectAnswerList(ApplicantFormVo formVo) {
        return (List<ApplicantSurveyAnswerVo>) commonDao.selectList("StudentArrivalMapper.selectAnswerList", formVo);
    }

    /**
     * 설문 저장
     */
    @Transactional
    public void save(ApplicantFormVo formVo) {
        commonDao.update("StudentArrivalMapper.updateSurvey", formVo);

        List<ApplicantSurveyVo> qstList = (List<ApplicantSurveyVo>) commonDao.selectList("StudentArrivalMapper.selectQstList", formVo);
        String[] qstNoList = formVo.getSurveyQstNo().split(";");
        for (int index = 0; index < qstNoList.length; index++) {
            String surveyQstNo = qstNoList[index];

            ApplicantSurveyAnswerVo vo = new ApplicantSurveyAnswerVo();
            vo.setRecruitYear(formVo.getRecruitYear());
            vo.setRecruitPeriodCd(formVo.getRecruitPeriodCd());
            vo.setRecruitDegree(formVo.getRecruitDegree());
            vo.setRecruitScreenCd(formVo.getRecruitScreenCd());
            vo.setSurveyNo(formVo.getSurveyNo());
            vo.setSurveyQstNo(surveyQstNo);
            vo.setAnswrContents(formVo.getAnswer(index));
            vo.setAnswerPoints("0");
            vo.setFirstRegistProgramId(formVo.getFirstRegistProgramId());
            vo.setLastUpdateProgramId(formVo.getLastUpdateProgramId());

            ApplicantSurveyVo selectedVo = new ApplicantSurveyVo();
            for (ApplicantSurveyVo vo2 : qstList) {
                if (vo2.getSurveyQstNo().equals(surveyQstNo)) {
                    selectedVo = vo2;
                    break;
                }
            }
            if ("RADIO".equals(selectedVo.getQstEntryTypeCd())) {
                String pointsArray = selectedVo.getRadioPoints();
                String valuesArray = selectedVo.getRadioValues();
                String etcsNo = selectedVo.getRadioEtcs();
                String[] points = pointsArray.split(";", -1);
                String[] values = valuesArray.split(";", -1);
                int pointIndex = -1;
                int valueIndex = -1;
                for (int idx = 0; idx < values.length; idx++) {
                    if (formVo.getAnswer(index).equals(values[idx])) {
                        pointIndex = idx;
                        valueIndex = idx + 1;
                        break;
                    }
                }
                if (pointIndex >= 0) {
                    if ("".equals(points[pointIndex])) {
                        vo.setAnswerPoints("0");
                    } else {
                        vo.setAnswerPoints(points[pointIndex]);
                    }
                }

                if (etcsNo.equals(String.valueOf(valueIndex))) {
                    vo.setEtcAnswrContents(formVo.getAnswerEtc(index));
                }
            } else if (selectedVo.getQstEntryTypeCd().equals("CHECK")) {
                String pointsArray = selectedVo.getCheckPoints();
                String valuesArray = selectedVo.getCheckValues();
                String etcsNo = selectedVo.getCheckEtcs();

                String[] points = pointsArray.split(";", -1);
                String[] values = valuesArray.split(";", -1);

                String[] formValues = formVo.getAnswer(index).split(";");
                StringBuffer answerPoints = new StringBuffer();
                for (int idx = 0; idx < values.length; idx++) {
                    for (String formValue : formValues) {
                        if (formValue.equals(values[idx])) {
                            if (answerPoints.length() > 0) {
                                answerPoints.append(";");
                            }
                            if ("".equals(points[idx])) {
                                answerPoints.append("0");
                            } else {
                                answerPoints.append(points[idx]);
                            }
                        }

                        if (etcsNo.equals(String.valueOf(idx + 1))) {
                            vo.setEtcAnswrContents(formVo.getAnswerEtc(index));
                        }
                    }
                }
                vo.setAnswerPoints(answerPoints.toString());
            }

            commonDao.update("StudentArrivalMapper.updateAnswer", vo);
        }
    }


}
