package admissions.applydoc.resultdocument.vo;

import admissions.common.file.vo.CommonFileVo;
import admissions.common.vo.DataDefaultVo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ConfPassNoticeVo extends DataDefaultVo {
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String recruitDegree = "";
    private String recruitScreenCd = "";
    private String passNoticeCd = "";
    private String passmanFileGroupCd = "";
    private List<CommonFileVo> passFileList = new ArrayList<>();
    private String candidateFileGroupCd = "";
    private List<CommonFileVo> candidateFileList = new ArrayList<>();
    private String passmanNoticeContents = "";
    private String candidateNoticeContents = "";
    private String notpassmanNoticeContents = "";

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getRecruitDegree() {
        return recruitDegree;
    }

    public void setRecruitDegree(String recruitDegree) {
        this.recruitDegree = recruitDegree;
    }

    public String getRecruitScreenCd() {
        return recruitScreenCd;
    }

    public void setRecruitScreenCd(String recruitScreenCd) {
        this.recruitScreenCd = recruitScreenCd;
    }

    public String getPassNoticeCd() {
        return passNoticeCd;
    }

    public void setPassNoticeCd(String passNoticeCd) {
        this.passNoticeCd = passNoticeCd;
    }

    public String getPassmanFileGroupCd() {
        return passmanFileGroupCd;
    }

    public void setPassmanFileGroupCd(String passmanFileGroupCd) {
        this.passmanFileGroupCd = passmanFileGroupCd;
    }

    public String getCandidateFileGroupCd() {
        return candidateFileGroupCd;
    }

    public void setCandidateFileGroupCd(String candidateFileGroupCd) {
        this.candidateFileGroupCd = candidateFileGroupCd;
    }

    public String getPassmanNoticeContents() {
        return passmanNoticeContents;
    }

    public void setPassmanNoticeContents(String passmanNoticeContents) {
        this.passmanNoticeContents = passmanNoticeContents;
    }

    public String getCandidateNoticeContents() {
        return candidateNoticeContents;
    }

    public void setCandidateNoticeContents(String candidateNoticeContents) {
        this.candidateNoticeContents = candidateNoticeContents;
    }

    public String getNotpassmanNoticeContents() {
        return notpassmanNoticeContents;
    }

    public void setNotpassmanNoticeContents(String notpassmanNoticeContents) {
        this.notpassmanNoticeContents = notpassmanNoticeContents;
    }

    public List<CommonFileVo> getPassFileList() {
        return Collections.unmodifiableList(passFileList);
    }

    public void setPassFileList(List<CommonFileVo> passFileList) {
        this.passFileList = Collections.unmodifiableList(passFileList);
    }

    public List<CommonFileVo> getCandidateFileList() {
        return Collections.unmodifiableList(candidateFileList);
    }

    public void setCandidateFileList(List<CommonFileVo> candidateFileList) {
        this.candidateFileList = Collections.unmodifiableList(candidateFileList);
    }
}
