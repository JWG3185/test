package admissions.applydoc.resultdocument.vo;

import admissions.common.vo.DataDefaultVo;

public class AfrmVo extends DataDefaultVo {
    private String screenNo = "";
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String recruitDegree = "";
    private String recruitScreenCd = "";
    private String supportNo = "";
    private String docEligibleYn = "";
    private String docRsltCd = "";
    private String docRsltNm = "";
    private String docRsltEngNm = "";
    private String docScore = "";
    private String docChargerConfirmYn = "";
    private String intrvRsltCd = "";
    private String intrvScore = "";
    private String reservePassRank = "";
    private String intrvChargerConfirmYn = "";
    private String hdqutrPassCd = "";
    private String hdqutrReservePassRank = "";
    private String virtualAccountBankCd = "";
    private String virtualAccountNo = "";
    private String bankCd = "";
    private String accountNo = "";
    private String accountHolder = "";
    private String managerProgressStatusCd = "";
    private String firstCampusRevwCd = "";
    private String firstManagerRevwCd = "";
    private String lastCampusRevwCd = "";
    private String lastManagerRevwCd = "";
    private String entrFeeInstalmentYn = "";
    private String entrPledgeAgreeYn = "";
    private String entrIndividualinfoAgreeYn = "";
    private String entrMarketingAgreeYn = "";
    private String rcmndDocFormalCd = "";
    private String registFeeInstalmentYn = "";
    private String entrRegistWriteYn = "";
    private String entrRegistDt = "";
    private String entrFeePaymentYn = "";
    private String academyStudNo = "";
    private String entrDt = "";
    private String transCancelProcessUserId = "";
    private String transCancelDt = "";
    private String transCancelReasonContents = "";
    private String academyTransDt = "";
    private String docSubmitYn = "";
    private String docSubmitYnSaveDt = "";
    private String rsltCd = "";
    private String userDisplayRsltCd = "";
    private String lastPassYn = "";
    private String userDisplayLastPassYn = "";
    private String userDisplayLastPassNm = "";
    private String userDisplayLastPassEngNm = "";
    private String resideRegistNo = "";
    private String firstResideRegistNo = "";
    private String lastResideRegistNo = "";
    private String admissionPledgeYn = "";
    private String admissionCancelYn = "";
    private String AdmissionCancelAgree = "";
    private String admissionCancelReason = "";
    private String admissionCancelReasonDetail = "";
    private String docChargerConfirmDt = "";
    private String docChargerConfirmId = "";
    private String intrvChargerConfirmDt = "";
    private String intrvChargerConfirmId = "";

    public String getScreenNo() {
        return screenNo;
    }

    public void setScreenNo(String screenNo) {
        this.screenNo = screenNo;
    }

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getRecruitDegree() {
        return recruitDegree;
    }

    public void setRecruitDegree(String recruitDegree) {
        this.recruitDegree = recruitDegree;
    }

    public String getRecruitScreenCd() {
        return recruitScreenCd;
    }

    public void setRecruitScreenCd(String recruitScreenCd) {
        this.recruitScreenCd = recruitScreenCd;
    }

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getDocEligibleYn() {
        return docEligibleYn;
    }

    public void setDocEligibleYn(String docEligibleYn) {
        this.docEligibleYn = docEligibleYn;
    }

    public String getDocRsltCd() {
        return docRsltCd;
    }

    public void setDocRsltCd(String docRsltCd) {
        this.docRsltCd = docRsltCd;
    }

    public String getDocScore() {
        return docScore;
    }

    public void setDocScore(String docScore) {
        this.docScore = docScore;
    }

    public String getDocChargerConfirmYn() {
        return docChargerConfirmYn;
    }

    public void setDocChargerConfirmYn(String docChargerConfirmYn) {
        this.docChargerConfirmYn = docChargerConfirmYn;
    }

    public String getIntrvRsltCd() {
        return intrvRsltCd;
    }

    public void setIntrvRsltCd(String intrvRsltCd) {
        this.intrvRsltCd = intrvRsltCd;
    }

    public String getIntrvScore() {
        return intrvScore;
    }

    public void setIntrvScore(String intrvScore) {
        this.intrvScore = intrvScore;
    }

    public String getReservePassRank() {
        return reservePassRank;
    }

    public void setReservePassRank(String reservePassRank) {
        this.reservePassRank = reservePassRank;
    }

    public String getHdqutrPassCd() {
        return hdqutrPassCd;
    }

    public void setHdqutrPassCd(String hdqutrPassCd) {
        this.hdqutrPassCd = hdqutrPassCd;
    }

    public String getHdqutrReservePassRank() {
        return hdqutrReservePassRank;
    }

    public void setHdqutrReservePassRank(String hdqutrReservePassRank) {
        this.hdqutrReservePassRank = hdqutrReservePassRank;
    }

    public String getVirtualAccountBankCd() {
        return virtualAccountBankCd;
    }

    public void setVirtualAccountBankCd(String virtualAccountBankCd) {
        this.virtualAccountBankCd = virtualAccountBankCd;
    }

    public String getVirtualAccountNo() {
        return virtualAccountNo;
    }

    public void setVirtualAccountNo(String virtualAccountNo) {
        this.virtualAccountNo = virtualAccountNo;
    }

    public String getBankCd() {
        return bankCd;
    }

    public void setBankCd(String bankCd) {
        this.bankCd = bankCd;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    public void setAccountHolder(String accountHolder) {
        this.accountHolder = accountHolder;
    }

    public String getManagerProgressStatusCd() {
        return managerProgressStatusCd;
    }

    public void setManagerProgressStatusCd(String managerProgressStatusCd) {
        this.managerProgressStatusCd = managerProgressStatusCd;
    }

    public String getFirstCampusRevwCd() {
        return firstCampusRevwCd;
    }

    public void setFirstCampusRevwCd(String firstCampusRevwCd) {
        this.firstCampusRevwCd = firstCampusRevwCd;
    }

    public String getFirstManagerRevwCd() {
        return firstManagerRevwCd;
    }

    public void setFirstManagerRevwCd(String firstManagerRevwCd) {
        this.firstManagerRevwCd = firstManagerRevwCd;
    }

    public String getLastCampusRevwCd() {
        return lastCampusRevwCd;
    }

    public void setLastCampusRevwCd(String lastCampusRevwCd) {
        this.lastCampusRevwCd = lastCampusRevwCd;
    }

    public String getLastManagerRevwCd() {
        return lastManagerRevwCd;
    }

    public void setLastManagerRevwCd(String lastManagerRevwCd) {
        this.lastManagerRevwCd = lastManagerRevwCd;
    }

    public String getEntrFeeInstalmentYn() {
        return entrFeeInstalmentYn;
    }

    public void setEntrFeeInstalmentYn(String entrFeeInstalmentYn) {
        this.entrFeeInstalmentYn = entrFeeInstalmentYn;
    }

    public String getEntrPledgeAgreeYn() {
        return entrPledgeAgreeYn;
    }

    public void setEntrPledgeAgreeYn(String entrPledgeAgreeYn) {
        this.entrPledgeAgreeYn = entrPledgeAgreeYn;
    }

    public String getEntrIndividualinfoAgreeYn() {
        return entrIndividualinfoAgreeYn;
    }

    public void setEntrIndividualinfoAgreeYn(String entrIndividualinfoAgreeYn) {
        this.entrIndividualinfoAgreeYn = entrIndividualinfoAgreeYn;
    }

    public String getEntrMarketingAgreeYn() {
        return entrMarketingAgreeYn;
    }

    public void setEntrMarketingAgreeYn(String entrMarketingAgreeYn) {
        this.entrMarketingAgreeYn = entrMarketingAgreeYn;
    }

    public String getRcmndDocFormalCd() {
        return rcmndDocFormalCd;
    }

    public void setRcmndDocFormalCd(String rcmndDocFormalCd) {
        this.rcmndDocFormalCd = rcmndDocFormalCd;
    }

    public String getRegistFeeInstalmentYn() {
        return registFeeInstalmentYn;
    }

    public void setRegistFeeInstalmentYn(String registFeeInstalmentYn) {
        this.registFeeInstalmentYn = registFeeInstalmentYn;
    }

    public String getEntrRegistWriteYn() {
        return entrRegistWriteYn;
    }

    public void setEntrRegistWriteYn(String entrRegistWriteYn) {
        this.entrRegistWriteYn = entrRegistWriteYn;
    }

    public String getEntrRegistDt() {
        return entrRegistDt;
    }

    public void setEntrRegistDt(String entrRegistDt) {
        this.entrRegistDt = entrRegistDt;
    }

    public String getEntrFeePaymentYn() {
        return entrFeePaymentYn;
    }

    public void setEntrFeePaymentYn(String entrFeePaymentYn) {
        this.entrFeePaymentYn = entrFeePaymentYn;
    }

    public String getAcademyStudNo() {
        return academyStudNo;
    }

    public void setAcademyStudNo(String academyStudNo) {
        this.academyStudNo = academyStudNo;
    }

    public String getEntrDt() {
        return entrDt;
    }

    public void setEntrDt(String entrDt) {
        this.entrDt = entrDt;
    }

    public String getTransCancelProcessUserId() {
        return transCancelProcessUserId;
    }

    public void setTransCancelProcessUserId(String transCancelProcessUserId) {
        this.transCancelProcessUserId = transCancelProcessUserId;
    }

    public String getTransCancelDt() {
        return transCancelDt;
    }

    public void setTransCancelDt(String transCancelDt) {
        this.transCancelDt = transCancelDt;
    }

    public String getTransCancelReasonContents() {
        return transCancelReasonContents;
    }

    public void setTransCancelReasonContents(String transCancelReasonContents) {
        this.transCancelReasonContents = transCancelReasonContents;
    }

    public String getAcademyTransDt() {
        return academyTransDt;
    }

    public void setAcademyTransDt(String academyTransDt) {
        this.academyTransDt = academyTransDt;
    }

    public String getDocSubmitYn() {
        return docSubmitYn;
    }

    public void setDocSubmitYn(String docSubmitYn) {
        this.docSubmitYn = docSubmitYn;
    }

    public String getDocSubmitYnSaveDt() {
        return docSubmitYnSaveDt;
    }

    public void setDocSubmitYnSaveDt(String docSubmitYnSaveDt) {
        this.docSubmitYnSaveDt = docSubmitYnSaveDt;
    }

    public String getRsltCd() {
        return rsltCd;
    }

    public void setRsltCd(String rsltCd) {
        this.rsltCd = rsltCd;
    }

    public String getUserDisplayRsltCd() {
        return userDisplayRsltCd;
    }

    public void setUserDisplayRsltCd(String userDisplayRsltCd) {
        this.userDisplayRsltCd = userDisplayRsltCd;
    }

    public String getLastPassYn() {
        return lastPassYn;
    }

    public void setLastPassYn(String lastPassYn) {
        this.lastPassYn = lastPassYn;
    }

    public String getUserDisplayLastPassYn() {
        return userDisplayLastPassYn;
    }

    public void setUserDisplayLastPassYn(String userDisplayLastPassYn) {
        this.userDisplayLastPassYn = userDisplayLastPassYn;
    }

    public String getIntrvChargerConfirmYn() {
        return intrvChargerConfirmYn;
    }

    public void setIntrvChargerConfirmYn(String intrvChargerConfirmYn) {
        this.intrvChargerConfirmYn = intrvChargerConfirmYn;
    }

    public String getDocRsltNm() {
        return docRsltNm;
    }

    public void setDocRsltNm(String docRsltNm) {
        this.docRsltNm = docRsltNm;
    }

    public String getDocRsltEngNm() {
        return docRsltEngNm;
    }

    public void setDocRsltEngNm(String docRsltEngNm) {
        this.docRsltEngNm = docRsltEngNm;
    }

    public String getUserDisplayLastPassNm() {
        return userDisplayLastPassNm;
    }

    public void setUserDisplayLastPassNm(String userDisplayLastPassNm) {
        this.userDisplayLastPassNm = userDisplayLastPassNm;
    }

    public String getUserDisplayLastPassEngNm() {
        return userDisplayLastPassEngNm;
    }

    public void setUserDisplayLastPassEngNm(String userDisplayLastPassEngNm) {
        this.userDisplayLastPassEngNm = userDisplayLastPassEngNm;
    }

    public String getResideRegistNo() {
        return resideRegistNo;
    }

    public void setResideRegistNo(String resideRegistNo) {
        this.resideRegistNo = resideRegistNo;
        if (!"".equals(resideRegistNo)) {
            this.firstResideRegistNo = resideRegistNo.substring(0, 6);
            this.lastResideRegistNo = resideRegistNo.substring(6);
        }
    }

    public String getFirstResideRegistNo() {
        return firstResideRegistNo;
    }

    public void setFirstResideRegistNo(String firstResideRegistNo) {
        this.firstResideRegistNo = firstResideRegistNo;
    }

    public String getLastResideRegistNo() {
        return lastResideRegistNo;
    }

    public void setLastResideRegistNo(String lastResideRegistNo) {
        this.lastResideRegistNo = lastResideRegistNo;
    }

    public String getAdmissionPledgeYn() {
        return admissionPledgeYn;
    }

    public void setAdmissionPledgeYn(String admissionPledgeYn) {
        this.admissionPledgeYn = admissionPledgeYn;
    }

    public String getAdmissionCancelYn() {
        return admissionCancelYn;
    }

    public void setAdmissionCancelYn(String admissionCancelYn) {
        this.admissionCancelYn = admissionCancelYn;
    }

    public String getAdmissionCancelAgree() {
        return AdmissionCancelAgree;
    }

    public void setAdmissionCancelAgree(String admissionCancelAgree) {
        AdmissionCancelAgree = admissionCancelAgree;
    }

    public String getAdmissionCancelReason() {
        return admissionCancelReason;
    }

    public void setAdmissionCancelReason(String admissionCancelReason) {
        this.admissionCancelReason = admissionCancelReason;
    }

    public String getAdmissionCancelReasonDetail() {
        return admissionCancelReasonDetail;
    }

    public void setAdmissionCancelReasonDetail(String admissionCancelReasonDetail) {
        this.admissionCancelReasonDetail = admissionCancelReasonDetail;
    }

    public String getDocChargerConfirmDt() {
        return docChargerConfirmDt;
    }

    public void setDocChargerConfirmDt(String docChargerConfirmDt) {
        this.docChargerConfirmDt = docChargerConfirmDt;
    }

    public String getDocChargerConfirmId() {
        return docChargerConfirmId;
    }

    public void setDocChargerConfirmId(String docChargerConfirmId) {
        this.docChargerConfirmId = docChargerConfirmId;
    }

    public String getIntrvChargerConfirmDt() {
        return intrvChargerConfirmDt;
    }

    public void setIntrvChargerConfirmDt(String intrvChargerConfirmDt) {
        this.intrvChargerConfirmDt = intrvChargerConfirmDt;
    }

    public String getIntrvChargerConfirmId() {
        return intrvChargerConfirmId;
    }

    public void setIntrvChargerConfirmId(String intrvChargerConfirmId) {
        this.intrvChargerConfirmId = intrvChargerConfirmId;
    }
}
