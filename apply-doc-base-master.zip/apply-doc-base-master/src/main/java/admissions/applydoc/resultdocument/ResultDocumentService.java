package admissions.applydoc.resultdocument;

import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantVo;
import admissions.applydoc.resultdocument.vo.AfrmIntrvSchdlVo;
import admissions.applydoc.resultdocument.vo.AfrmVo;
import admissions.applydoc.resultdocument.vo.ConfPassNoticeVo;
import admissions.common.auth.AuthService;
import admissions.common.dao.CommonDao;
import admissions.common.file.FileService;
import admissions.common.file.vo.CommonFileVo;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.outline.PDDocumentOutline;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

@Service
public class ResultDocumentService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResultDocumentService.class);
    @Autowired
    CommonDao commonDao;
    @Autowired
    FileService fileService;
    @Autowired
    AuthService authService;

    @Value("${server.kind}")
    private String imgServerKind;

    @Value("${file.upload.dir}")
    private String uploadDir;

    @Value("${clipreport.url}")
    private String clipReportUrl;

	public File downloadPdf(ApplicantVo vo) {
        File pdfDir = new File(uploadDir + File.separator + "pdf");
        if(!pdfDir.exists() || !pdfDir.isDirectory())
        {
            boolean res = pdfDir.mkdirs();
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("make dir res: " + res);
            }
        }

        String localFilePath = "";

        String imgServerIp = "http://172.16.6.215:83";
        if(imgServerKind.equals("front"))
        {
            imgServerIp = "http://210.98.46.41:9983";
        }
        String params = vo.getRecruitYear() + "|" + vo.getRecruitPeriodCd() + "|" + vo.getRecruitDegree() + "|" + vo.getRecruitScreenCd() + "|" + vo.getSupportNo() + "|" + imgServerIp;
        String encryptedParam = "";
        String encodedParams = "";
        try{
            encryptedParam = authService.encryptAES256(params);
            encodedParams = URLEncoder.encode(encryptedParam, "UTF-8");
        }
        catch(Exception e)
        {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        StringBuffer fileUrl = new StringBuffer();
        String useLanguage = (String) commonDao.selectOne("ApplicantMapper.selectUseLanguage", vo);

        fileUrl.append(clipReportUrl.replaceAll("recruit_report.jsp", "recruit_exportForPDF.jsp"));
        fileUrl.append("?crfName=r020_admiTicket_" + useLanguage.toLowerCase() + ".crf");
        fileUrl.append("&params=" + encodedParams);

        localFilePath = uploadDir + File.separator + "pdf" + File.separator + "form" + vo.getRecruitYear() + "_" + vo.getRecruitPeriodCd() + "_" + vo.getRecruitDegree() + "_" + vo.getRecruitScreenCd() + "_" + vo.getSupportNo() + ".pdf";

        try {
            URL url = new URL(fileUrl.toString());
            try (InputStream in = url.openStream())
            {
                // 로컬 파일에 스트림 데이터 저장
                try (OutputStream out = new FileOutputStream(localFilePath))
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                }
            }
            File docFile = new File(localFilePath);
            if(docFile.isFile())
            {
                PDDocument document = PDDocument.load(docFile);

                try
                {
                    PDDocumentOutline documentOutline = new PDDocumentOutline();

                    // Create a new bookmark item
                    PDOutlineItem bookmark = new PDOutlineItem();
                    bookmark.setTitle("test_identification_slip");
                    bookmark.setDestination(document.getPage(0));

                    // Add the bookmark to the outline
                    documentOutline.addFirst(bookmark);

                    // Set the document outline
                    document.getDocumentCatalog().setDocumentOutline(documentOutline);
                    document.save(localFilePath);
                }
                catch (IOException e)
                {
                    if (LOGGER.isErrorEnabled()) {
                        LOGGER.error(e.getMessage(), e);
                    }
                }
                finally {
                    document.close();
                }
            }
        } catch (IOException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        return new File(localFilePath);
	}

	public AfrmVo selectApplicantAfrm(ApplicantFormVo formVo) {
        return (AfrmVo) commonDao.selectOne("ResultDocument.selectAfrm", formVo);
    }

    @Transactional
    public void updateApplicantAfrm(AfrmVo afrmVo)
    {
        commonDao.update("ResultDocument.updateAfrm", afrmVo);
    }

    public ConfPassNoticeVo selectPassNotice(ApplicantFormVo formVo)
    {
        ConfPassNoticeVo passVo = (ConfPassNoticeVo) commonDao.selectOne("ResultDocument.selectPassNotice", formVo);

        if(ObjectUtils.isNotEmpty(passVo)){
            if(StringUtils.isNotEmpty(passVo.getPassmanFileGroupCd()))
            {
                passVo.setPassFileList((List<CommonFileVo>) fileService.selectList(passVo.getPassmanFileGroupCd()));
            }
            if(StringUtils.isNotEmpty(passVo.getCandidateFileGroupCd()))
            {
                passVo.setCandidateFileList((List<CommonFileVo>) fileService.selectList(passVo.getCandidateFileGroupCd()));
            }
        }

        return passVo;
    }

    public AfrmIntrvSchdlVo selectIntrvSchd(ApplicantFormVo formVo)
    {
        return (AfrmIntrvSchdlVo) commonDao.selectOne("ResultDocument.selectAfrmIntrvSchdl", formVo);
    }

    public File downloadPassCertPdf(ApplicantVo vo) {
        File pdfDir = new File(uploadDir + File.separator + "pdf");
        if(!pdfDir.exists() || !pdfDir.isDirectory())
        {
            boolean res = pdfDir.mkdirs();
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("make dir res: " + res);
            }
        }

        String localFilePath = "";

        String params = vo.getSupportNo() + "|" + vo.getRecruitYear() + "|" + vo.getRecruitPeriodCd() + "|" + vo.getRecruitDegree() + "|" + vo.getRecruitScreenCd();
        String encryptedParam = "";
        String encodedParams = "";
        try{
            encryptedParam = authService.encryptAES256(params);
            encodedParams = URLEncoder.encode(encryptedParam, "UTF-8");
        }
        catch(Exception e)
        {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        StringBuffer fileUrl = new StringBuffer();
        String useLanguage = (String) commonDao.selectOne("ApplicantMapper.selectUseLanguage", vo);

        fileUrl.append(clipReportUrl.replaceAll("recruit_report.jsp", "recruit_exportForPDF.jsp"));
        fileUrl.append("?crfName=passCert_" + useLanguage.toLowerCase() + ".crf");
        fileUrl.append("&params=" + encodedParams);

        localFilePath = uploadDir + File.separator + "pdf" + File.separator + "form" + vo.getRecruitYear() + "_" + vo.getRecruitPeriodCd() + "_" + vo.getRecruitDegree() + "_" + vo.getRecruitScreenCd() + "_" + vo.getSupportNo() + ".pdf";

        try {
            URL url = new URL(fileUrl.toString());
            try (InputStream in = url.openStream())
            {
                // 로컬 파일에 스트림 데이터 저장
                try (OutputStream out = new FileOutputStream(localFilePath))
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                }
            }
            File docFile = new File(localFilePath);
            if(docFile.isFile())
            {
                PDDocument document = PDDocument.load(docFile);

                try
                {
                    PDDocumentOutline documentOutline = new PDDocumentOutline();

                    // Create a new bookmark item
                    PDOutlineItem bookmark = new PDOutlineItem();
                    bookmark.setTitle("pass_cert");
                    bookmark.setDestination(document.getPage(0));

                    // Add the bookmark to the outline
                    documentOutline.addFirst(bookmark);

                    // Set the document outline
                    document.getDocumentCatalog().setDocumentOutline(documentOutline);
                    document.save(localFilePath);
                }
                catch (IOException e)
                {
                    if (LOGGER.isErrorEnabled()) {
                        LOGGER.error(e.getMessage(), e);
                    }
                }
                finally {
                    document.close();
                }
            }
        } catch (IOException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        return new File(localFilePath);
    }

    public File downloadTuitionPdf(ApplicantVo vo) {
        File pdfDir = new File(uploadDir + File.separator + "pdf");
        if(!pdfDir.exists() || !pdfDir.isDirectory())
        {
            boolean res = pdfDir.mkdirs();
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("make dir res: " + res);
            }
        }

        String localFilePath = "";

        String params = vo.getSupportNo() + "|" + vo.getRecruitYear() + "|" + vo.getRecruitPeriodCd() + "|" + vo.getRecruitDegree() + "|" + vo.getRecruitScreenCd();
        String encryptedParam = "";
        String encodedParams = "";
        try{
            encryptedParam = authService.encryptAES256(params);
            encodedParams = URLEncoder.encode(encryptedParam, "UTF-8");
        }
        catch(Exception e)
        {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        StringBuffer fileUrl = new StringBuffer();
        String useLanguage = (String) commonDao.selectOne("ApplicantMapper.selectUseLanguage", vo);

        fileUrl.append(clipReportUrl.replaceAll("recruit_report.jsp", "recruit_exportForPDF.jsp"));
        fileUrl.append("?crfName=rpt_tuition_" + useLanguage.toLowerCase() + ".crf");
        fileUrl.append("&params=" + encodedParams);

        localFilePath = uploadDir + File.separator + "pdf" + File.separator + "form" + vo.getRecruitYear() + "_" + vo.getRecruitPeriodCd() + "_" + vo.getRecruitDegree() + "_" + vo.getRecruitScreenCd() + "_" + vo.getSupportNo() + ".pdf";

        try {
            URL url = new URL(fileUrl.toString());
            try (InputStream in = url.openStream())
            {
                // 로컬 파일에 스트림 데이터 저장
                try (OutputStream out = new FileOutputStream(localFilePath))
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                }
            }
            File docFile = new File(localFilePath);
            if(docFile.isFile())
            {
                PDDocument document = PDDocument.load(docFile);

                try
                {
                    PDDocumentOutline documentOutline = new PDDocumentOutline();

                    // Create a new bookmark item
                    PDOutlineItem bookmark = new PDOutlineItem();
                    bookmark.setTitle("tution");
                    bookmark.setDestination(document.getPage(0));

                    // Add the bookmark to the outline
                    documentOutline.addFirst(bookmark);

                    // Set the document outline
                    document.getDocumentCatalog().setDocumentOutline(documentOutline);
                    document.save(localFilePath);
                }
                catch (IOException e)
                {
                    if (LOGGER.isErrorEnabled()) {
                        LOGGER.error(e.getMessage(), e);
                    }
                }
                finally {
                    document.close();
                }
            }
        } catch (IOException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        return new File(localFilePath);
    }
}
