package admissions.applydoc.resultdocument.vo;

import admissions.common.vo.DataDefaultVo;

public class AfrmIntrvSchdlVo extends DataDefaultVo {
    private String screenNo = "";
    private String compositionDivCd = "";
    private String compositionNo = "";
    private String recruitYear = "";
    private String intrvDt = "";
    private String intrvStartTm = "";
    private String intrvEndTm = "";
    private String intrvTimeStartTxt = "";
    private String intrvTimeEndTxt = "";
    private String intrvPlaceNm = "";
    private String intrvContact = "";
    private String intrvContactContents = "";
    private String intrvPlanContents = "";
    private String aplcntPrepareitemContents = "";
    private String intrvRemarkContents = "";

    public String getScreenNo() {
        return screenNo;
    }

    public void setScreenNo(String screenNo) {
        this.screenNo = screenNo;
    }

    public String getCompositionNo() {
        return compositionNo;
    }

    public void setCompositionNo(String compositionNo) {
        this.compositionNo = compositionNo;
    }

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getIntrvDt() {
        return intrvDt;
    }

    public void setIntrvDt(String intrvDt) {
        this.intrvDt = intrvDt;
    }

    public String getIntrvStartTm() {
        return intrvStartTm;
    }

    public void setIntrvStartTm(String intrvStartTm) {
        this.intrvStartTm = intrvStartTm;
    }

    public String getIntrvEndTm() {
        return intrvEndTm;
    }

    public void setIntrvEndTm(String intrvEndTm) {
        this.intrvEndTm = intrvEndTm;
    }

    public String getIntrvPlaceNm() {
        return intrvPlaceNm;
    }

    public void setIntrvPlaceNm(String intrvPlaceNm) {
        this.intrvPlaceNm = intrvPlaceNm;
    }

    public String getIntrvContact() {
        return intrvContact;
    }

    public void setIntrvContact(String intrvContact) {
        this.intrvContact = intrvContact;
    }

    public String getIntrvContactContents() {
        return intrvContactContents;
    }

    public void setIntrvContactContents(String intrvContactContents) {
        this.intrvContactContents = intrvContactContents;
    }

    public String getIntrvPlanContents() {
        return intrvPlanContents;
    }

    public void setIntrvPlanContents(String intrvPlanContents) {
        this.intrvPlanContents = intrvPlanContents;
    }

    public String getAplcntPrepareitemContents() {
        return aplcntPrepareitemContents;
    }

    public void setAplcntPrepareitemContents(String aplcntPrepareitemContents) {
        this.aplcntPrepareitemContents = aplcntPrepareitemContents;
    }

    public String getIntrvRemarkContents() {
        return intrvRemarkContents;
    }

    public void setIntrvRemarkContents(String intrvRemarkContents) {
        this.intrvRemarkContents = intrvRemarkContents;
    }

    public String getIntrvTimeStartTxt() {
        return intrvTimeStartTxt;
    }

    public void setIntrvTimeStartTxt(String intrvTimeStartTxt) {
        this.intrvTimeStartTxt = intrvTimeStartTxt;
    }

    public String getIntrvTimeEndTxt() {
        return intrvTimeEndTxt;
    }

    public void setIntrvTimeEndTxt(String intrvTimeEndTxt) {
        this.intrvTimeEndTxt = intrvTimeEndTxt;
    }

    public String getCompositionDivCd() {
        return compositionDivCd;
    }

    public void setCompositionDivCd(String compositionDivCd) {
        this.compositionDivCd = compositionDivCd;
    }
}
