package admissions.applydoc.resultdocument;

import admissions.applydoc.applicant.ApplicantService;
import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantVo;
import admissions.applydoc.resultdocument.vo.AfrmVo;
import admissions.system.code.CodeService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;

@Controller
@RequestMapping("/resultdocument/")
public class ResultDocumentContorller {
    private static final Logger LOGGER = LoggerFactory.getLogger(ResultDocumentContorller.class);

    @Autowired
    ResultDocumentService resultDocumentService;

    @Autowired
    ApplicantService applicantService;

    @Autowired
    CodeService codeService;

    @PostMapping("selectResultDocument.do")
    public ModelAndView selectResultDocument(@RequestBody ApplicantFormVo formVo)
    {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        AfrmVo afrmVo = resultDocumentService.selectApplicantAfrm(formVo);

        formVo.setScreenNo(afrmVo.getScreenNo());

        // PASS_NOTICE_CD ( 1 : 1차, 2 : 최종 )
        formVo.setPassNoticeCd("1");
        // CMITE_DIV_CD ( 01 :서류심사, 02 : 면접심사 )
        formVo.setCmiteDivCd("02");

        model.addObject("applicant", applicantService.selectApplicant(formVo));
        model.addObject("passNotice", resultDocumentService.selectPassNotice(formVo));
        model.addObject("afrm", afrmVo);
        model.addObject("intrvSchd", resultDocumentService.selectIntrvSchd(formVo));

        return model;
    }

    @PostMapping("downloadPdf.do")
    public void downloadPdf (HttpServletRequest request , HttpServletResponse response, @RequestBody ApplicantVo vo) throws IOException
    {
        final File file = resultDocumentService.downloadPdf(vo);
        final int fileSize = Long.valueOf(file.length()).intValue();

        if(file.exists() && file.isFile())
        {
            InputStream is = null;

            try{
                is = Files.newInputStream(file.toPath(), StandardOpenOption.READ);

                IOUtils.copy(is, response.getOutputStream());

                String mimeType = "application/zip";
                if(file.getName().endsWith(".pdf"))
                {
                    mimeType = "application/pdf";
                }

                response.setContentType(mimeType);
                response.setContentLength(fileSize);
                response.setHeader("Content-Disposition", "inline;");
                response.setHeader("Content-Transfer-Encoding", "binary");
                response.getOutputStream().flush();
                response.getOutputStream().close();
            }
            catch (IOException e)
            {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error(e.getMessage(), e);
                }
            }
            finally {
                if(is != null)
                {
                    is.close();
                }
            }
        }
    }
}
