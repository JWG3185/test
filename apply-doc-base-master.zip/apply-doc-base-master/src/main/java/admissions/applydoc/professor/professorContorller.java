package admissions.applydoc.professor;

import admissions.applydoc.applicant.ApplicantService;
import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantProfessorVo;
import admissions.applydoc.resultdocument.ResultDocumentService;
import admissions.applydoc.resultdocument.vo.AfrmVo;
import admissions.common.vo.PaginationVo;
import admissions.system.code.CodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.util.List;

@Controller
@RequestMapping("/professor/")
public class professorContorller {

    @Autowired
    ResultDocumentService resultDocumentService;

    @Autowired
    professorService professorService;

    @Autowired
    ApplicantService applicantService;

    @Autowired
    CodeService codeService;

    @PostMapping("selectAfrmProfessor.do")
    public ModelAndView selectAfrmProfessor(@RequestBody ApplicantFormVo formVo)
    {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        AfrmVo preofessor = professorService.selectAfrmProfessor(formVo);

        formVo.setScreenNo(preofessor.getScreenNo());
        model.addObject("applicant", applicantService.selectApplicant(formVo));
        model.addObject("professor", preofessor);

        return model;
    }

    @PostMapping("selectProfessor.do")
    public ModelAndView selectProfessor(@RequestBody ApplicantProfessorVo formVo)
    {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        List<ApplicantProfessorVo> professorList = professorService.selectProfessor(formVo);

        PaginationVo pagination = new PaginationVo();
        pagination.setList(professorList, formVo.getCountPerPage());
        pagination.setCurrentPage(formVo.getPageNo());
        model.addObject("pagination", pagination);

        model.addObject("professorList", professorList);
        return model;
    }

    @PostMapping("updateProfessor.do")
    public ModelAndView updateProfessor(@RequestBody AfrmVo afrmVo)
    {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        professorService.updateProfessor(afrmVo);
        return model;
    }
}
