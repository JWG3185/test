package admissions.applydoc.professor;

import admissions.applydoc.applicant.ApplicantService;
import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantProfessorVo;
import admissions.applydoc.resultdocument.ResultDocumentService;
import admissions.applydoc.resultdocument.vo.AfrmVo;
import admissions.common.dao.CommonDao;
import admissions.common.file.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class professorService {

    @Autowired
    CommonDao commonDao;
    @Autowired
    FileService fileService;

    @Autowired
    ApplicantService applicantService;

    @Autowired
    ResultDocumentService resultDocumentService;

    public AfrmVo selectAfrmProfessor(ApplicantFormVo formVo) {
        return (AfrmVo) commonDao.selectOne("ProfessorMapper.selectAfrmProfessor", formVo);
    }

    public List<ApplicantProfessorVo> selectProfessor(ApplicantProfessorVo formVo)
    {
        return (List<ApplicantProfessorVo>) commonDao.selectList("ProfessorMapper.selectProfessor", formVo);
    }

    public int updateProfessor(AfrmVo afrmVo) {
        return commonDao.update("ProfessorMapper.updateProfessor", afrmVo);
    }
}
