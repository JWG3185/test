package admissions.applydoc.lastresult;

import admissions.common.dao.CommonDao;
import admissions.common.file.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LastResultService {

    @Autowired
    CommonDao commonDao;
    @Autowired
    FileService fileService;
}
