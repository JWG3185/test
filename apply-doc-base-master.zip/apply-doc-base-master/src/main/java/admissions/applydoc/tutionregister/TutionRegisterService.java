package admissions.applydoc.tutionregister;

import admissions.applydoc.applicant.ApplicantService;
import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantProfessorVo;
import admissions.applydoc.applicant.vo.ApplicantSubmitDocVo;
import admissions.applydoc.applicant.vo.ApplicantVo;
import admissions.applydoc.resultdocument.ResultDocumentService;
import admissions.common.dao.CommonDao;
import admissions.common.file.FileService;
import admissions.common.file.vo.CommonFileVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TutionRegisterService {

    @Autowired
    CommonDao commonDao;
    @Autowired
    FileService fileService;

    @Autowired
    ApplicantService applicantService;

    @Autowired
    ResultDocumentService resultDocumentService;


    @Transactional
    public void saveTutionRegister(ApplicantVo applicantVo) {

        if (!applicantVo.getDisabilityProofFileList().isEmpty()) {
            for (Object o : applicantVo.getDisabilityProofFileList()) {
                CommonFileVo fileVo = (CommonFileVo) o;
                fileVo.setFirstRegistUserId(applicantVo.getFirstRegistUserId());
                fileVo.setFirstRegistProgramId(applicantVo.getFirstRegistProgramId());
            }
            if ("tmp".equals(applicantVo.getDisabilityProofFileGroupNo())) {
                applicantVo.setDisabilityProofFileGroupNo("");
            }
            String fileGroupNo = fileService.doSave(applicantVo.getDisabilityProofFileList(), applicantVo.getDisabilityProofFileGroupNo());
            applicantVo.setDisabilityProofFileGroupNo(fileGroupNo);
        } else {
            fileService.deleteFileGroup(applicantVo.getDisabilityProofFileGroupNo());
            applicantVo.setDisabilityProofFileGroupNo("");
        }

        commonDao.update("ApplicantMapper.saveApplicant", applicantVo);
        commonDao.update("ApplicantMapper.updateApplicantAfrm", applicantVo.getAfrm());

        if (!applicantVo.getSubmitDocList().isEmpty()) {
            List<ApplicantSubmitDocVo> submitDocVoList = applicantVo.getSubmitDocList()
                    .stream()
                    .filter(h -> !h.getFileList().isEmpty())
                    .collect(Collectors.toList());
            List<ApplicantSubmitDocVo> submitDocDeleteList = applicantVo.getSubmitDocList()
                    .stream()
                    .filter(h -> h.getFileList().isEmpty())
                    .collect(Collectors.toList());
            if (!submitDocDeleteList.isEmpty()) {
                for (int idx = 0; idx < submitDocDeleteList.size(); idx++) {
                    fileService.deleteFileGroup(submitDocDeleteList.get(idx).getBeforeFileGroupNo());
                    commonDao.delete("ApplicantMapper.deleteSubmitDoc", submitDocDeleteList.get(idx));
                }
            }
            if (!submitDocVoList.isEmpty()) {
                applicantVo.setSubmitDocList(submitDocVoList);

                String fileGroupNo = "";
                for (int i = 0; i < submitDocVoList.size(); i++) {
                    ApplicantSubmitDocVo o = submitDocVoList.get(i);
                    CommonFileVo fileVo = o.getFileList().get(0);
                    fileVo.setFirstRegistUserId(applicantVo.getFirstRegistUserId());
                    fileVo.setFirstRegistProgramId(applicantVo.getFirstRegistProgramId());
                    fileGroupNo = fileService.doSave(o.getFileList(), o.getBeforeFileGroupNo());
                    o.setFileGroupNo(fileGroupNo);
                }
                commonDao.update("ApplicantMapper.updateSubmitDocList", applicantVo);
            }
        }

    }

    public void saveAdmissionCancel(ApplicantVo applicantVo) {
        commonDao.update("ApplicantMapper.updateAdmissionCancel", applicantVo.getAfrm());
    }

    public List<ApplicantProfessorVo> selectProfessor(ApplicantFormVo formVo) {
        return (List<ApplicantProfessorVo>) commonDao.selectList("ApplicantMapper.selectProfessor", formVo);
    }

}
