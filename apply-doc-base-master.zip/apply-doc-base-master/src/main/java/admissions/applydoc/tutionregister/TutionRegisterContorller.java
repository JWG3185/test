package admissions.applydoc.tutionregister;

import admissions.applydoc.applicant.ApplicantService;
import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantProfessorVo;
import admissions.applydoc.applicant.vo.ApplicantVo;
import admissions.applydoc.resultdocument.ResultDocumentService;
import admissions.system.code.CodeService;
import admissions.system.code.vo.CodeFormVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.util.List;

@Controller
@RequestMapping("/tutionregister/")
public class TutionRegisterContorller {

    @Autowired
    ResultDocumentService resultDocumentService;

    @Autowired
    TutionRegisterService tutionRegisterService;

    @Autowired
    ApplicantService applicantService;

    @Autowired
    CodeService codeService;

    @PostMapping("selectTutionRegister.do")
    public ModelAndView selectTutionRegister(@RequestBody ApplicantFormVo formVo)
    {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        CodeFormVo codeFormVo = new CodeFormVo();

        formVo.setDocDivCd("2");

        model.addObject("applicant", applicantService.selectApplicant(formVo));
        model.addObject("afrm", resultDocumentService.selectApplicantAfrm(formVo));
        model.addObject("submitDocList", applicantService.selectSubmitDocList(formVo));

        codeFormVo.setComClassCd("NATION_TEL_NO");
        model.addObject("nationTelList", codeService.selectList(codeFormVo));
        codeFormVo.setComClassCd("MILL_CD");
        model.addObject("millCdList", codeService.selectList(codeFormVo));
        codeFormVo.setComClassCd("MILLTYPE_CD");
        model.addObject("millTypeCdList", codeService.selectList(codeFormVo));
        codeFormVo.setComClassCd("DISABILITY_GRADE_CD");
        model.addObject("disabilityCdList", codeService.selectList(codeFormVo));
        codeFormVo.setComClassCd("DISABILITY_DIV_CD");
        model.addObject("disabilityDivCdList", codeService.selectList(codeFormVo));

        return model;
    }

    @PostMapping("saveAdmissionCancel.do")
    public ModelAndView saveAdmissionCancel(@RequestBody ApplicantVo applicantVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        tutionRegisterService.saveAdmissionCancel(applicantVo);
        return model;
    }

    @PostMapping("saveTutionRegister.do")
    public ModelAndView saveTutionRegister(@RequestBody ApplicantVo applicantVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        tutionRegisterService.saveTutionRegister(applicantVo);
        return model;
    }

    @PostMapping("selectProfessor.do")
    public ModelAndView selectProfessor(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        List<ApplicantProfessorVo> professorList = tutionRegisterService.selectProfessor(formVo);
        model.addObject("professorList", professorList);
        return model;
    }
}
