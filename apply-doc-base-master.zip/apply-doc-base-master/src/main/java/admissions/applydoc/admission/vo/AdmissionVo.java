package admissions.applydoc.admission.vo;

import admissions.applydoc.applicant.vo.ApplicantSubmitDocVo;
import admissions.common.file.vo.CommonFileVo;
import admissions.common.vo.DataDefaultVo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AdmissionVo extends DataDefaultVo {
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String recruitDegree = "";
    private String recruitScreenCd = "";
    private String fileDivCd = "";
    private String actDivCd = "";
    private String uploadNecesseYn = "";
    private String admissionDocCd = "";
    private String docNm = "";
    private String docEngNm = "";
    private String sortOrder = "";
    private String downloadFileGroupNo = "";
    private String remarkContents = "";
    private String rSeq = "";
    private String submitYn = "";
    private String supportNo = "";
    private String fileGroupNo = "";
    private String beforeFileGroupNo = "";
    private String state = "";
    List<CommonFileVo> downloadFileList = new ArrayList<CommonFileVo>();
    private List<AdmissionVo> submitDocList = new ArrayList<>();

    public List<CommonFileVo> getDownloadFileList() {
        return Collections.unmodifiableList(downloadFileList);
    }

    public void setDownloadFileList(List<CommonFileVo> downloadFileList) {
        this.downloadFileList = Collections.unmodifiableList(downloadFileList);
    }

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getRecruitDegree() {
        return recruitDegree;
    }

    public void setRecruitDegree(String recruitDegree) {
        this.recruitDegree = recruitDegree;
    }

    public String getRecruitScreenCd() {
        return recruitScreenCd;
    }

    public void setRecruitScreenCd(String recruitScreenCd) {
        this.recruitScreenCd = recruitScreenCd;
    }

    public String getFileDivCd() {
        return fileDivCd;
    }

    public void setFileDivCd(String fileDivCd) {
        this.fileDivCd = fileDivCd;
    }

    public String getActDivCd() {
        return actDivCd;
    }

    public void setActDivCd(String actDivCd) {
        this.actDivCd = actDivCd;
    }

    public String getUploadNecesseYn() {
        return uploadNecesseYn;
    }

    public void setUploadNecesseYn(String uploadNecesseYn) {
        this.uploadNecesseYn = uploadNecesseYn;
    }

    public String getAdmissionDocCd() {
        return admissionDocCd;
    }

    public void setAdmissionDocCd(String admissionDocCd) {
        this.admissionDocCd = admissionDocCd;
    }

    public String getDocNm() {
        return docNm;
    }

    public void setDocNm(String docNm) {
        this.docNm = docNm;
    }

    public String getDocEngNm() {
        return docEngNm;
    }

    public void setDocEngNm(String docEngNm) {
        this.docEngNm = docEngNm;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getDownloadFileGroupNo() {
        return downloadFileGroupNo;
    }

    public void setDownloadFileGroupNo(String downloadFileGroupNo) {
        this.downloadFileGroupNo = downloadFileGroupNo;
    }

    public String getRemarkContents() {
        return remarkContents;
    }

    public void setRemarkContents(String remarkContents) {
        this.remarkContents = remarkContents;
    }

    public String getrSeq() {
        return rSeq;
    }

    public void setrSeq(String rSeq) {
        this.rSeq = rSeq;
    }

    public String getSubmitYn() {
        return submitYn;
    }

    public void setSubmitYn(String submitYn) {
        this.submitYn = submitYn;
    }

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getFileGroupNo() {
        return fileGroupNo;
    }

    public void setFileGroupNo(String fileGroupNo) {
        this.fileGroupNo = fileGroupNo;
    }

    public String getBeforeFileGroupNo() {
        return beforeFileGroupNo;
    }

    public void setBeforeFileGroupNo(String beforeFileGroupNo) {
        this.beforeFileGroupNo = beforeFileGroupNo;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<AdmissionVo> getSubmitDocList() {
        return Collections.unmodifiableList(submitDocList);
    }

    public void setSubmitDocList(List<AdmissionVo> submitDocList) {
        this.submitDocList = Collections.unmodifiableList(submitDocList);
    }
}