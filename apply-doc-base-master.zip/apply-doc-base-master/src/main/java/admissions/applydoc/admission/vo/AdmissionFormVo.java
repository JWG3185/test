package admissions.applydoc.admission.vo;

import admissions.common.vo.DataDefaultVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class AdmissionFormVo extends DataDefaultVo {
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String recruitDegree = "";
    private String recruitScreenCd = "";
    private String supportNo = "";
    private String screenNo = "";

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getRecruitDegree() {
        return recruitDegree;
    }

    public void setRecruitDegree(String recruitDegree) {
        this.recruitDegree = recruitDegree;
    }

    public String getRecruitScreenCd() {
        return recruitScreenCd;
    }

    public void setRecruitScreenCd(String recruitScreenCd) {
        this.recruitScreenCd = recruitScreenCd;
    }

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getScreenNo() {
        return screenNo;
    }

    public void setScreenNo(String screenNo) {
        this.screenNo = screenNo;
    }
}
