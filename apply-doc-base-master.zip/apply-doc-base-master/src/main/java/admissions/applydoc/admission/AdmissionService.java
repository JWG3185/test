package admissions.applydoc.admission;

import admissions.applydoc.admission.vo.AdmissionFormVo;
import admissions.applydoc.admission.vo.AdmissionSubmitDocVo;
import admissions.applydoc.admission.vo.AdmissionVo;
import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantSubmitDocVo;
import admissions.applydoc.applicant.vo.ApplicantVo;
import admissions.common.dao.CommonDao;
import admissions.common.file.FileService;
import admissions.common.file.vo.CommonFileVo;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AdmissionService {

    @Autowired
    CommonDao commonDao;

    @Autowired
    FileService fileService;

    public List<AdmissionVo> selectAdmissionSubmitDocList(ApplicantFormVo formVo) {
        List<AdmissionVo> admissionsSubmitDocList = (List<AdmissionVo>) commonDao.selectList("AdmissionMapper.selectAdmissionSubmitDocList", formVo);

        for (AdmissionVo submitDoc : admissionsSubmitDocList) {
            if (StringUtils.isNotEmpty(submitDoc.getDownloadFileGroupNo())) {
                submitDoc.setDownloadFileList((List<CommonFileVo>) fileService.selectList(submitDoc.getDownloadFileGroupNo()));
            }

            if (StringUtils.isNotEmpty(submitDoc.getBeforeFileGroupNo())) {
                submitDoc.setFileList((List<CommonFileVo>) fileService.selectList(submitDoc.getBeforeFileGroupNo()));
            }
        }

        return admissionsSubmitDocList;
    }

    @Transactional
    public void saveAdmissionDocument(AdmissionVo admissionVo) {

        if (!admissionVo.getSubmitDocList().isEmpty()) {

            List<AdmissionVo> submitDocList = admissionVo.getSubmitDocList();

            String fileGroupNo = "";

            for (AdmissionVo submitDocVo : submitDocList) {

                if (submitDocVo.getFileList().isEmpty()) {
                    if (!submitDocVo.getBeforeFileGroupNo().isEmpty()) {
                        fileService.deleteFileGroup(submitDocVo.getBeforeFileGroupNo());
                    }
                    submitDocVo.setFileGroupNo("");
                    continue;
                }
                CommonFileVo fileVo = submitDocVo.getFileList().get(0);
                fileVo.setFirstRegistUserId(admissionVo.getFirstRegistUserId());
                fileVo.setFirstRegistProgramId(admissionVo.getFirstRegistProgramId());
                fileGroupNo = fileService.doSave(submitDocVo.getFileList(), submitDocVo.getBeforeFileGroupNo());
                submitDocVo.setFileGroupNo(fileGroupNo);

            }

            System.out.println("INININ");
            commonDao.update("AdmissionMapper.updateAdmissionSubmitDoc", admissionVo);

        }
    }

}
