package admissions.applydoc.admission;

import admissions.applydoc.admission.vo.AdmissionFormVo;
import admissions.applydoc.admission.vo.AdmissionVo;
import admissions.applydoc.applicant.ApplicantService;
import admissions.applydoc.applicant.vo.ApplicantFormVo;
import admissions.applydoc.applicant.vo.ApplicantVo;
import admissions.applydoc.resultdocument.ResultDocumentService;
import admissions.applydoc.resultdocument.vo.AfrmVo;
import admissions.system.code.CodeService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;

@Controller
@RequestMapping("/admission/")
public class AdmissionController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AdmissionController.class);
    private static final String JSON_VIEW = "jsonView";

    @Autowired
    AdmissionService admissionService;

    @Autowired
    ApplicantService applicantService;

    @Autowired
    ResultDocumentService resultDocumentService;

    @PostMapping("selectAdmissionDocList.do")
    public ModelAndView selectAdmissionDocList(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        ApplicantVo applicant = applicantService.selectApplicant(formVo);
        model.addObject("applicant", applicant);

        AfrmVo afrmVo = resultDocumentService.selectApplicantAfrm(formVo);
        model.addObject("afrm", afrmVo);

        model.addObject("submitDocList", admissionService.selectAdmissionSubmitDocList(formVo));

        return model;
    }

    @PostMapping("saveAdmissionDocument.do")
    public ModelAndView saveAdmissionDocument(@RequestBody AdmissionVo admissionVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        admissionService.saveAdmissionDocument(admissionVo);
        return model;
    }
}
