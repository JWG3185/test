package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantFamilyVo extends DataDefaultVo
{
    String recruitYear = "";
    String supportNo = "";
    String familyNo = "";
    String familyRelateNm = "";
    String belongCd = "";
    String familyName = "";

    public String getRecruitYear() {
        return recruitYear;
    }
    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getSupportNo() {
        return supportNo;
    }
    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getFamilyNo() {
        return familyNo;
    }
    public void setFamilyNo(String familyNo) {
        this.familyNo = familyNo;
    }

    public String getFamilyRelateNm() {
        return familyRelateNm;
    }
    public void setFamilyRelateNm(String familyRelateNm) {
        this.familyRelateNm = familyRelateNm;
    }

    public String getBelongCd() {
        return belongCd;
    }
    public void setBelongCd(String belongCd) {
        this.belongCd = belongCd;
    }

    public String getFamilyName() {
        return familyName;
    }
    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }
}
