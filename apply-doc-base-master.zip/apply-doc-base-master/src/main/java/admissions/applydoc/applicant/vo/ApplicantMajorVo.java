package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantMajorVo extends DataDefaultVo {
    private String recruitMajorCd = "";
    private String recruitMajorNm = "";
    private String recruitMajorEngNm = "";
    private String supportDegreeCd = "";
    private String supportDegreeNm = "";
    private String supportDegreeEngNm = "";
    private String deptShortNmKor = "";
    private String deptShortNmEng = "";

    public String getSupportDegreeNm() {
        return supportDegreeNm;
    }

    public void setSupportDegreeNm(String supportDegreeNm) {
        this.supportDegreeNm = supportDegreeNm;
    }

    public String getSupportDegreeEngNm() {
        return supportDegreeEngNm;
    }

    public void setSupportDegreeEngNm(String supportDegreeEngNm) {
        this.supportDegreeEngNm = supportDegreeEngNm;
    }

    public String getSupportDegreeCd() {
        return supportDegreeCd;
    }

    public void setSupportDegreeCd(String supportDegreeCd) {
        this.supportDegreeCd = supportDegreeCd;
    }

    public String getRecruitMajorCd() {
        return recruitMajorCd;
    }

    public void setRecruitMajorCd(String recruitMajorCd) {
        this.recruitMajorCd = recruitMajorCd;
    }

    public String getRecruitMajorNm() {
        return recruitMajorNm;
    }

    public void setRecruitMajorNm(String recruitMajorNm) {
        this.recruitMajorNm = recruitMajorNm;
    }

    public String getRecruitMajorEngNm() {
        return recruitMajorEngNm;
    }

    public void setRecruitMajorEngNm(String recruitMajorEngNm) {
        this.recruitMajorEngNm = recruitMajorEngNm;
    }

    public String getDeptShortNmKor() {
        return deptShortNmKor;
    }

    public void setDeptShortNmKor(String deptShortNmKor) {
        this.deptShortNmKor = deptShortNmKor;
    }

    public String getDeptShortNmEng() {
        return deptShortNmEng;
    }

    public void setDeptShortNmEng(String deptShortNmEng) {
        this.deptShortNmEng = deptShortNmEng;
    }
}
