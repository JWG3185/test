package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantSurveyAnswerVo extends DataDefaultVo {
	private String recruitYear = "";
	private String recruitPeriodCd = "";
	private String recruitDegree = "";
	private String recruitScreenCd = "";
	private String surveyNo = "";
	private String surveyQstNo = "";
	private String answrContents = "";
	private String answerPoints = "";
	private String etcAnswrContents = "";
	private String answerNo = "";
	private String qstEntryTypeCd = "";

	public String getQstEntryTypeCd() {
		return qstEntryTypeCd;
	}

	public void setQstEntryTypeCd(String qstEntryTypeCd) {
		this.qstEntryTypeCd = qstEntryTypeCd;
	}

	public String getRecruitYear() {
		return recruitYear;
	}

	public void setRecruitYear(String recruitYear) {
		this.recruitYear = recruitYear;
	}

	public String getRecruitPeriodCd() {
		return recruitPeriodCd;
	}

	public void setRecruitPeriodCd(String recruitPeriodCd) {
		this.recruitPeriodCd = recruitPeriodCd;
	}

	public String getRecruitDegree() {
		return recruitDegree;
	}

	public void setRecruitDegree(String recruitDegree) {
		this.recruitDegree = recruitDegree;
	}

	public String getRecruitScreenCd() {
		return recruitScreenCd;
	}

	public void setRecruitScreenCd(String recruitScreenCd) {
		this.recruitScreenCd = recruitScreenCd;
	}

	public String getAnswerNo() {
		return answerNo;
	}

	public void setAnswerNo(String answerNo) {
		this.answerNo = answerNo;
	}

	public String getSurveyNo() {
		return surveyNo;
	}

	public void setSurveyNo(String surveyNo) {
		this.surveyNo = surveyNo;
	}

	public String getSurveyQstNo() {
		return surveyQstNo;
	}

	public void setSurveyQstNo(String surveyQstNo) {
		this.surveyQstNo = surveyQstNo;
	}


	public String getAnswerPoints() {
		return answerPoints;
	}

	public void setAnswerPoints(String answerPoints) {
		this.answerPoints = answerPoints;
	}

	public String getAnswrContents() {
		return answrContents;
	}

	public void setAnswrContents(String answrContents) {
		this.answrContents = answrContents;
	}

	public String getEtcAnswrContents() {
		return etcAnswrContents;
	}

	public void setEtcAnswrContents(String etcAnswrContents) {
		this.etcAnswrContents = etcAnswrContents;
	}
}
