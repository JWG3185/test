package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantMedicalQstVo extends DataDefaultVo {
    private String healthQstNo = "";
    private String healthQstNm = "";
    private String necesseYn = "";
    private String useYn = "";
    private String disabilityQstYn = "";
    private String sortOrder = "";
    private String answrYn = "";
    private String etcContents = "";

    public String getHealthQstNo() {
        return healthQstNo;
    }

    public void setHealthQstNo(String healthQstNo) {
        this.healthQstNo = healthQstNo;
    }

    public String getHealthQstNm() {
        return healthQstNm;
    }

    public void setHealthQstNm(String healthQstNm) {
        this.healthQstNm = healthQstNm;
    }

    public String getNecesseYn() {
        return necesseYn;
    }

    public void setNecesseYn(String necesseYn) {
        this.necesseYn = necesseYn;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getDisabilityQstYn() {
        return disabilityQstYn;
    }

    public void setDisabilityQstYn(String disabilityQstYn) {
        this.disabilityQstYn = disabilityQstYn;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getAnswrYn() {
        return answrYn;
    }

    public void setAnswrYn(String answrYn) {
        this.answrYn = answrYn;
    }

    public String getEtcContents() {
        return etcContents;
    }

    public void setEtcContents(String etcContents) {
        this.etcContents = etcContents;
    }
}
