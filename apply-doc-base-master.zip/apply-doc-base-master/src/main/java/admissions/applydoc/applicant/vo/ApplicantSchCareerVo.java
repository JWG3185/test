package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantSchCareerVo extends DataDefaultVo {
    private String recruitYear = "";
    private String supportNo = "";
    private String schCareerNo = "";
    private String schCareerDivCd = "";
    private String schCareerDivNm = "";
    private String schCareerDivEngNm = "";
    private String schoolCd = "";
    private String schoolNm = "";
    private String entrDt = "";
    private String graduateDt = "";
    private String majorNm = "";
    private String degreeNoNm = "";
    private String degreeDivCd = "";
    private String degreeDivNm = "";
    private String degreeDivEngNm = "";
    private String steadNm = "";
    private String lastScore = "";
    private String scoreCriterion = "";
    private String entrDivCd = "";
    private String entrDivNm = "";
    private String entrDivEngNm = "";
    private String graduateDivCd = "";
    private String graduateDivNm = "";
    private String graduateDivEngNm = "";
    private String completeTermCnt = "";

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getSchCareerNo() {
        return schCareerNo;
    }

    public void setSchCareerNo(String schCareerNo) {
        this.schCareerNo = schCareerNo;
    }

    public String getSchCareerDivCd() {
        return schCareerDivCd;
    }

    public void setSchCareerDivCd(String schCareerDivCd) {
        this.schCareerDivCd = schCareerDivCd;
    }

    public String getSchoolCd() {
        return schoolCd;
    }

    public void setSchoolCd(String schoolCd) {
        this.schoolCd = schoolCd;
    }

    public String getSchoolNm() {
        return schoolNm;
    }

    public void setSchoolNm(String schoolNm) {
        this.schoolNm = schoolNm;
    }

    public String getEntrDt() {
        return entrDt;
    }

    public void setEntrDt(String entrDt) {
        this.entrDt = entrDt;
    }

    public String getGraduateDt() {
        return graduateDt;
    }

    public void setGraduateDt(String graduateDt) {
        this.graduateDt = graduateDt;
    }

    public String getMajorNm() {
        return majorNm;
    }

    public void setMajorNm(String majorNm) {
        this.majorNm = majorNm;
    }

    public String getDegreeNoNm() {
        return degreeNoNm;
    }

    public void setDegreeNoNm(String degreeNoNm) {
        this.degreeNoNm = degreeNoNm;
    }

    public String getDegreeDivCd() {
        return degreeDivCd;
    }

    public void setDegreeDivCd(String degreeDivCd) {
        this.degreeDivCd = degreeDivCd;
    }

    public String getSteadNm() {
        return steadNm;
    }

    public void setSteadNm(String steadNm) {
        this.steadNm = steadNm;
    }

    public String getLastScore() {
        return lastScore;
    }

    public void setLastScore(String lastScore) {
        this.lastScore = lastScore;
    }

    public String getScoreCriterion() {
        return scoreCriterion;
    }

    public void setScoreCriterion(String scoreCriterion) {
        this.scoreCriterion = scoreCriterion;
    }

    public String getEntrDivCd() {
        return entrDivCd;
    }

    public void setEntrDivCd(String entrDivCd) {
        this.entrDivCd = entrDivCd;
    }

    public String getGraduateDivCd() {
        return graduateDivCd;
    }

    public void setGraduateDivCd(String graduateDivCd) {
        this.graduateDivCd = graduateDivCd;
    }

    public String getCompleteTermCnt() {
        return completeTermCnt;
    }

    public void setCompleteTermCnt(String completeTermCnt) {
        this.completeTermCnt = completeTermCnt;
    }

    public String getSchCareerDivNm() {
        return schCareerDivNm;
    }

    public void setSchCareerDivNm(String schCareerDivNm) {
        this.schCareerDivNm = schCareerDivNm;
    }

    public String getSchCareerDivEngNm() {
        return schCareerDivEngNm;
    }

    public void setSchCareerDivEngNm(String schCareerDivEngNm) {
        this.schCareerDivEngNm = schCareerDivEngNm;
    }

    public String getDegreeDivNm() {
        return degreeDivNm;
    }

    public void setDegreeDivNm(String degreeDivNm) {
        this.degreeDivNm = degreeDivNm;
    }

    public String getDegreeDivEngNm() {
        return degreeDivEngNm;
    }

    public void setDegreeDivEngNm(String degreeDivEngNm) {
        this.degreeDivEngNm = degreeDivEngNm;
    }

    public String getGraduateDivNm() {
        return graduateDivNm;
    }

    public void setGraduateDivNm(String graduateDivNm) {
        this.graduateDivNm = graduateDivNm;
    }

    public String getGraduateDivEngNm() {
        return graduateDivEngNm;
    }

    public void setGraduateDivEngNm(String graduateDivEngNm) {
        this.graduateDivEngNm = graduateDivEngNm;
    }

    public String getEntrDivNm() {
        return entrDivNm;
    }

    public void setEntrDivNm(String entrDivNm) {
        this.entrDivNm = entrDivNm;
    }

    public String getEntrDivEngNm() {
        return entrDivEngNm;
    }

    public void setEntrDivEngNm(String entrDivEngNm) {
        this.entrDivEngNm = entrDivEngNm;
    }
}
