package admissions.applydoc.applicant;

import admissions.applydoc.applicant.vo.*;
import admissions.applydoc.resultdocument.vo.AfrmVo;
import admissions.common.auth.AuthService;
import admissions.common.dao.CommonDao;
import admissions.common.file.FileService;
import admissions.common.file.vo.CommonFileVo;
import admissions.common.mail.MailService;
import admissions.common.mail.vo.ComTransferEmailReceiverVo;
import admissions.common.mail.vo.ComTransferEmailVo;
import admissions.system.code.vo.CodeVo;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.outline.PDDocumentOutline;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class ApplicantService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicantService.class);
    @Autowired
    CommonDao commonDao;

    @Autowired
    MailService mailService;

    @Autowired
    FileService fileService;
    @Autowired
    AuthService authService;

    @Value("${proxy.url}")
    private String proxyUrl;

    @Value("${server.kind}")
    private String imgServerKind;

    @Value("${file.upload.dir}")
    private String uploadDir;

    @Value("${clipreport.url}")
    private String clipReportUrl;

    /**
     * 발신 설정
     */
    String dsptchEmlAddr = "help_adm@osolit.net";
    /**
     * sender name
     */
    String dsptchUserNm = "UST사용자서비스";
    /**
     * group email yn
     */
    String groupEmlYn = "N";

    /**
     * 전형 목록
     */
    public List<ApplicantVo> selectScreenList(ApplicantFormVo formVo) {
        return (List<ApplicantVo>) commonDao.selectList("ApplicantMapper.selectScreenList", formVo);
    }

    public ApplicantVo selectPreScreenInfo(ApplicantFormVo formVo) {
        return (ApplicantVo) commonDao.selectOne("ApplicantMapper.selectPreScreenInfo", formVo);
    }

    /**
     * 회원 정보 조회
     */
    public UserVo selectUserInfo(ApplicantFormVo formVo) {
        return (UserVo) commonDao.selectOne("ApplicantMapper.selectUserInfo", formVo);
    }

    public List<CodeVo> selectEngUseNationCdList(ApplicantFormVo formVo) {
        return (List<CodeVo>) commonDao.selectList("ApplicantMapper.selectEngUseNationCdList", formVo);
    }

    /**
     * 설문 질의 목록
     */
    public List<ApplicantSurveyVo> selectSurveyQstList(ApplicantFormVo formVo) {
        return (List<ApplicantSurveyVo>) commonDao.selectList("ApplicantMapper.selectSurveyQstList", formVo);
    }

    /**
     * 설문 답변 목록
     */
    public List<ApplicantSurveyAnswerVo> selectSurveyAnswerList(ApplicantFormVo formVo) {
        return (List<ApplicantSurveyAnswerVo>) commonDao.selectList("ApplicantMapper.selectSurveyAnswerList", formVo);
    }

    /**
     * 설문 저장
     */
    @Transactional
    public void saveSurvey(ApplicantFormVo formVo) {
        commonDao.update("ApplicantMapper.updateSurvey", formVo);

        List<ApplicantSurveyVo> qstList = (List<ApplicantSurveyVo>) commonDao.selectList("ApplicantMapper.selectSurveyQstList", formVo);
        String[] qstNoList = formVo.getSurveyQstNo().split(";");
        for (int index = 0; index < qstNoList.length; index++) {
            String surveyQstNo = qstNoList[index];

            ApplicantSurveyAnswerVo vo = new ApplicantSurveyAnswerVo();
            vo.setRecruitYear(formVo.getRecruitYear());
            vo.setRecruitPeriodCd(formVo.getRecruitPeriodCd());
            vo.setRecruitDegree(formVo.getRecruitDegree());
            vo.setRecruitScreenCd(formVo.getRecruitScreenCd());
            vo.setSurveyNo(formVo.getSurveyNo());
            vo.setSurveyQstNo(surveyQstNo);
            vo.setAnswrContents(formVo.getAnswer(index));
            vo.setAnswerPoints("0");
            vo.setFirstRegistProgramId(formVo.getFirstRegistProgramId());
            vo.setLastUpdateProgramId(formVo.getLastUpdateProgramId());

            ApplicantSurveyVo selectedVo = new ApplicantSurveyVo();
            for (ApplicantSurveyVo vo2 : qstList) {
                if (vo2.getSurveyQstNo().equals(surveyQstNo)) {
                    selectedVo = vo2;
                    break;
                }
            }
            if ("RADIO".equals(selectedVo.getQstEntryTypeCd())) {
                String pointsArray = selectedVo.getRadioPoints();
                String valuesArray = selectedVo.getRadioValues();
                String etcsNo = selectedVo.getRadioEtcs();
                String[] points = pointsArray.split(";", -1);
                String[] values = valuesArray.split(";", -1);
                int pointIndex = -1;
                int valueIndex = -1;
                for (int idx = 0; idx < values.length; idx++) {
                    if (formVo.getAnswer(index).equals(values[idx])) {
                        pointIndex = idx;
                        valueIndex = idx + 1;
                        break;
                    }
                }
                if (pointIndex >= 0) {
                    if ("".equals(points[pointIndex])) {
                        vo.setAnswerPoints("0");
                    } else {
                        vo.setAnswerPoints(points[pointIndex]);
                    }
                }

                if (etcsNo.equals(String.valueOf(valueIndex))) {
                    vo.setEtcAnswrContents(formVo.getAnswerEtc(index));
                }
            } else if (selectedVo.getQstEntryTypeCd().equals("CHECK")) {
                String pointsArray = selectedVo.getCheckPoints();
                String valuesArray = selectedVo.getCheckValues();
                String etcsNo = selectedVo.getCheckEtcs();

                String[] points = pointsArray.split(";", -1);
                String[] values = valuesArray.split(";", -1);

                String[] formValues = formVo.getAnswer(index).split(";");
                StringBuffer answerPoints = new StringBuffer();
                for (int idx = 0; idx < values.length; idx++) {
                    for (String formValue : formValues) {
                        if (formValue.equals(values[idx])) {
                            if (answerPoints.length() > 0) {
                                answerPoints.append(";");
                            }
                            if ("".equals(points[idx])) {
                                answerPoints.append("0");
                            } else {
                                answerPoints.append(points[idx]);
                            }
                        }

                        if (etcsNo.equals(String.valueOf(idx + 1))) {
                            vo.setEtcAnswrContents(formVo.getAnswerEtc(index));
                        }
                    }
                }
                vo.setAnswerPoints(answerPoints.toString());
            }

            commonDao.update("ApplicantMapper.updateSurveyAnswer", vo);
        }
    }

    /**
     * STEP.2 지원자 정보 저장
     */
    @Transactional
    public ApplicantVo saveApplicant(ApplicantVo applicantVo) {

        if (!applicantVo.getPhotoList().isEmpty()) {
            for (Object o : applicantVo.getPhotoList()) {
                CommonFileVo fileVo = (CommonFileVo) o;
                fileVo.setFirstRegistUserId(applicantVo.getFirstRegistUserId());
                fileVo.setFirstRegistProgramId(applicantVo.getFirstRegistProgramId());
            }
            if ("tmp".equals(applicantVo.getPicFileGroupNo())) {
                applicantVo.setPicFileGroupNo("");
            }
            String fileGroupNo = fileService.doSave(applicantVo.getPhotoList(), applicantVo.getPicFileGroupNo());
            applicantVo.setPicFileGroupNo(fileGroupNo);
        }

        if (!applicantVo.getDisabilityProofFileList().isEmpty()) {
            for (Object o : applicantVo.getDisabilityProofFileList()) {
                CommonFileVo fileVo = (CommonFileVo) o;
                fileVo.setFirstRegistUserId(applicantVo.getFirstRegistUserId());
                fileVo.setFirstRegistProgramId(applicantVo.getFirstRegistProgramId());
            }
            if ("tmp".equals(applicantVo.getDisabilityProofFileGroupNo())) {
                applicantVo.setDisabilityProofFileGroupNo("");
            }
            String fileGroupNo = fileService.doSave(applicantVo.getDisabilityProofFileList(), applicantVo.getDisabilityProofFileGroupNo());
            applicantVo.setDisabilityProofFileGroupNo(fileGroupNo);
        } else {
            fileService.deleteFileGroup(applicantVo.getDisabilityProofFileGroupNo());
            applicantVo.setDisabilityProofFileGroupNo("");
        }
        commonDao.update("ApplicantMapper.saveApplicant", applicantVo);

        if (!applicantVo.getSchCareer1List().isEmpty() || !applicantVo.getSchCareer2List().isEmpty()) {
            List<ApplicantSchCareerVo> mergedList = Stream.of(applicantVo.getSchCareer1List(), applicantVo.getSchCareer2List())
                    .flatMap(x -> x.stream())
                    .collect(Collectors.toList());
            applicantVo.setSchCareerList(mergedList);

            commonDao.delete("ApplicantMapper.deleteSchCareer", applicantVo);
            commonDao.update("ApplicantMapper.updateSchCareer", applicantVo);
        } else {
            commonDao.delete("ApplicantMapper.deleteSchCareer", applicantVo);
        }

        if (!applicantVo.getWorkCareerList().isEmpty()) {
            commonDao.delete("ApplicantMapper.deleteWorkCareer", applicantVo);
            commonDao.update("ApplicantMapper.updateWorkCareer", applicantVo);
        } else {
            commonDao.delete("ApplicantMapper.deleteWorkCareer", applicantVo);
        }

        if (!applicantVo.getEtcCareerList().isEmpty()) {
            commonDao.delete("ApplicantMapper.deleteEtcCareer", applicantVo);
            commonDao.update("ApplicantMapper.updateEtcCareer", applicantVo);
        } else {
            commonDao.delete("ApplicantMapper.deleteEtcCareer", applicantVo);
        }

        if (!applicantVo.getEngScoreList().isEmpty()) {
            commonDao.delete("ApplicantMapper.deleteEngScore", applicantVo);
            commonDao.update("ApplicantMapper.updateEngScore", applicantVo);
        } else {
            commonDao.delete("ApplicantMapper.deleteEngScore", applicantVo);
        }

        return applicantVo;

    }

    /**
     * 지원서 조회
     */
    public ApplicantVo selectApplicant(ApplicantFormVo formVo) {

        ApplicantVo applicantVo = (ApplicantVo) commonDao.selectOne("ApplicantMapper.selectApplicant", formVo);

        List<ApplicantSchCareerVo> schCareerList = (List<ApplicantSchCareerVo>) commonDao.selectList("ApplicantMapper.selectSchCareer", formVo);
        if (!schCareerList.isEmpty()) {
            applicantVo.setSchCareer1List(schCareerList.stream().filter(item -> "5".equals(item.getSchCareerDivCd())).collect(Collectors.toList()));
            applicantVo.setSchCareer2List(schCareerList.stream().filter(item -> "6".equals(item.getSchCareerDivCd())).collect(Collectors.toList()));
        }

        List<ApplicantEngScoreVo> engScoreList = (List<ApplicantEngScoreVo>) commonDao.selectList("selectEngScore", formVo);
        if (!engScoreList.isEmpty()) {
            applicantVo.setEngScoreList(engScoreList);
        }

        List<ApplicantCareerVo> workCareerList = (List<ApplicantCareerVo>) commonDao.selectList("selectCareer", formVo);
        if (!workCareerList.isEmpty()) {
            applicantVo.setWorkCareerList(workCareerList);
        }

        List<ApplicantEtcCareerVo> etcCareerList = (List<ApplicantEtcCareerVo>) commonDao.selectList("selectEtcCareer", formVo);
        if (!etcCareerList.isEmpty()) {
            applicantVo.setEtcCareerList(etcCareerList);
        }

        // 첨부파일 셋팅
        if (!ObjectUtils.isEmpty(applicantVo)) {
            if (StringUtils.isNotEmpty(applicantVo.getPicFileGroupNo())) {
                applicantVo.setPhotoList((List<CommonFileVo>) fileService.selectList(applicantVo.getPicFileGroupNo()));
            }
            if (StringUtils.isNotEmpty(applicantVo.getDisabilityProofFileGroupNo())) {
                applicantVo.setDisabilityProofFileList((List<CommonFileVo>) fileService.selectList(applicantVo.getDisabilityProofFileGroupNo()));
            }
        }
        return applicantVo;

    }

    /**
     * 전공
     */
    public List<ApplicantMajorVo> selectMajorDept(ApplicantFormVo formVo) {
        return (List<ApplicantMajorVo>) commonDao.selectList("ApplicantMapper.selectMajorDept", formVo);
    }

    /**
     * 전공
     */
    public List<ApplicantMajorVo> selectMajor(ApplicantFormVo formVo) {
        return (List<ApplicantMajorVo>) commonDao.selectList("ApplicantMapper.selectMajor", formVo);
    }

    /**
     * 기업 전공
     */
    public List<ApplicantMajorVo> selectCompanyMajor(ApplicantFormVo formVo) {
        return (List<ApplicantMajorVo>) commonDao.selectList("ApplicantMapper.selectCompanyMajor", formVo);
    }


    /**
     * supportNo 조회
     */
    public ApplicantVo selectSupportNo(ApplicantFormVo formVO) {
        return (ApplicantVo) commonDao.selectOne("ApplicantMapper.selectSupportNo", formVO);
    }

    public ApplicantVo selectPlanList(ApplicantFormVo formVo) {
        return (ApplicantVo) commonDao.selectOne("ApplicantMapper.selectPlanList", formVo);
    }

    @Transactional
    public void saveApplicantPlan(ApplicantVo applicantVo) {
        commonDao.update("ApplicantMapper.saveApplicantPlan", applicantVo);
    }

    public List<ApplicantSubmitDocVo> selectSubmitDocList(ApplicantFormVo formVo) {

        List<ApplicantSubmitDocVo> applicantSubmitDocList = (List<ApplicantSubmitDocVo>) commonDao.selectList("ApplicantMapper.selectSubmitDocList", formVo);

        for (ApplicantSubmitDocVo submitDoc : applicantSubmitDocList) {
            if (StringUtils.isNotEmpty(submitDoc.getBeforeFileGroupNo())) {
                submitDoc.setFileList((List<CommonFileVo>) fileService.selectList(submitDoc.getBeforeFileGroupNo()));
                ;
            }
        }

        return applicantSubmitDocList;

    }

    public List<ApplicantMedicalQstVo> selectMedicalQstList(ApplicantFormVo formVo) {
        return (List<ApplicantMedicalQstVo>) commonDao.selectList("ApplicantMapper.selectMedicalQstList", formVo);
    }

    public List<ApplicantRcmnderVo> selectRcmnderList(ApplicantFormVo formVo) {
        return (List<ApplicantRcmnderVo>) commonDao.selectList("ApplicantMapper.selectRcmnderList", formVo);
    }

    @Transactional
    public void saveApplicantDocument(ApplicantVo applicantVo) {
        if (!ObjectUtils.isEmpty(applicantVo)) {
            commonDao.update("ApplicantMapper.saveApplicant", applicantVo);
        }
        if (!applicantVo.getSubmitDocList().isEmpty()) {
//			List<ApplicantSubmitDocVo> submitDocList = applicantVo.getSubmitDocList()
//					.stream()
//					.filter(h -> !h.getFileList().isEmpty())
//					.collect(Collectors.toList());
//			List<ApplicantSubmitDocVo> submitDocDeleteList = applicantVo.getSubmitDocList()
//					.stream()
//					.filter(h -> h.getFileList().isEmpty())
//					.collect(Collectors.toList());
//			if(!submitDocDeleteList.isEmpty()){
//				for (int idx = 0; idx < submitDocDeleteList.size(); idx++) {
//					fileService.deleteFileGroup(submitDocDeleteList.get(idx).getBeforeFileGroupNo());
//					commonDao.delete("ApplicantMapper.deleteSubmitDoc", submitDocDeleteList.get(idx));
//				}
//			}
//			if(!submitDocList.isEmpty()) {
//				applicantVo.setSubmitDocList(submitDocList);

            List<ApplicantSubmitDocVo> submitDocList = applicantVo.getSubmitDocList();
            String fileGroupNo = "";
            for (ApplicantSubmitDocVo submitDocVo : submitDocList) {
                if (submitDocVo.getFileList().isEmpty()) {
                    if (!submitDocVo.getBeforeFileGroupNo().isEmpty()) {
                        fileService.deleteFileGroup(submitDocVo.getBeforeFileGroupNo());
                    }
                    submitDocVo.setFileGroupNo("");
                    continue;
                }
                CommonFileVo fileVo = submitDocVo.getFileList().get(0);
                fileVo.setFirstRegistUserId(applicantVo.getFirstRegistUserId());
                fileVo.setFirstRegistProgramId(applicantVo.getFirstRegistProgramId());
                fileGroupNo = fileService.doSave(submitDocVo.getFileList(), submitDocVo.getBeforeFileGroupNo());
                submitDocVo.setFileGroupNo(fileGroupNo);
            }
            commonDao.update("ApplicantMapper.updateSubmitDocList", applicantVo);
//			}
        }

        if ("02".equals(applicantVo.getRcmndDocFormalCd())) {
            commonDao.delete("ApplicantMapper.deleteRcmnderList", applicantVo);
        } else if (!applicantVo.getRcmnderList().isEmpty()) {
            commonDao.update("ApplicantMapper.updateRcmnderList", applicantVo);
        }
    }

    public ApplicantVo selectScreenBySupportNo(ApplicantFormVo formVo) {
        return (ApplicantVo) commonDao.selectOne("ApplicantMapper.selectScreenBySupportNo", formVo);
    }

    @Transactional
    public ApplicantRcmnderVo sendRemnderMail(ApplicantRcmnderVo rcmnderVo) {

        // 추천서 정보 등록

        int count = 0;

        if (!rcmnderVo.getRcmndDiscernNm().isEmpty()) {
            count = Integer.parseInt(commonDao.selectOne("ApplicantMapper.selectRcmndCount", rcmnderVo).toString());
        }

        if (count > 0) {
            // 추천서 정보 UPDATE
            commonDao.update("ApplicantMapper.updateRcmnd", rcmnderVo);
        } else {
            // 추천서 정보 INSERT
            commonDao.insert("ApplicantMapper.insertRcmnd", rcmnderVo);
        }

        // ScreenInfo 정보 얻어오기
        ApplicantFormVo formVo = new ApplicantFormVo();
        formVo.setSupportNo(rcmnderVo.getSupportNo());

        ApplicantVo screenInfo = (ApplicantVo) commonDao.selectOne("ApplicantMapper.selectScreenBySupportNo", formVo);

        formVo.setRecruitYear(screenInfo.getRecruitYear());
        formVo.setRecruitPeriodCd(screenInfo.getRecruitPeriodCd());
        formVo.setRecruitDegree(screenInfo.getRecruitDegree());
        formVo.setRecruitScreenCd(screenInfo.getRecruitScreenCd());

        // Applicant rcmndDocFormalCd 01: 시스템 02: 우편

        ApplicantVo applicantVo = (ApplicantVo) commonDao.selectOne("ApplicantMapper.selectApplicant", formVo);
        applicantVo.setRcmndDocFormalCd("01");

        // 지원자 정보 관련 UPDATE
//        commonDao.update("ApplicantMapper.saveApplicant", applicantVo);
        String EngNm = applicantVo.getEngFirstNm() + " " + applicantVo.getEngMiddleNm() + " " + applicantVo.getEngFamilyNm();
        // 메일 발송 프로세스
        String emlTitle = "[UST] You have been named by the applicant, " + EngNm + " as a referee.";

        ComTransferEmailVo mailVo = new ComTransferEmailVo();
        mailVo.setEmailTitle(emlTitle);
        mailVo.setSenderEmailAddress("help_adm@osolit.net");
        mailVo.setSenderNm("UST Admission");
        mailVo.setMultimailYn("N");
        mailVo.setFirstRegistUserId(rcmnderVo.getFirstRegistUserId());
        mailVo.setFirstRegistUserIp(rcmnderVo.getFirstRegistUserIp());
        mailVo.setFirstRegistProgramId(rcmnderVo.getFirstRegistProgramId());

        // 발신 내용 설정
        HashMap<String, String> contentMap = new HashMap<String, String>();
        contentMap.put("proxyUrl", proxyUrl);
        contentMap.put("rcmndDiscernNm", rcmnderVo.getRcmndDiscernNm());
        contentMap.put("serviceUrl", proxyUrl);
        contentMap.put("EngNm", EngNm);
        contentMap.put("afrmRegistEndTxt", screenInfo.getAfrmRegistEndTxt());
        mailVo.setContentMap(contentMap);

        // 수신 설정
        List<ComTransferEmailReceiverVo> recipientList = new ArrayList<ComTransferEmailReceiverVo>();
        ComTransferEmailReceiverVo recipientVo = new ComTransferEmailReceiverVo();
        recipientVo.setReceiverNm(rcmnderVo.getRcmnderName());
        recipientVo.setReceiverEmailAddress(rcmnderVo.getRcmnderEmailAddress());
        recipientVo.setReceiveTypeCd("R");

        // 수신 목록 세팅
        recipientList.add(recipientVo);
        mailVo.setRecipientList(recipientList);

        // 메일 정보 입력
        int pkEmlSndng = mailService.insertMailInfo(mailVo, "rcmnderMail");

        //이메일 발송
        mailService.sendEmail(String.valueOf(pkEmlSndng));
        commonDao.update("ApplicantMapper.updateRemnderRequestDate", rcmnderVo);

        return rcmnderVo;
    }

    @Transactional
    public void deleteRemnder(ApplicantRcmnderVo rcmnderVo) {
        commonDao.delete("ApplicantMapper.deleteRemnderDoc", rcmnderVo);
        commonDao.delete("ApplicantMapper.deleteRemnder", rcmnderVo);
    }

    @Transactional
    public void saveSubmit(ApplicantFormVo formVo) {
        ApplicantVo applicantVo = (ApplicantVo) commonDao.selectOne("ApplicantMapper.selectApplicant", formVo);
        applicantVo.setAdocWriteStepCd(formVo.getAdocWriteStepCd());
        applicantVo.setLastUpdateProgramId(formVo.getLastUpdateProgramId());
        commonDao.update("ApplicantMapper.saveApplicant", applicantVo);

        AfrmVo afrmVo = new AfrmVo();
        afrmVo.setRecruitYear(applicantVo.getRecruitYear());
        afrmVo.setRecruitPeriodCd(applicantVo.getRecruitPeriodCd());
        afrmVo.setRecruitDegree(applicantVo.getRecruitDegree());
        afrmVo.setRecruitScreenCd(applicantVo.getRecruitScreenCd());
        afrmVo.setSupportNo(applicantVo.getSupportNo());
        afrmVo.setFirstRegistProgramId(applicantVo.getFirstRegistProgramId());
        afrmVo.setLastUpdateProgramId(applicantVo.getLastUpdateProgramId());

        commonDao.update("ApplicantMapper.updateApplicantAfrm", afrmVo);
//
//        String locale = formVo.getUseLanguage();
//        String korTitle = "[" + applicantVo.getScreenNm() + "] 원서접수 완료";
//        String engTitle = "[" + applicantVo.getScreenNm() + "] Completed Submission of Application Form";
//        // 메읿 발송 프로세스
//        String emlTitle = "ko".equals(locale) ? korTitle : engTitle;
//
//        ComTransferEmailVo mailVo = new ComTransferEmailVo();
//        mailVo.setEmailTitle(emlTitle);
//        mailVo.setSenderEmailAddress(dsptchEmlAddr);
//        mailVo.setSenderNm(dsptchUserNm);
//        mailVo.setMultimailYn(groupEmlYn);
//        mailVo.setSendRequestId(applicantVo.getUserId());
//        mailVo.setFirstRegistProgramId(formVo.getFirstRegistProgramId());
//
//        // 발신 내용 설정
//        HashMap<String, String> contentMap = new HashMap<String, String>();
//        contentMap.put("proxyUrl", proxyUrl);
//        contentMap.put("locale", locale);
//        contentMap.put("category", "ko".equals(locale) ? applicantVo.getScreenNm() : applicantVo.getScreenNm());
//        contentMap.put("name", "ko".equals(locale) ? applicantVo.getKorNm() : applicantVo.getEngFirstNm() + " " + applicantVo.getEngMiddleNm() + " " + applicantVo.getEngFamilyNm());
////        contentMap.put("campus", "ko".equals(locale) ? applicantVo.getCampusSchoolNm() : applicantVo.getCampusSchoolEngNm());
////        contentMap.put("major", "ko".equals(locale) ? applicantVo.getRecruitMajorNm() + "(" + applicantVo.getDetailMajorNm() + ")"
////                : applicantVo.getRecruitMajorEngNm() + "(" + applicantVo.getDetailMajorEngNm() + ")");
//        mailVo.setContentMap(contentMap);
//
//        // 수신 설정
//        List<ComTransferEmailReceiverVo> recipientList = new ArrayList<>();
//        ComTransferEmailReceiverVo recipientVo = new ComTransferEmailReceiverVo();
//        recipientVo.setReceiverNm("ko".equals(locale) ? applicantVo.getKorNm() : applicantVo.getEngFirstNm() + applicantVo.getEngMiddleNm() + applicantVo.getEngFamilyNm());
//        recipientVo.setReceiverEmailAddress(applicantVo.getEmailAddress());
//        recipientVo.setReceiveTypeCd("R");
//        // 수신 목록 세팅
//        recipientList.add(recipientVo);
//        mailVo.setRecipientList(recipientList);
//
//        // 메일 정보 입력
//        int pkEmlSndng = mailService.insertMailInfo(mailVo, "applicantSubmitMail");
//
//        //이메일 발송
//        mailService.sendEmail(String.valueOf(pkEmlSndng));
    }

    public Map checkServerTime(ApplicantFormVo formVo) {
        return (Map) commonDao.selectOne("ApplicantMapper.checkServerTime", formVo);
    }

    public File downloadPdf(ApplicantVo vo) {
        File pdfDir = new File(uploadDir + File.separator + "pdf");
        if (!pdfDir.exists() || !pdfDir.isDirectory()) {
            boolean res = pdfDir.mkdirs();
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("make dir res: " + res);
            }
        }

        String localFilePath = "";

        // 원서
        String imgServerIp = "http://172.16.6.215:83";
        if (imgServerKind.equals("front")) {
            imgServerIp = "http://210.98.46.41:9983";
        }
        String params = vo.getRecruitYear() + "|" + vo.getRecruitPeriodCd() + "|" + vo.getRecruitDegree() + "|" + vo.getRecruitScreenCd() + "|" + vo.getSupportNo() + "|" + imgServerIp;
        String encryptedParam = "";
        String encodedParams = "";
        try {
            encryptedParam = authService.encryptAES256(params);
            encodedParams = URLEncoder.encode(encryptedParam, "UTF-8");
        } catch (Exception e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        StringBuffer fileUrl = new StringBuffer();
        String useLanguage = (String) commonDao.selectOne("ApplicantMapper.selectUseLanguage", vo);

        fileUrl.append(clipReportUrl.replaceAll("recruit_report.jsp", "recruit_exportForPDF.jsp"));
        fileUrl.append("?crfName=r010_application_" + useLanguage.toLowerCase() + ".crf");
        fileUrl.append("&params=" + encodedParams);

        localFilePath = uploadDir + File.separator + "pdf" + File.separator + "form" + vo.getRecruitYear() + "_" + vo.getRecruitPeriodCd() + "_" + vo.getRecruitDegree() + "_" + vo.getRecruitScreenCd() + "_" + vo.getSupportNo() + ".pdf";

        try {
            URL url = new URL(fileUrl.toString());
            try (InputStream in = url.openStream()) {
                // 로컬 파일에 스트림 데이터 저장
                try (OutputStream out = new FileOutputStream(localFilePath)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                }
            }
            File docFile = new File(localFilePath);
            if (docFile.isFile()) {
                PDDocument document = PDDocument.load(docFile);

                try {
                    PDDocumentOutline documentOutline = new PDDocumentOutline();

                    // Create a new bookmark item
                    PDOutlineItem bookmark = new PDOutlineItem();
                    bookmark.setTitle("application_form");
                    bookmark.setDestination(document.getPage(0));

                    // Add the bookmark to the outline
                    documentOutline.addFirst(bookmark);

                    // Set the document outline
                    document.getDocumentCatalog().setDocumentOutline(documentOutline);
                    document.save(localFilePath);
                } catch (IOException e) {
                    if (LOGGER.isErrorEnabled()) {
                        LOGGER.error(e.getMessage(), e);
                    }
                } finally {
                    document.close();
                }
            }
        } catch (IOException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }
        // 원서 여기까지

        return new File(localFilePath);
    }

}
