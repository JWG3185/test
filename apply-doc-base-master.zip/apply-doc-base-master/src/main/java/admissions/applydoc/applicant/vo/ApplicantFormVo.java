package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ApplicantFormVo extends DataDefaultVo {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicantFormVo.class);
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String recruitDegree = "";
    private String recruitScreenCd = "";
    private String adocWriteStepCd = "";
    private String campusSchoolCd = "";
    private String userId = "";
    private String supportNo = "";
    private String screenNo = "";
    private String useLanguage = "";
    private String surveyNo = "";
    private String surveyQstNo = "";
    private String supportDegreeCd = "";
    private String degreeDivCd = "";
    private String docDivCd = "";
    private String passNoticeCd = "";
    private String cmiteDivCd = "";
    private String screenFeePayAmount = "";
    private String screenFeePayDivCd = "";
    private String di = "";
    private String answer0 = "";
    private String answer1 = "";
    private String answer2 = "";
    private String answer3 = "";
    private String answer4 = "";
    private String answer5 = "";
    private String answer6 = "";
    private String answer7 = "";
    private String answer8 = "";
    private String answer9 = "";
    private String answer10 = "";
    private String answer11 = "";
    private String answer12 = "";
    private String answer13 = "";
    private String answer14 = "";
    private String answer15 = "";
    private String answer16 = "";
    private String answer17 = "";
    private String answer18 = "";
    private String answer19 = "";
    private String answer20 = "";
    private String answer21 = "";
    private String answer22 = "";
    private String answer23 = "";
    private String answer24 = "";
    private String answer25 = "";
    private String answer26 = "";
    private String answer27 = "";
    private String answer28 = "";
    private String answer29 = "";
    private String answer30 = "";
    private String answer31 = "";
    private String answer32 = "";
    private String answer33 = "";
    private String answer34 = "";
    private String answer35 = "";
    private String answer36 = "";
    private String answer37 = "";
    private String answer38 = "";
    private String answer39 = "";
    private String answer40 = "";
    private String answer41 = "";
    private String answer42 = "";
    private String answer43 = "";
    private String answer44 = "";
    private String answer45 = "";
    private String answer46 = "";
    private String answer47 = "";
    private String answer48 = "";
    private String answer49 = "";
    private String answer50 = "";
    private String answer0Etc = "";
    private String answer1Etc = "";
    private String answer2Etc = "";
    private String answer3Etc = "";
    private String answer4Etc = "";
    private String answer5Etc = "";
    private String answer6Etc = "";
    private String answer7Etc = "";
    private String answer8Etc = "";
    private String answer9Etc = "";
    private String answer10Etc = "";
    private String answer11Etc = "";
    private String answer12Etc = "";
    private String answer13Etc = "";
    private String answer14Etc = "";
    private String answer15Etc = "";
    private String answer16Etc = "";
    private String answer17Etc = "";
    private String answer18Etc = "";
    private String answer19Etc = "";
    private String answer20Etc = "";
    private String answer21Etc = "";
    private String answer22Etc = "";
    private String answer23Etc = "";
    private String answer24Etc = "";
    private String answer25Etc = "";
    private String answer26Etc = "";
    private String answer27Etc = "";
    private String answer28Etc = "";
    private String answer29Etc = "";
    private String answer30Etc = "";
    private String answer31Etc = "";
    private String answer32Etc = "";
    private String answer33Etc = "";
    private String answer34Etc = "";
    private String answer35Etc = "";
    private String answer36Etc = "";
    private String answer37Etc = "";
    private String answer38Etc = "";
    private String answer39Etc = "";
    private String answer40Etc = "";
    private String answer41Etc = "";
    private String answer42Etc = "";
    private String answer43Etc = "";
    private String answer44Etc = "";
    private String answer45Etc = "";
    private String answer46Etc = "";
    private String answer47Etc = "";
    private String answer48Etc = "";
    private String answer49Etc = "";
    private String answer50Etc = "";

    public String getDegreeDivCd() {
        return degreeDivCd;
    }

    public void setDegreeDivCd(String degreeDivCd) {
        this.degreeDivCd = degreeDivCd;
    }

    public String getAnswer0() {
        return answer0;
    }

    public void setAnswer0(String answer0) {
        this.answer0 = answer0;
    }

    public String getAnswer0Etc() {
        return answer0Etc;
    }

    public void setAnswer0Etc(String answer0Etc) {
        this.answer0Etc = answer0Etc;
    }

    public String getAnswer(int index) {
        String answer = "";
        String methodName = "getAnswer" + String.valueOf(index);
        try {
            Method method = this.getClass().getMethod(methodName);
            answer = (String) method.invoke(this);
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException |
                 InvocationTargetException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage().replaceAll("[\r\n]", ""));
            }
        }

        return answer;
    }

    public String getAnswerEtc(int index) {
        String answer = "";
        String methodName = "getAnswer" + String.valueOf(index) + "Etc";
        try {
            Method method = this.getClass().getMethod(methodName);
            answer = (String) method.invoke(this);
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException |
                 InvocationTargetException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage().replaceAll("[\r\n]", ""));
            }
        }

        return answer;
    }

    public String getCampusSchoolCd() {
        return campusSchoolCd;
    }

    public void setCampusSchoolCd(String campusSchoolCd) {
        this.campusSchoolCd = campusSchoolCd;
    }

    public String getSupportDegreeCd() {
        return supportDegreeCd;
    }

    public void setSupportDegreeCd(String supportDegreeCd) {
        this.supportDegreeCd = supportDegreeCd;
    }

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getAnswer1() {
        return answer1;
    }

    public void setAnswer1(String answer1) {
        this.answer1 = answer1;
    }

    public String getAnswer2() {
        return answer2;
    }

    public void setAnswer2(String answer2) {
        this.answer2 = answer2;
    }

    public String getAnswer3() {
        return answer3;
    }

    public void setAnswer3(String answer3) {
        this.answer3 = answer3;
    }

    public String getAnswer4() {
        return answer4;
    }

    public void setAnswer4(String answer4) {
        this.answer4 = answer4;
    }

    public String getAnswer5() {
        return answer5;
    }

    public void setAnswer5(String answer5) {
        this.answer5 = answer5;
    }

    public String getAnswer6() {
        return answer6;
    }

    public void setAnswer6(String answer6) {
        this.answer6 = answer6;
    }

    public String getAnswer7() {
        return answer7;
    }

    public void setAnswer7(String answer7) {
        this.answer7 = answer7;
    }

    public String getAnswer8() {
        return answer8;
    }

    public void setAnswer8(String answer8) {
        this.answer8 = answer8;
    }

    public String getAnswer9() {
        return answer9;
    }

    public void setAnswer9(String answer9) {
        this.answer9 = answer9;
    }

    public String getAnswer10() {
        return answer10;
    }

    public void setAnswer10(String answer10) {
        this.answer10 = answer10;
    }

    public String getAnswer11() {
        return answer11;
    }

    public void setAnswer11(String answer11) {
        this.answer11 = answer11;
    }

    public String getAnswer12() {
        return answer12;
    }

    public void setAnswer12(String answer12) {
        this.answer12 = answer12;
    }

    public String getAnswer13() {
        return answer13;
    }

    public void setAnswer13(String answer13) {
        this.answer13 = answer13;
    }

    public String getAnswer14() {
        return answer14;
    }

    public void setAnswer14(String answer14) {
        this.answer14 = answer14;
    }

    public String getAnswer15() {
        return answer15;
    }

    public void setAnswer15(String answer15) {
        this.answer15 = answer15;
    }

    public String getAnswer16() {
        return answer16;
    }

    public void setAnswer16(String answer16) {
        this.answer16 = answer16;
    }

    public String getAnswer17() {
        return answer17;
    }

    public void setAnswer17(String answer17) {
        this.answer17 = answer17;
    }

    public String getAnswer18() {
        return answer18;
    }

    public void setAnswer18(String answer18) {
        this.answer18 = answer18;
    }

    public String getAnswer19() {
        return answer19;
    }

    public void setAnswer19(String answer19) {
        this.answer19 = answer19;
    }

    public String getAnswer20() {
        return answer20;
    }

    public void setAnswer20(String answer20) {
        this.answer20 = answer20;
    }

    public String getAnswer21() {
        return answer21;
    }

    public void setAnswer21(String answer21) {
        this.answer21 = answer21;
    }

    public String getAnswer22() {
        return answer22;
    }

    public void setAnswer22(String answer22) {
        this.answer22 = answer22;
    }

    public String getAnswer23() {
        return answer23;
    }

    public void setAnswer23(String answer23) {
        this.answer23 = answer23;
    }

    public String getAnswer24() {
        return answer24;
    }

    public void setAnswer24(String answer24) {
        this.answer24 = answer24;
    }

    public String getAnswer25() {
        return answer25;
    }

    public void setAnswer25(String answer25) {
        this.answer25 = answer25;
    }

    public String getAnswer26() {
        return answer26;
    }

    public void setAnswer26(String answer26) {
        this.answer26 = answer26;
    }

    public String getAnswer27() {
        return answer27;
    }

    public void setAnswer27(String answer27) {
        this.answer27 = answer27;
    }

    public String getAnswer28() {
        return answer28;
    }

    public void setAnswer28(String answer28) {
        this.answer28 = answer28;
    }

    public String getAnswer29() {
        return answer29;
    }

    public void setAnswer29(String answer29) {
        this.answer29 = answer29;
    }

    public String getAnswer30() {
        return answer30;
    }

    public void setAnswer30(String answer30) {
        this.answer30 = answer30;
    }

    public String getAnswer31() {
        return answer31;
    }

    public void setAnswer31(String answer31) {
        this.answer31 = answer31;
    }

    public String getAnswer32() {
        return answer32;
    }

    public void setAnswer32(String answer32) {
        this.answer32 = answer32;
    }

    public String getAnswer33() {
        return answer33;
    }

    public void setAnswer33(String answer33) {
        this.answer33 = answer33;
    }

    public String getAnswer34() {
        return answer34;
    }

    public void setAnswer34(String answer34) {
        this.answer34 = answer34;
    }

    public String getAnswer35() {
        return answer35;
    }

    public void setAnswer35(String answer35) {
        this.answer35 = answer35;
    }

    public String getAnswer36() {
        return answer36;
    }

    public void setAnswer36(String answer36) {
        this.answer36 = answer36;
    }

    public String getAnswer37() {
        return answer37;
    }

    public void setAnswer37(String answer37) {
        this.answer37 = answer37;
    }

    public String getAnswer38() {
        return answer38;
    }

    public void setAnswer38(String answer38) {
        this.answer38 = answer38;
    }

    public String getAnswer39() {
        return answer39;
    }

    public void setAnswer39(String answer39) {
        this.answer39 = answer39;
    }

    public String getAnswer40() {
        return answer40;
    }

    public void setAnswer40(String answer40) {
        this.answer40 = answer40;
    }

    public String getAnswer41() {
        return answer41;
    }

    public void setAnswer41(String answer41) {
        this.answer41 = answer41;
    }

    public String getAnswer42() {
        return answer42;
    }

    public void setAnswer42(String answer42) {
        this.answer42 = answer42;
    }

    public String getAnswer43() {
        return answer43;
    }

    public void setAnswer43(String answer43) {
        this.answer43 = answer43;
    }

    public String getAnswer44() {
        return answer44;
    }

    public void setAnswer44(String answer44) {
        this.answer44 = answer44;
    }

    public String getAnswer45() {
        return answer45;
    }

    public void setAnswer45(String answer45) {
        this.answer45 = answer45;
    }

    public String getAnswer46() {
        return answer46;
    }

    public void setAnswer46(String answer46) {
        this.answer46 = answer46;
    }

    public String getAnswer47() {
        return answer47;
    }

    public void setAnswer47(String answer47) {
        this.answer47 = answer47;
    }

    public String getAnswer48() {
        return answer48;
    }

    public void setAnswer48(String answer48) {
        this.answer48 = answer48;
    }

    public String getAnswer49() {
        return answer49;
    }

    public void setAnswer49(String answer49) {
        this.answer49 = answer49;
    }

    public String getAnswer50() {
        return answer50;
    }

    public void setAnswer50(String answer50) {
        this.answer50 = answer50;
    }

    public String getAnswer1Etc() {
        return answer1Etc;
    }

    public void setAnswer1Etc(String answer1Etc) {
        this.answer1Etc = answer1Etc;
    }

    public String getAnswer2Etc() {
        return answer2Etc;
    }

    public void setAnswer2Etc(String answer2Etc) {
        this.answer2Etc = answer2Etc;
    }

    public String getAnswer3Etc() {
        return answer3Etc;
    }

    public void setAnswer3Etc(String answer3Etc) {
        this.answer3Etc = answer3Etc;
    }

    public String getAnswer4Etc() {
        return answer4Etc;
    }

    public void setAnswer4Etc(String answer4Etc) {
        this.answer4Etc = answer4Etc;
    }

    public String getAnswer5Etc() {
        return answer5Etc;
    }

    public void setAnswer5Etc(String answer5Etc) {
        this.answer5Etc = answer5Etc;
    }

    public String getAnswer6Etc() {
        return answer6Etc;
    }

    public void setAnswer6Etc(String answer6Etc) {
        this.answer6Etc = answer6Etc;
    }

    public String getAnswer7Etc() {
        return answer7Etc;
    }

    public void setAnswer7Etc(String answer7Etc) {
        this.answer7Etc = answer7Etc;
    }

    public String getAnswer8Etc() {
        return answer8Etc;
    }

    public void setAnswer8Etc(String answer8Etc) {
        this.answer8Etc = answer8Etc;
    }

    public String getAnswer9Etc() {
        return answer9Etc;
    }

    public void setAnswer9Etc(String answer9Etc) {
        this.answer9Etc = answer9Etc;
    }

    public String getAnswer10Etc() {
        return answer10Etc;
    }

    public void setAnswer10Etc(String answer10Etc) {
        this.answer10Etc = answer10Etc;
    }

    public String getAnswer11Etc() {
        return answer11Etc;
    }

    public void setAnswer11Etc(String answer11Etc) {
        this.answer11Etc = answer11Etc;
    }

    public String getAnswer12Etc() {
        return answer12Etc;
    }

    public void setAnswer12Etc(String answer12Etc) {
        this.answer12Etc = answer12Etc;
    }

    public String getAnswer13Etc() {
        return answer13Etc;
    }

    public void setAnswer13Etc(String answer13Etc) {
        this.answer13Etc = answer13Etc;
    }

    public String getAnswer14Etc() {
        return answer14Etc;
    }

    public void setAnswer14Etc(String answer14Etc) {
        this.answer14Etc = answer14Etc;
    }

    public String getAnswer15Etc() {
        return answer15Etc;
    }

    public void setAnswer15Etc(String answer15Etc) {
        this.answer15Etc = answer15Etc;
    }

    public String getAnswer16Etc() {
        return answer16Etc;
    }

    public void setAnswer16Etc(String answer16Etc) {
        this.answer16Etc = answer16Etc;
    }

    public String getAnswer17Etc() {
        return answer17Etc;
    }

    public void setAnswer17Etc(String answer17Etc) {
        this.answer17Etc = answer17Etc;
    }

    public String getAnswer18Etc() {
        return answer18Etc;
    }

    public void setAnswer18Etc(String answer18Etc) {
        this.answer18Etc = answer18Etc;
    }

    public String getAnswer19Etc() {
        return answer19Etc;
    }

    public void setAnswer19Etc(String answer19Etc) {
        this.answer19Etc = answer19Etc;
    }

    public String getAnswer20Etc() {
        return answer20Etc;
    }

    public void setAnswer20Etc(String answer20Etc) {
        this.answer20Etc = answer20Etc;
    }

    public String getAnswer21Etc() {
        return answer21Etc;
    }

    public void setAnswer21Etc(String answer21Etc) {
        this.answer21Etc = answer21Etc;
    }

    public String getAnswer22Etc() {
        return answer22Etc;
    }

    public void setAnswer22Etc(String answer22Etc) {
        this.answer22Etc = answer22Etc;
    }

    public String getAnswer23Etc() {
        return answer23Etc;
    }

    public void setAnswer23Etc(String answer23Etc) {
        this.answer23Etc = answer23Etc;
    }

    public String getAnswer24Etc() {
        return answer24Etc;
    }

    public void setAnswer24Etc(String answer24Etc) {
        this.answer24Etc = answer24Etc;
    }

    public String getAnswer25Etc() {
        return answer25Etc;
    }

    public void setAnswer25Etc(String answer25Etc) {
        this.answer25Etc = answer25Etc;
    }

    public String getAnswer26Etc() {
        return answer26Etc;
    }

    public void setAnswer26Etc(String answer26Etc) {
        this.answer26Etc = answer26Etc;
    }

    public String getAnswer27Etc() {
        return answer27Etc;
    }

    public void setAnswer27Etc(String answer27Etc) {
        this.answer27Etc = answer27Etc;
    }

    public String getAnswer28Etc() {
        return answer28Etc;
    }

    public void setAnswer28Etc(String answer28Etc) {
        this.answer28Etc = answer28Etc;
    }

    public String getAnswer29Etc() {
        return answer29Etc;
    }

    public void setAnswer29Etc(String answer29Etc) {
        this.answer29Etc = answer29Etc;
    }

    public String getAnswer30Etc() {
        return answer30Etc;
    }

    public void setAnswer30Etc(String answer30Etc) {
        this.answer30Etc = answer30Etc;
    }

    public String getAnswer31Etc() {
        return answer31Etc;
    }

    public void setAnswer31Etc(String answer31Etc) {
        this.answer31Etc = answer31Etc;
    }

    public String getAnswer32Etc() {
        return answer32Etc;
    }

    public void setAnswer32Etc(String answer32Etc) {
        this.answer32Etc = answer32Etc;
    }

    public String getAnswer33Etc() {
        return answer33Etc;
    }

    public void setAnswer33Etc(String answer33Etc) {
        this.answer33Etc = answer33Etc;
    }

    public String getAnswer34Etc() {
        return answer34Etc;
    }

    public void setAnswer34Etc(String answer34Etc) {
        this.answer34Etc = answer34Etc;
    }

    public String getAnswer35Etc() {
        return answer35Etc;
    }

    public void setAnswer35Etc(String answer35Etc) {
        this.answer35Etc = answer35Etc;
    }

    public String getAnswer36Etc() {
        return answer36Etc;
    }

    public void setAnswer36Etc(String answer36Etc) {
        this.answer36Etc = answer36Etc;
    }

    public String getAnswer37Etc() {
        return answer37Etc;
    }

    public void setAnswer37Etc(String answer37Etc) {
        this.answer37Etc = answer37Etc;
    }

    public String getAnswer38Etc() {
        return answer38Etc;
    }

    public void setAnswer38Etc(String answer38Etc) {
        this.answer38Etc = answer38Etc;
    }

    public String getAnswer39Etc() {
        return answer39Etc;
    }

    public void setAnswer39Etc(String answer39Etc) {
        this.answer39Etc = answer39Etc;
    }

    public String getAnswer40Etc() {
        return answer40Etc;
    }

    public void setAnswer40Etc(String answer40Etc) {
        this.answer40Etc = answer40Etc;
    }

    public String getAnswer41Etc() {
        return answer41Etc;
    }

    public void setAnswer41Etc(String answer41Etc) {
        this.answer41Etc = answer41Etc;
    }

    public String getAnswer42Etc() {
        return answer42Etc;
    }

    public void setAnswer42Etc(String answer42Etc) {
        this.answer42Etc = answer42Etc;
    }

    public String getAnswer43Etc() {
        return answer43Etc;
    }

    public void setAnswer43Etc(String answer43Etc) {
        this.answer43Etc = answer43Etc;
    }

    public String getAnswer44Etc() {
        return answer44Etc;
    }

    public void setAnswer44Etc(String answer44Etc) {
        this.answer44Etc = answer44Etc;
    }

    public String getAnswer45Etc() {
        return answer45Etc;
    }

    public void setAnswer45Etc(String answer45Etc) {
        this.answer45Etc = answer45Etc;
    }

    public String getAnswer46Etc() {
        return answer46Etc;
    }

    public void setAnswer46Etc(String answer46Etc) {
        this.answer46Etc = answer46Etc;
    }

    public String getAnswer47Etc() {
        return answer47Etc;
    }

    public void setAnswer47Etc(String answer47Etc) {
        this.answer47Etc = answer47Etc;
    }

    public String getAnswer48Etc() {
        return answer48Etc;
    }

    public void setAnswer48Etc(String answer48Etc) {
        this.answer48Etc = answer48Etc;
    }

    public String getAnswer49Etc() {
        return answer49Etc;
    }

    public void setAnswer49Etc(String answer49Etc) {
        this.answer49Etc = answer49Etc;
    }

    public String getAnswer50Etc() {
        return answer50Etc;
    }

    public void setAnswer50Etc(String answer50Etc) {
        this.answer50Etc = answer50Etc;
    }

    public String getUseLanguage() {
        return useLanguage;
    }

    public void setUseLanguage(String useLanguage) {
        this.useLanguage = useLanguage;
    }

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getRecruitDegree() {
        return recruitDegree;
    }

    public void setRecruitDegree(String recruitDegree) {
        this.recruitDegree = recruitDegree;
    }

    public String getRecruitScreenCd() {
        return recruitScreenCd;
    }

    public void setRecruitScreenCd(String recruitScreenCd) {
        this.recruitScreenCd = recruitScreenCd;
    }

    public String getSurveyNo() {
        return surveyNo;
    }

    public void setSurveyNo(String surveyNo) {
        this.surveyNo = surveyNo;
    }

    public String getSurveyQstNo() {
        return surveyQstNo;
    }

    public void setSurveyQstNo(String surveyQstNo) {
        this.surveyQstNo = surveyQstNo;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAdocWriteStepCd() {
        return adocWriteStepCd;
    }

    public void setAdocWriteStepCd(String adocWriteStepCd) {
        this.adocWriteStepCd = adocWriteStepCd;
    }

    public String getDocDivCd() {
        return docDivCd;
    }

    public void setDocDivCd(String docDivCd) {
        this.docDivCd = docDivCd;
    }

    public String getPassNoticeCd() {
        return passNoticeCd;
    }

    public void setPassNoticeCd(String passNoticeCd) {
        this.passNoticeCd = passNoticeCd;
    }

    public String getScreenNo() {
        return screenNo;
    }

    public void setScreenNo(String screenNo) {
        this.screenNo = screenNo;
    }

    public String getCmiteDivCd() {
        return cmiteDivCd;
    }

    public void setCmiteDivCd(String cmiteDivCd) {
        this.cmiteDivCd = cmiteDivCd;
    }

    public String getScreenFeePayAmount() {
        return screenFeePayAmount;
    }

    public void setScreenFeePayAmount(String screenFeePayAmount) {
        this.screenFeePayAmount = screenFeePayAmount;
    }

    public String getScreenFeePayDivCd() {
        return screenFeePayDivCd;
    }

    public void setScreenFeePayDivCd(String screenFeePayDivCd) {
        this.screenFeePayDivCd = screenFeePayDivCd;
    }

    public String getDi() {
        return di;
    }

    public void setDi(String di) {
        this.di = di;
    }
}
