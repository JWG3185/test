package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantCareerVo extends DataDefaultVo {
    private String recruitYear = "";
    private String supportNo = "";
    private String careerNo = "";
    private String orgNm = "";
    private String workStartDt = "";
    private String workEndDt = "";
    private String deptPositionNm = "";
    private String chargeWorkNm = "";
    private String careerPeriodNm = "";
    private String careerShapeCd = "";
    private String careerShapeNm = "";
    private String careerShapeEngNm = "";
    private String orgCategory = "";
    private String orgNation = "";
    private String orgNationNm = "";
    private String orgNationEngNm = "";
    private String orgCategoryNm = "";
    private String orgCategoryEngNm = "";
    private String workYn = "";

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getCareerNo() {
        return careerNo;
    }

    public void setCareerNo(String careerNo) {
        this.careerNo = careerNo;
    }

    public String getOrgNm() {
        return orgNm;
    }

    public void setOrgNm(String orgNm) {
        this.orgNm = orgNm;
    }

    public String getWorkStartDt() {
        return workStartDt;
    }

    public void setWorkStartDt(String workStartDt) {
        this.workStartDt = workStartDt;
    }

    public String getWorkEndDt() {
        return workEndDt;
    }

    public void setWorkEndDt(String workEndDt) {
        this.workEndDt = workEndDt;
    }

    public String getDeptPositionNm() {
        return deptPositionNm;
    }

    public void setDeptPositionNm(String deptPositionNm) {
        this.deptPositionNm = deptPositionNm;
    }

    public String getChargeWorkNm() {
        return chargeWorkNm;
    }

    public void setChargeWorkNm(String chargeWorkNm) {
        this.chargeWorkNm = chargeWorkNm;
    }

    public String getCareerPeriodNm() {
        return careerPeriodNm;
    }

    public void setCareerPeriodNm(String careerPeriodNm) {
        this.careerPeriodNm = careerPeriodNm;
    }

    public String getCareerShapeCd() {
        return careerShapeCd;
    }

    public void setCareerShapeCd(String careerShapeCd) {
        this.careerShapeCd = careerShapeCd;
    }

    public String getCareerShapeNm() {
        return careerShapeNm;
    }

    public void setCareerShapeNm(String careerShapeNm) {
        this.careerShapeNm = careerShapeNm;
    }

    public String getCareerShapeEngNm() {
        return careerShapeEngNm;
    }

    public void setCareerShapeEngNm(String careerShapeEngNm) {
        this.careerShapeEngNm = careerShapeEngNm;
    }

    public String getOrgCategory() {
        return orgCategory;
    }

    public void setOrgCategory(String orgCategory) {
        this.orgCategory = orgCategory;
    }

    public String getOrgNation() {
        return orgNation;
    }

    public void setOrgNation(String orgNation) {
        this.orgNation = orgNation;
    }

    public String getWorkYn() {
        return workYn;
    }

    public void setWorkYn(String workYn) {
        this.workYn = workYn;
    }

    public String getOrgNationNm() {
        return orgNationNm;
    }

    public void setOrgNationNm(String orgNationNm) {
        this.orgNationNm = orgNationNm;
    }

    public String getOrgNationEngNm() {
        return orgNationEngNm;
    }

    public void setOrgNationEngNm(String orgNationEngNm) {
        this.orgNationEngNm = orgNationEngNm;
    }

    public String getOrgCategoryNm() {
        return orgCategoryNm;
    }

    public void setOrgCategoryNm(String orgCategoryNm) {
        this.orgCategoryNm = orgCategoryNm;
    }

    public String getOrgCategoryEngNm() {
        return orgCategoryEngNm;
    }

    public void setOrgCategoryEngNm(String orgCategoryEngNm) {
        this.orgCategoryEngNm = orgCategoryEngNm;
    }
}
