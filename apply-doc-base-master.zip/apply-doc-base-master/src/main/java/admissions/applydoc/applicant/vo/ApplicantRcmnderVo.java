package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantRcmnderVo extends DataDefaultVo {
    private String supportNo = "";
    private String recruitYear = "";
    private String rcmndDiscernNm = "";
    private String rcmnderName = "";
    private String rcmnderEmailAddress = "";
    private String belongNm = "";
    private String positionNm = "";
    private String relateNm = "";
    private String telNo = "";
    private String postAddress = "";
    private String revwRequestDate = "";
    private String writeYn = "";
    private String rcmndDocResult = "";

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRcmndDiscernNm() {
        return rcmndDiscernNm;
    }

    public void setRcmndDiscernNm(String rcmndDiscernNm) {
        this.rcmndDiscernNm = rcmndDiscernNm;
    }

    public String getRcmnderName() {
        return rcmnderName;
    }

    public void setRcmnderName(String rcmnderName) {
        this.rcmnderName = rcmnderName;
    }

    public String getRcmnderEmailAddress() {
        return rcmnderEmailAddress;
    }

    public void setRcmnderEmailAddress(String rcmnderEmailAddress) {
        this.rcmnderEmailAddress = rcmnderEmailAddress;
    }

    public String getBelongNm() {
        return belongNm;
    }

    public void setBelongNm(String belongNm) {
        this.belongNm = belongNm;
    }

    public String getPositionNm() {
        return positionNm;
    }

    public void setPositionNm(String positionNm) {
        this.positionNm = positionNm;
    }

    public String getRelateNm() {
        return relateNm;
    }

    public void setRelateNm(String relateNm) {
        this.relateNm = relateNm;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getPostAddress() {
        return postAddress;
    }

    public void setPostAddress(String postAddress) {
        this.postAddress = postAddress;
    }

    public String getRevwRequestDate() {
        return revwRequestDate;
    }

    public void setRevwRequestDate(String revwRequestDate) {
        this.revwRequestDate = revwRequestDate;
    }

    public String getRcmndDocResult() {
        return rcmndDocResult;
    }

    public void setRcmndDocResult(String rcmndDocResult) {
        this.rcmndDocResult = rcmndDocResult;
    }

    public String getWriteYn() {
        return writeYn;
    }

    public void setWriteYn(String writeYn) {
        this.writeYn = writeYn;
    }
}
