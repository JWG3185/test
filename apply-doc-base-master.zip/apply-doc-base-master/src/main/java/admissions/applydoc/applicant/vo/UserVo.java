package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class UserVo extends DataDefaultVo {
    private String userId = "";
    private String userNm = "";
    private String engFirstNm = "";
    private String engMiddleNm = "";
    private String engFamilyNm = "";
    private String countryCd = "";
    private String mobileNo = "";
    private String emailAddress = "";
    private String birthDt = "";

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserNm() {
        return userNm;
    }

    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }

    public String getEngFirstNm() {
        return engFirstNm;
    }

    public void setEngFirstNm(String engFirstNm) {
        this.engFirstNm = engFirstNm;
    }

    public String getEngMiddleNm() {
        return engMiddleNm;
    }

    public void setEngMiddleNm(String engMiddleNm) {
        this.engMiddleNm = engMiddleNm;
    }

    public String getEngFamilyNm() {
        return engFamilyNm;
    }

    public void setEngFamilyNm(String engFamilyNm) {
        this.engFamilyNm = engFamilyNm;
    }

    public String getCountryCd() {
        return countryCd;
    }

    public void setCountryCd(String countryCd) {
        this.countryCd = countryCd;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getBirthDt() {
        return birthDt;
    }

    public void setBirthDt(String birthDt) {
        this.birthDt = birthDt;
    }
}
