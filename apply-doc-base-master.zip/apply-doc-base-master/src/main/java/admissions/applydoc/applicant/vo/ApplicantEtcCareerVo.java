package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantEtcCareerVo extends DataDefaultVo
{
    private String recruitYear = "";
    private String supportNo = "";
    private String etcCareerNo = "";
    private String etcDivCd = "";
    private String etcDivNm = "";
    private String etcDivEngNm = "";
    private String etcCareerContents = "";
    private String etcCareerDt = "";
    private String etcCareerStartDt = "";
    private String etcCareerEndDt = "";
    private String etcCareerRegistNo = "";
    private String etcCareerOrgNm = "";

    public String getRecruitYear() {
        return recruitYear;
    }
    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getSupportNo() {
        return supportNo;
    }
    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getEtcCareerNo() {
        return etcCareerNo;
    }
    public void setEtcCareerNo(String etcCareerNo) {
        this.etcCareerNo = etcCareerNo;
    }

    public String getEtcDivCd() {
        return etcDivCd;
    }

    public void setEtcDivCd(String etcDivCd) {
        this.etcDivCd = etcDivCd;
    }

    public String getEtcCareerContents() {
        return etcCareerContents;
    }
    public void setEtcCareerContents(String etcCareerContents) {
        this.etcCareerContents = etcCareerContents;
    }

    public String getEtcCareerDt() {
        return etcCareerDt;
    }
    public void setEtcCareerDt(String etcCareerDt) {
        this.etcCareerDt = etcCareerDt;
    }

    public String getEtcCareerRegistNo() {
        return etcCareerRegistNo;
    }
    public void setEtcCareerRegistNo(String etcCareerRegistNo) {
        this.etcCareerRegistNo = etcCareerRegistNo;
    }

    public String getEtcCareerOrgNm() {
        return etcCareerOrgNm;
    }
    public void setEtcCareerOrgNm(String etcCareerOrgNm) {
        this.etcCareerOrgNm = etcCareerOrgNm;
    }

    public String getEtcDivNm() { return etcDivNm; }

    public void setEtcDivNm(String etcDivNm) { this.etcDivNm = etcDivNm; }

    public String getEtcDivEngNm() { return etcDivEngNm; }

    public void setEtcDivEngNm(String etcDivEngNm) { this.etcDivEngNm = etcDivEngNm; }

    public String getEtcCareerStartDt() { return etcCareerStartDt; }

    public void setEtcCareerStartDt(String etcCareerStartDt) { this.etcCareerStartDt = etcCareerStartDt; }

    public String getEtcCareerEndDt() { return etcCareerEndDt; }

    public void setEtcCareerEndDt(String etcCareerEndDt) { this.etcCareerEndDt = etcCareerEndDt; }
}