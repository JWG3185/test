package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantSubmitDocVo extends DataDefaultVo {
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String recruitDegree = "";
    private String recruitScreenCd = "";
    private String supportNo = "";
    private String docDivCd = "";
    private String docCd = "";
    private String docNm = "";
    private String docEngNm = "";
    private String necesseYn = "";
    private String masterSubmitYn = "";
    private String doctorSubmitYn = "";
    private String combineSubmitYn = "";
    private String rSeq = "";
    private String submitYn = "";
    private String fileGroupNo = "";
    private String beforeFileGroupNo = "";
    private String feedbackYn = "";
    private String feedbackContents = "";
    private String state = "";

    public String getRecruitYear() { return recruitYear; }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getRecruitDegree() {
        return recruitDegree;
    }

    public void setRecruitDegree(String recruitDegree) {
        this.recruitDegree = recruitDegree;
    }

    public String getRecruitScreenCd() {
        return recruitScreenCd;
    }

    public void setRecruitScreenCd(String recruitScreenCd) {
        this.recruitScreenCd = recruitScreenCd;
    }

    public String getDocDivCd() {
        return docDivCd;
    }

    public void setDocDivCd(String docDivCd) {
        this.docDivCd = docDivCd;
    }

    public String getDocCd() {
        return docCd;
    }

    public void setDocCd(String docCd) {
        this.docCd = docCd;
    }

    public String getDocNm() {
        return docNm;
    }

    public void setDocNm(String docNm) {
        this.docNm = docNm;
    }

    public String getNecesseYn() {
        return necesseYn;
    }

    public void setNecesseYn(String necesseYn) {
        this.necesseYn = necesseYn;
    }

    public String getMasterSubmitYn() {
        return masterSubmitYn;
    }

    public void setMasterSubmitYn(String masterSubmitYn) {
        this.masterSubmitYn = masterSubmitYn;
    }

    public String getDoctorSubmitYn() {
        return doctorSubmitYn;
    }

    public void setDoctorSubmitYn(String doctorSubmitYn) {
        this.doctorSubmitYn = doctorSubmitYn;
    }

    public String getCombineSubmitYn() {
        return combineSubmitYn;
    }

    public void setCombineSubmitYn(String combineSubmitYn) {
        this.combineSubmitYn = combineSubmitYn;
    }

    public String getrSeq() {
        return rSeq;
    }

    public void setrSeq(String rSeq) {
        this.rSeq = rSeq;
    }

    public String getSubmitYn() {
        return submitYn;
    }

    public void setSubmitYn(String submitYn) {
        this.submitYn = submitYn;
    }

    public String getDocEngNm() { return docEngNm; }

    public void setDocEngNm(String docEngNm) { this.docEngNm = docEngNm; }

    public String getBeforeFileGroupNo() {
        return beforeFileGroupNo;
    }

    public void setBeforeFileGroupNo(String beforeFileGroupNo) {
        this.beforeFileGroupNo = beforeFileGroupNo;
    }

    public String getFileGroupNo() {
        return fileGroupNo;
    }

    public void setFileGroupNo(String fileGroupNo) {
        this.fileGroupNo = fileGroupNo;
    }

    public String getFeedbackYn() {
        return feedbackYn;
    }

    public void setFeedbackYn(String feedbackYn) {
        this.feedbackYn = feedbackYn;
    }

    public String getFeedbackContents() {
        return feedbackContents;
    }

    public void setFeedbackContents(String feedbackContents) {
        this.feedbackContents = feedbackContents;
    }

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
