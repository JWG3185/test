package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantEngScoreVo extends DataDefaultVo
{
    private String recruitYear = "";
    private String supportNo = "";
    private String engScoreNo = "";
    private String engExamCd = "";
    private String engExamNm = "";
    private String engExamEngNm = "";
    private String scoreCertDt = "";
    private String scoreScore = "";

    public String getRecruitYear() {
        return recruitYear;
    }
    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getSupportNo() {
        return supportNo;
    }
    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getEngScoreNo() {
        return engScoreNo;
    }
    public void setEngScoreNo(String engScoreNo) {
        this.engScoreNo = engScoreNo;
    }

    public String getEngExamCd() {
        return engExamCd;
    }
    public void setEngExamCd(String engExamCd) {
        this.engExamCd = engExamCd;
    }

    public String getScoreCertDt() {
        return scoreCertDt;
    }
    public void setScoreCertDt(String scoreCertDt) {
        this.scoreCertDt = scoreCertDt;
    }

    public String getScoreScore() {
        return scoreScore;
    }
    public void setScoreScore(String scoreScore) {
        this.scoreScore = scoreScore;
    }

    public String getEngExamNm() { return engExamNm; }

    public void setEngExamNm(String engExamNm) { this.engExamNm = engExamNm; }

    public String getEngExamEngNm() { return engExamEngNm; }

    public void setEngExamEngNm(String engExamEngNm) { this.engExamEngNm = engExamEngNm; }
}