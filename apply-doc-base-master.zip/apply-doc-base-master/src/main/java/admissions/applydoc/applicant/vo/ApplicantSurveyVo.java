package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantSurveyVo extends DataDefaultVo {
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String recruitDegree = "";
    private String recruitScreenCd = "";
    private String surveyNo = "";
    private String surveyNm = "";
    private String surveyClassNo = "";
    private String surveyClassNm = "";
    private String surveyQstNo = "";
    private String qstNm = "";
    private String necesseYn = "";
    private String qstDetailContents = "";
    private String qstEntryTypeCd = "";
    private String minAnsrCnt = "";
    private String maxAnsrCnt = "";
    private String qstRows = "";
    private String selectValues = "";
    private String selectPoints = "";
    private String selectEtcs = "";
    private String radioValues = "";
    private String radioPoints = "";
    private String radioEtcs = "";
    private String checkValues = "";
    private String checkPoints = "";
    private String checkEtcs = "";
    private String surveyUpNo = "";
    private String surveyUpQstNo = "";

    public String getSurveyClassNo() {
        return surveyClassNo;
    }

    public void setSurveyClassNo(String surveyClassNo) {
        this.surveyClassNo = surveyClassNo;
    }

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getRecruitDegree() {
        return recruitDegree;
    }

    public void setRecruitDegree(String recruitDegree) {
        this.recruitDegree = recruitDegree;
    }

    public String getRecruitScreenCd() {
        return recruitScreenCd;
    }

    public void setRecruitScreenCd(String recruitScreenCd) {
        this.recruitScreenCd = recruitScreenCd;
    }

    public String getSurveyNo() {
        return surveyNo;
    }

    public void setSurveyNo(String surveyNo) {
        this.surveyNo = surveyNo;
    }

    public String getSurveyNm() {
        return surveyNm;
    }

    public void setSurveyNm(String surveyNm) {
        this.surveyNm = surveyNm;
    }

    public String getSurveyClassNm() {
        return surveyClassNm;
    }

    public void setSurveyClassNm(String surveyClassNm) {
        this.surveyClassNm = surveyClassNm;
    }

    public String getSurveyQstNo() {
        return surveyQstNo;
    }

    public void setSurveyQstNo(String surveyQstNo) {
        this.surveyQstNo = surveyQstNo;
    }

    public String getQstNm() {
        return qstNm;
    }

    public void setQstNm(String qstNm) {
        this.qstNm = qstNm;
    }

    public String getNecesseYn() {
        return necesseYn;
    }

    public void setNecesseYn(String necesseYn) {
        this.necesseYn = necesseYn;
    }

    public String getQstDetailContents() {
        return qstDetailContents;
    }

    public void setQstDetailContents(String qstDetailContents) {
        this.qstDetailContents = qstDetailContents;
    }

    public String getQstEntryTypeCd() {
        return qstEntryTypeCd;
    }

    public void setQstEntryTypeCd(String qstEntryTypeCd) {
        this.qstEntryTypeCd = qstEntryTypeCd;
    }

    public String getMinAnsrCnt() {
        return minAnsrCnt;
    }

    public void setMinAnsrCnt(String minAnsrCnt) {
        this.minAnsrCnt = minAnsrCnt;
    }

    public String getMaxAnsrCnt() {
        return maxAnsrCnt;
    }

    public void setMaxAnsrCnt(String maxAnsrCnt) {
        this.maxAnsrCnt = maxAnsrCnt;
    }

    public String getQstRows() {
        return qstRows;
    }

    public void setQstRows(String qstRows) {
        this.qstRows = qstRows;
    }

    public String getSelectValues() {
        return selectValues;
    }

    public void setSelectValues(String selectValues) {
        this.selectValues = selectValues;
    }

    public String getSelectPoints() {
        return selectPoints;
    }

    public void setSelectPoints(String selectPoints) {
        this.selectPoints = selectPoints;
    }

    public String getSelectEtcs() {
        return selectEtcs;
    }

    public void setSelectEtcs(String selectEtcs) {
        this.selectEtcs = selectEtcs;
    }

    public String getRadioValues() {
        return radioValues;
    }

    public void setRadioValues(String radioValues) {
        this.radioValues = radioValues;
    }

    public String getRadioPoints() {
        return radioPoints;
    }

    public void setRadioPoints(String radioPoints) {
        this.radioPoints = radioPoints;
    }

    public String getRadioEtcs() {
        return radioEtcs;
    }

    public void setRadioEtcs(String radioEtcs) {
        this.radioEtcs = radioEtcs;
    }

    public String getCheckValues() {
        return checkValues;
    }

    public void setCheckValues(String checkValues) {
        this.checkValues = checkValues;
    }

    public String getCheckPoints() {
        return checkPoints;
    }

    public void setCheckPoints(String checkPoints) {
        this.checkPoints = checkPoints;
    }

    public String getCheckEtcs() {
        return checkEtcs;
    }

    public void setCheckEtcs(String checkEtcs) {
        this.checkEtcs = checkEtcs;
    }

    public String getSurveyUpNo() {
        return surveyUpNo;
    }

    public void setSurveyUpNo(String surveyUpNo) {
        this.surveyUpNo = surveyUpNo;
    }

    public String getSurveyUpQstNo() {
        return surveyUpQstNo;
    }

    public void setSurveyUpQstNo(String surveyUpQstNo) {
        this.surveyUpQstNo = surveyUpQstNo;
    }
}
