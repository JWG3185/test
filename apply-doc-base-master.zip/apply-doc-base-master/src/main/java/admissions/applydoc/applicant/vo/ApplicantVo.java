package admissions.applydoc.applicant.vo;

import admissions.applydoc.resultdocument.vo.AfrmVo;
import admissions.common.file.vo.CommonFileVo;
import admissions.common.vo.DataDefaultVo;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ApplicantVo extends DataDefaultVo {
    private String recruitYear = "";
    private String screenClassCd = "";
    private String screenClassNm = "";
    private String screenClassEngNm = "";
    private String recruitPeriodCd = "";
    private String recruitPeriodNm = "";
    private String recruitPeriodEngNm = "";
    private String recruitDegree = "";
    private String recruitScreenCd = "";
    private String recruitScreenNm = "";
    private String screenNo = "";
    private String recruitScreenEngNm = "";
    private String supportDegreeCd = "";
    private String supportDegreeNm = "";
    private String supportDegreeEngNm = "";
    private String screenNm = "";
    private String useYn = "N";
    private String userDisplayLastPassYn = "";
    private String firstResideRegistNo = "";
    private String lastResideRegistNo = "";
    private String afrmRegistStartDt = "";
    private String afrmRegistStartTm = "";
    private String afrmRegistEndDt = "";
    private String afrmRegistEndTm = "";
    private String afrmRegistStartTxt = "";
    private String afrmRegistEndTxt = "";
    private String currentWriteYn = "N";
    private String majorCd = "";
    private String supportNo = "";
    private String countryCd = "";
    private String countryNm = "";
    private String countryEngNm = "";
    private String doubleCountryNo = "";
    private String doubleCountryNm = "";
    private String doubleCountryEngNm = "";
    private String doubleCountryDt = "";
    private String cableTelNationCd = "";
    private String cableTelNationNm = "";
    private String cableTelNationEngNm = "";
    private String mobileNationCd = "";
    private String mobileNationNm = "";
    private String mobileNationEngNm = "";
    private String addTelNationCd = "";
    private String addTelNationNm = "";
    private String addTelNationEngNm = "";
    private String addTelRelateNm = "";
    private String picFileGroupNo = "";
    private String korNm = "";
    private String engFirstNm = "";
    private String engMiddleNm = "";
    private String engFamilyNm = "";
    private String birthDt = "";
    private String genderCd = "";
    private String basicPostNo = "";
    private String basicPostAddress = "";
    private String basicDetailAddress = "";
    private String mobileNo = "";
    private String cableTelNo = "";
    private String addTelNo = "";
    private String emailAddress = "";
    private String millCd = "";
    private String disabilityYn = "N";
    private String disabilityDivCd = "";
    private String disabilityDivNm = "";
    private String disabilityDivEngNm = "";
    private String disabilityGradeCd = "";
    private String disabilityGradeNm = "";
    private String disabilityGradeEngNm = "";
    private String surveyNo = "";
    private String recruitMajorCd = "";
    private String recruitMajorNm = "";
    private String recruitMajorEngNm = "";
    private String passportName = "";
    private String countryEtcNm = "";
    private String engScoreFileGroupNo = "";
    private String workCareerFileGroupNo = "";
    private String etcProofFileGroupNo = "";
    private String residencePostNo = "";
    private String disabilityProofFileGroupNo = "";
    private String residencePostAddress = "";
    private String residenceDetailAddress = "";
    private String milltypeCd = "";
    private String millservStartDt = "";
    private String millservEndDt = "";
    private String adocWriteStepCd = "";
    private String engScoreExemptYn = "N";
    private String engScoreExemptNationCd = "";
    private String engScoreExemptNationCdNm = "";
    private String visaValidYn = "N";
    private String plan1TitleNm = "";
    private String plan2TitleNm = "";
    private String plan3TitleNm = "";
    private String plan4TitleNm = "";
    private String plan5TitleNm = "";
    private String plan1UseYn = "";
    private String plan2UseYn = "";
    private String plan3UseYn = "";
    private String plan4UseYn = "";
    private String plan5UseYn = "";
    private String plan1Contents = "";
    private String plan2Contents = "";
    private String plan3Contents = "";
    private String plan4Contents = "";
    private String plan5Contents = "";
    private String afrmSubmitDt = "";
    private String supportProgressStatusCd = "";
    private String rcmndDocFormalCd = "";
    private String docSubmitYn = "N";
    private String docSubmitYnSaveDt = "";
    private String userId = "";
    private String rcmndDocEntryYn = "";
    private String firstScreenAnnounceStartTxt = "";
    private String firstScreenAnnounceEndTxt = "";
    private String firstScreenAnnounceTodayYn = "";
    private String passAnnounceStartTxt = "";
    private String passAnnounceEndTxt = "";
    private String passAnnounceTodayYn = "";
    private String entrRegistStartTxt = "";
    private String entrRegistEndTxt = "";
    private String entrRegistTodayYn = "";
    private String continentCd = "";
    private String continentNm = "";
    private String continentEngNm = "";
    private String passportNo = "";
    private String domesticResidenceYn = "";
    private String overseasKoreansYn = "";
    private String gmpYn = "";
    private String financialSupportYn = "";
    private String engScoreExemptNationNm = "";
    private String engScoreExemptNationEngNm = "";
    private String firstForeignerRegistrationNo = "";
    private String lastForeignerRegistrationNo = "";
    private String resideRegistNo = "";
    private String foreignerRegistrationNo = "";
    private String recruitDegreeNm = "";
    private String recruitDegreeEngNm = "";
    private String plan1RequiredYn = "";
    private String plan2RequiredYn = "";
    private String plan3RequiredYn = "";
    private String plan4RequiredYn = "";
    private String plan5RequiredYn = "";
    private AfrmVo afrm = new AfrmVo();
    private List<ApplicantEngScoreVo> engScoreList = new ArrayList<>();
    private List<ApplicantSchCareerVo> schCareerList = new ArrayList<>();
    private List<ApplicantSchCareerVo> schCareer1List = new ArrayList<>();
    private List<ApplicantSchCareerVo> schCareer2List = new ArrayList<>();
    private List<ApplicantEtcCareerVo> etcCareerList = new ArrayList<>();
    private List<ApplicantCareerVo> workCareerList = new ArrayList<>();
    private List<CommonFileVo> photoList = new ArrayList<>();
    private List<CommonFileVo> engScoreFileList = new ArrayList<CommonFileVo>();
    private List<CommonFileVo> etcProofFileList = new ArrayList<CommonFileVo>();
    private List<CommonFileVo> disabilityProofFileList = new ArrayList<>();
    private List<CommonFileVo> workCareerFileList = new ArrayList<CommonFileVo>();
    private List<ApplicantSubmitDocVo> submitDocList = new ArrayList<>();
    private List<ApplicantRcmnderVo> rcmnderList = new ArrayList<>();

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getRecruitPeriodNm() {
        return recruitPeriodNm;
    }

    public void setRecruitPeriodNm(String recruitPeriodNm) {
        this.recruitPeriodNm = recruitPeriodNm;
    }

    public String getRecruitPeriodEngNm() {
        return recruitPeriodEngNm;
    }

    public void setRecruitPeriodEngNm(String recruitPeriodEngNm) {
        this.recruitPeriodEngNm = recruitPeriodEngNm;
    }

    public String getRecruitDegree() {
        return recruitDegree;
    }

    public void setRecruitDegree(String recruitDegree) {
        this.recruitDegree = recruitDegree;
    }

    public String getRecruitScreenCd() {
        return recruitScreenCd;
    }

    public void setRecruitScreenCd(String recruitScreenCd) {
        this.recruitScreenCd = recruitScreenCd;
    }

    public String getRecruitScreenNm() {
        return recruitScreenNm;
    }

    public void setRecruitScreenNm(String recruitScreenNm) {
        this.recruitScreenNm = recruitScreenNm;
    }

    public String getRecruitScreenEngNm() {
        return recruitScreenEngNm;
    }

    public void setRecruitScreenEngNm(String recruitScreenEngNm) {
        this.recruitScreenEngNm = recruitScreenEngNm;
    }

    public String getSupportDegreeCd() {
        return supportDegreeCd;
    }

    public void setSupportDegreeCd(String supportDegreeCd) {
        this.supportDegreeCd = supportDegreeCd;
    }

    public String getScreenNm() {
        return screenNm;
    }

    public void setScreenNm(String screenNm) {
        this.screenNm = screenNm;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getAfrmRegistStartDt() {
        return afrmRegistStartDt;
    }

    public void setAfrmRegistStartDt(String afrmRegistStartDt) {
        this.afrmRegistStartDt = afrmRegistStartDt;
    }

    public String getAfrmRegistStartTm() {
        return afrmRegistStartTm;
    }

    public void setAfrmRegistStartTm(String afrmRegistStartTm) {
        this.afrmRegistStartTm = afrmRegistStartTm;
    }

    public String getAfrmRegistEndDt() {
        return afrmRegistEndDt;
    }

    public void setAfrmRegistEndDt(String afrmRegistEndDt) {
        this.afrmRegistEndDt = afrmRegistEndDt;
    }

    public String getAfrmRegistEndTm() {
        return afrmRegistEndTm;
    }

    public void setAfrmRegistEndTm(String afrmRegistEndTm) {
        this.afrmRegistEndTm = afrmRegistEndTm;
    }

    public String getAfrmRegistStartTxt() {
        return afrmRegistStartTxt;
    }

    public void setAfrmRegistStartTxt(String afrmRegistStartTxt) {
        this.afrmRegistStartTxt = afrmRegistStartTxt;
    }

    public String getAfrmRegistEndTxt() {
        return afrmRegistEndTxt;
    }

    public void setAfrmRegistEndTxt(String afrmRegistEndTxt) {
        this.afrmRegistEndTxt = afrmRegistEndTxt;
    }

    public String getCurrentWriteYn() {
        return currentWriteYn;
    }

    public void setCurrentWriteYn(String currentWriteYn) {
        this.currentWriteYn = currentWriteYn;
    }

    public String getMajorCd() {
        return majorCd;
    }

    public void setMajorCd(String majorCd) {
        this.majorCd = majorCd;
    }

    public String getSupportNo() {
        return supportNo;
    }

    public void setSupportNo(String supportNo) {
        this.supportNo = supportNo;
    }

    public String getCountryCd() {
        return countryCd;
    }

    public void setCountryCd(String countryCd) {
        this.countryCd = countryCd;
    }

    public String getDoubleCountryNo() {
        return doubleCountryNo;
    }

    public void setDoubleCountryNo(String doubleCountryNo) {
        this.doubleCountryNo = doubleCountryNo;
    }

    public String getDoubleCountryDt() {
        return doubleCountryDt;
    }

    public void setDoubleCountryDt(String doubleCountryDt) {
        this.doubleCountryDt = doubleCountryDt;
    }

    public String getCableTelNationCd() {
        return cableTelNationCd;
    }

    public void setCableTelNationCd(String cableTelNationCd) {
        this.cableTelNationCd = cableTelNationCd;
    }

    public String getMobileNationCd() {
        return mobileNationCd;
    }

    public void setMobileNationCd(String mobileNationCd) {
        this.mobileNationCd = mobileNationCd;
    }

    public String getAddTelNationCd() {
        return addTelNationCd;
    }

    public void setAddTelNationCd(String addTelNationCd) {
        this.addTelNationCd = addTelNationCd;
    }

    public String getPicFileGroupNo() {
        return picFileGroupNo;
    }

    public void setPicFileGroupNo(String picFileGroupNo) {
        this.picFileGroupNo = picFileGroupNo;
    }

    public String getKorNm() {
        return korNm;
    }

    public void setKorNm(String korNm) {
        this.korNm = korNm;
    }

    public String getEngFirstNm() {
        return engFirstNm;
    }

    public void setEngFirstNm(String engFirstNm) {
        this.engFirstNm = engFirstNm;
    }

    public String getEngMiddleNm() {
        return engMiddleNm;
    }

    public void setEngMiddleNm(String engMiddleNm) {
        this.engMiddleNm = engMiddleNm;
    }

    public String getEngFamilyNm() {
        return engFamilyNm;
    }

    public void setEngFamilyNm(String engFamilyNm) {
        this.engFamilyNm = engFamilyNm;
    }

    public String getBirthDt() {
        return birthDt;
    }

    public void setBirthDt(String birthDt) {
        this.birthDt = birthDt;
    }

    public String getGenderCd() {
        return genderCd;
    }

    public void setGenderCd(String genderCd) {
        this.genderCd = genderCd;
    }

    public String getBasicPostNo() {
        return basicPostNo;
    }

    public void setBasicPostNo(String basicPostNo) {
        this.basicPostNo = basicPostNo;
    }

    public String getBasicPostAddress() {
        return basicPostAddress;
    }

    public void setBasicPostAddress(String basicPostAddress) {
        this.basicPostAddress = basicPostAddress;
    }

    public String getBasicDetailAddress() {
        return basicDetailAddress;
    }

    public void setBasicDetailAddress(String basicDetailAddress) {
        this.basicDetailAddress = basicDetailAddress;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getCableTelNo() {
        return cableTelNo;
    }

    public void setCableTelNo(String cableTelNo) {
        this.cableTelNo = cableTelNo;
    }

    public String getAddTelNo() {
        return addTelNo;
    }

    public void setAddTelNo(String addTelNo) {
        this.addTelNo = addTelNo;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getMillCd() {
        return millCd;
    }

    public void setMillCd(String millCd) {
        this.millCd = millCd;
    }

    public String getDisabilityYn() {
        return disabilityYn;
    }

    public void setDisabilityYn(String disabilityYn) {
        this.disabilityYn = disabilityYn;
    }

    public String getDisabilityGradeCd() {
        return disabilityGradeCd;
    }

    public void setDisabilityGradeCd(String disabilityGradeCd) {
        this.disabilityGradeCd = disabilityGradeCd;
    }

    public String getSurveyNo() {
        return surveyNo;
    }

    public void setSurveyNo(String surveyNo) {
        this.surveyNo = surveyNo;
    }

    public String getRecruitMajorCd() {
        return recruitMajorCd;
    }

    public void setRecruitMajorCd(String recruitMajorCd) {
        this.recruitMajorCd = recruitMajorCd;
    }

    public String getRecruitMajorNm() {
        return recruitMajorNm;
    }

    public void setRecruitMajorNm(String recruitMajorNm) {
        this.recruitMajorNm = recruitMajorNm;
    }

    public String getPassportName() {
        return passportName;
    }

    public void setPassportName(String passportName) {
        this.passportName = passportName;
    }

    public String getCountryEtcNm() {
        return countryEtcNm;
    }

    public void setCountryEtcNm(String countryEtcNm) {
        this.countryEtcNm = countryEtcNm;
    }

    public String getEngScoreFileGroupNo() {
        return engScoreFileGroupNo;
    }

    public void setEngScoreFileGroupNo(String engScoreFileGroupNo) {
        this.engScoreFileGroupNo = engScoreFileGroupNo;
    }

    public String getWorkCareerFileGroupNo() {
        return workCareerFileGroupNo;
    }

    public void setWorkCareerFileGroupNo(String workCareerFileGroupNo) {
        this.workCareerFileGroupNo = workCareerFileGroupNo;
    }

    public String getEtcProofFileGroupNo() {
        return etcProofFileGroupNo;
    }

    public void setEtcProofFileGroupNo(String etcProofFileGroupNo) {
        this.etcProofFileGroupNo = etcProofFileGroupNo;
    }

    public String getResidencePostNo() {
        return residencePostNo;
    }

    public void setResidencePostNo(String residencePostNo) {
        this.residencePostNo = residencePostNo;
    }

    public String getResidencePostAddress() {
        return residencePostAddress;
    }

    public void setResidencePostAddress(String residencePostAddress) {
        this.residencePostAddress = residencePostAddress;
    }

    public String getResidenceDetailAddress() {
        return residenceDetailAddress;
    }

    public void setResidenceDetailAddress(String residenceDetailAddress) {
        this.residenceDetailAddress = residenceDetailAddress;
    }

    public String getMilltypeCd() {
        return milltypeCd;
    }

    public void setMilltypeCd(String milltypeCd) {
        this.milltypeCd = milltypeCd;
    }

    public String getMillservStartDt() {
        return millservStartDt;
    }

    public void setMillservStartDt(String millservStartDt) {
        this.millservStartDt = millservStartDt;
    }

    public String getMillservEndDt() {
        return millservEndDt;
    }

    public void setMillservEndDt(String millservEndDt) {
        this.millservEndDt = millservEndDt;
    }

    public String getAdocWriteStepCd() {
        return adocWriteStepCd;
    }

    public void setAdocWriteStepCd(String adocWriteStepCd) {
        this.adocWriteStepCd = adocWriteStepCd;
    }

    public String getEngScoreExemptYn() {
        return engScoreExemptYn;
    }

    public void setEngScoreExemptYn(String engScoreExemptYn) {
        this.engScoreExemptYn = engScoreExemptYn;
    }

    public String getVisaValidYn() {
        return visaValidYn;
    }

    public void setVisaValidYn(String visaValidYn) {
        this.visaValidYn = visaValidYn;
    }

    public String getPlan1Contents() {
        return plan1Contents;
    }

    public void setPlan1Contents(String plan1Contents) {
        this.plan1Contents = plan1Contents;
    }

    public String getPlan2Contents() {
        return plan2Contents;
    }

    public void setPlan2Contents(String plan2Contents) {
        this.plan2Contents = plan2Contents;
    }

    public String getPlan3Contents() {
        return plan3Contents;
    }

    public void setPlan3Contents(String plan3Contents) {
        this.plan3Contents = plan3Contents;
    }

    public String getPlan4Contents() {
        return plan4Contents;
    }

    public void setPlan4Contents(String plan4Contents) {
        this.plan4Contents = plan4Contents;
    }

    public String getPlan5Contents() {
        return plan5Contents;
    }

    public void setPlan5Contents(String plan5Contents) {
        this.plan5Contents = plan5Contents;
    }

    public String getAfrmSubmitDt() {
        return afrmSubmitDt;
    }

    public void setAfrmSubmitDt(String afrmSubmitDt) {
        this.afrmSubmitDt = afrmSubmitDt;
    }

    public String getSupportProgressStatusCd() {
        return supportProgressStatusCd;
    }

    public void setSupportProgressStatusCd(String supportProgressStatusCd) {
        this.supportProgressStatusCd = supportProgressStatusCd;
    }

    public String getRcmndDocFormalCd() {
        return rcmndDocFormalCd;
    }

    public void setRcmndDocFormalCd(String rcmndDocFormalCd) {
        this.rcmndDocFormalCd = rcmndDocFormalCd;
    }

    public String getDocSubmitYn() {
        return docSubmitYn;
    }

    public void setDocSubmitYn(String docSubmitYn) {
        this.docSubmitYn = docSubmitYn;
    }

    public String getDocSubmitYnSaveDt() {
        return docSubmitYnSaveDt;
    }

    public void setDocSubmitYnSaveDt(String docSubmitYnSaveDt) {
        this.docSubmitYnSaveDt = docSubmitYnSaveDt;
    }

    public List<ApplicantEngScoreVo> getEngScoreList() {
        return Collections.unmodifiableList(engScoreList);
    }

    public void setEngScoreList(List<ApplicantEngScoreVo> engScoreList) {
        this.engScoreList = Collections.unmodifiableList(engScoreList);
    }

    public List<ApplicantSchCareerVo> getSchCareer1List() {
        return Collections.unmodifiableList(schCareer1List);
    }

    public void setSchCareer1List(List<ApplicantSchCareerVo> schCareer1List) {
        this.schCareer1List = Collections.unmodifiableList(schCareer1List);
    }

    public List<ApplicantSchCareerVo> getSchCareer2List() {
        return Collections.unmodifiableList(schCareer2List);
    }

    public void setSchCareer2List(List<ApplicantSchCareerVo> schCareer2List) {
        this.schCareer2List = Collections.unmodifiableList(schCareer2List);
    }

    public List<ApplicantEtcCareerVo> getEtcCareerList() {
        return Collections.unmodifiableList(etcCareerList);
    }

    public void setEtcCareerList(List<ApplicantEtcCareerVo> etcCareerList) {
        this.etcCareerList = Collections.unmodifiableList(etcCareerList);
    }

    public List<ApplicantCareerVo> getWorkCareerList() {
        return Collections.unmodifiableList(workCareerList);
    }

    public void setWorkCareerList(List<ApplicantCareerVo> workCareerList) {
        this.workCareerList = Collections.unmodifiableList(workCareerList);
    }

    public List<CommonFileVo> getPhotoList() {
        return Collections.unmodifiableList(photoList);
    }

    public void setPhotoList(List<CommonFileVo> photoList) {
        this.photoList = Collections.unmodifiableList(photoList);
    }

    public List<CommonFileVo> getEngScoreFileList() {
        return Collections.unmodifiableList(engScoreFileList);
    }

    public void setEngScoreFileList(List<CommonFileVo> engScoreFileList) {
        this.engScoreFileList = Collections.unmodifiableList(engScoreFileList);
    }

    public List<CommonFileVo> getEtcProofFileList() {
        return Collections.unmodifiableList(etcProofFileList);
    }

    public void setEtcProofFileList(List<CommonFileVo> etcProofFileList) {
        this.etcProofFileList = Collections.unmodifiableList(etcProofFileList);
    }

    public List<CommonFileVo> getWorkCareerFileList() {
        return Collections.unmodifiableList(workCareerFileList);
    }

    public void setWorkCareerFileList(List<CommonFileVo> workCareerFileList) {
        this.workCareerFileList = Collections.unmodifiableList(workCareerFileList);
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRecruitMajorEngNm() {
        return recruitMajorEngNm;
    }

    public void setRecruitMajorEngNm(String recruitMajorEngNm) {
        this.recruitMajorEngNm = recruitMajorEngNm;
    }

    public List<ApplicantSchCareerVo> getSchCareerList() {
        return Collections.unmodifiableList(schCareerList);
    }

    public void setSchCareerList(List<ApplicantSchCareerVo> schCareerList) {
        this.schCareerList = Collections.unmodifiableList(schCareerList);
    }

    public String getAddTelRelateNm() {
        return addTelRelateNm;
    }

    public void setAddTelRelateNm(String addTelRelateNm) {
        this.addTelRelateNm = addTelRelateNm;
    }

    public String getPlan1TitleNm() {
        return plan1TitleNm;
    }

    public void setPlan1TitleNm(String plan1TitleNm) {
        this.plan1TitleNm = plan1TitleNm;
    }

    public String getPlan2TitleNm() {
        return plan2TitleNm;
    }

    public void setPlan2TitleNm(String plan2TitleNm) {
        this.plan2TitleNm = plan2TitleNm;
    }

    public String getPlan3TitleNm() {
        return plan3TitleNm;
    }

    public void setPlan3TitleNm(String plan3TitleNm) {
        this.plan3TitleNm = plan3TitleNm;
    }

    public String getPlan4TitleNm() {
        return plan4TitleNm;
    }

    public void setPlan4TitleNm(String plan4TitleNm) {
        this.plan4TitleNm = plan4TitleNm;
    }

    public String getPlan5TitleNm() {
        return plan5TitleNm;
    }

    public void setPlan5TitleNm(String plan5TitleNm) {
        this.plan5TitleNm = plan5TitleNm;
    }

    public String getPlan1UseYn() {
        return plan1UseYn;
    }

    public void setPlan1UseYn(String plan1UseYn) {
        this.plan1UseYn = plan1UseYn;
    }

    public String getPlan2UseYn() {
        return plan2UseYn;
    }

    public void setPlan2UseYn(String plan2UseYn) {
        this.plan2UseYn = plan2UseYn;
    }

    public String getPlan3UseYn() {
        return plan3UseYn;
    }

    public void setPlan3UseYn(String plan3UseYn) {
        this.plan3UseYn = plan3UseYn;
    }

    public String getPlan4UseYn() {
        return plan4UseYn;
    }

    public void setPlan4UseYn(String plan4UseYn) {
        this.plan4UseYn = plan4UseYn;
    }

    public String getPlan5UseYn() {
        return plan5UseYn;
    }

    public void setPlan5UseYn(String plan5UseYn) {
        this.plan5UseYn = plan5UseYn;
    }

    public String getRcmndDocEntryYn() {
        return rcmndDocEntryYn;
    }

    public void setRcmndDocEntryYn(String rcmndDocEntryYn) {
        this.rcmndDocEntryYn = rcmndDocEntryYn;
    }

    public List<ApplicantSubmitDocVo> getSubmitDocList() {
        return Collections.unmodifiableList(submitDocList);
    }

    public void setSubmitDocList(List<ApplicantSubmitDocVo> submitDocList) {
        this.submitDocList = Collections.unmodifiableList(submitDocList);
    }

    public List<ApplicantRcmnderVo> getRcmnderList() {
        return Collections.unmodifiableList(rcmnderList);
    }

    public void setRcmnderList(List<ApplicantRcmnderVo> rcmnderList) {
        this.rcmnderList = Collections.unmodifiableList(rcmnderList);
    }

    public String getCountryNm() {
        return countryNm;
    }

    public void setCountryNm(String countryNm) {
        this.countryNm = countryNm;
    }

    public String getCountryEngNm() {
        return countryEngNm;
    }

    public void setCountryEngNm(String countryEngNm) {
        this.countryEngNm = countryEngNm;
    }

    public String getDoubleCountryNm() {
        return doubleCountryNm;
    }

    public void setDoubleCountryNm(String doubleCountryNm) {
        this.doubleCountryNm = doubleCountryNm;
    }

    public String getDoubleCountryEngNm() {
        return doubleCountryEngNm;
    }

    public void setDoubleCountryEngNm(String doubleCountryEngNm) {
        this.doubleCountryEngNm = doubleCountryEngNm;
    }

    public String getCableTelNationNm() {
        return cableTelNationNm;
    }

    public void setCableTelNationNm(String cableTelNationNm) {
        this.cableTelNationNm = cableTelNationNm;
    }

    public String getCableTelNationEngNm() {
        return cableTelNationEngNm;
    }

    public void setCableTelNationEngNm(String cableTelNationEngNm) {
        this.cableTelNationEngNm = cableTelNationEngNm;
    }

    public String getMobileNationNm() {
        return mobileNationNm;
    }

    public void setMobileNationNm(String mobileNationNm) {
        this.mobileNationNm = mobileNationNm;
    }

    public String getMobileNationEngNm() {
        return mobileNationEngNm;
    }

    public void setMobileNationEngNm(String mobileNationEngNm) {
        this.mobileNationEngNm = mobileNationEngNm;
    }

    public String getAddTelNationNm() {
        return addTelNationNm;
    }

    public void setAddTelNationNm(String addTelNationNm) {
        this.addTelNationNm = addTelNationNm;
    }

    public String getAddTelNationEngNm() {
        return addTelNationEngNm;
    }

    public void setAddTelNationEngNm(String addTelNationEngNm) {
        this.addTelNationEngNm = addTelNationEngNm;
    }

    public String getDisabilityGradeNm() {
        return disabilityGradeNm;
    }

    public void setDisabilityGradeNm(String disabilityGradeNm) {
        this.disabilityGradeNm = disabilityGradeNm;
    }

    public String getDisabilityGradeEngNm() {
        return disabilityGradeEngNm;
    }

    public void setDisabilityGradeEngNm(String disabilityGradeEngNm) {
        this.disabilityGradeEngNm = disabilityGradeEngNm;
    }

    public String getDisabilityDivCd() {
        return disabilityDivCd;
    }

    public void setDisabilityDivCd(String disabilityDivCd) {
        this.disabilityDivCd = disabilityDivCd;
    }

    public String getDisabilityDivNm() {
        return disabilityDivNm;
    }

    public void setDisabilityDivNm(String disabilityDivNm) {
        this.disabilityDivNm = disabilityDivNm;
    }

    public String getDisabilityDivEngNm() {
        return disabilityDivEngNm;
    }

    public void setDisabilityDivEngNm(String disabilityDivEngNm) {
        this.disabilityDivEngNm = disabilityDivEngNm;
    }

    public String getScreenClassCd() {
        return screenClassCd;
    }

    public void setScreenClassCd(String screenClassCd) {
        this.screenClassCd = screenClassCd;
    }

    public String getScreenClassNm() {
        return screenClassNm;
    }

    public void setScreenClassNm(String screenClassNm) {
        this.screenClassNm = screenClassNm;
    }

    public String getScreenClassEngNm() {
        return screenClassEngNm;
    }

    public void setScreenClassEngNm(String screenClassEngNm) {
        this.screenClassEngNm = screenClassEngNm;
    }

    public String getFirstScreenAnnounceTodayYn() {
        return firstScreenAnnounceTodayYn;
    }

    public void setFirstScreenAnnounceTodayYn(String firstScreenAnnounceTodayYn) {
        this.firstScreenAnnounceTodayYn = firstScreenAnnounceTodayYn;
    }

    public String getPassAnnounceTodayYn() {
        return passAnnounceTodayYn;
    }

    public void setPassAnnounceTodayYn(String passAnnounceTodayYn) {
        this.passAnnounceTodayYn = passAnnounceTodayYn;
    }

    public String getEntrRegistTodayYn() {
        return entrRegistTodayYn;
    }

    public void setEntrRegistTodayYn(String entrRegistTodayYn) {
        this.entrRegistTodayYn = entrRegistTodayYn;
    }

    public String getFirstScreenAnnounceStartTxt() {
        return firstScreenAnnounceStartTxt;
    }

    public void setFirstScreenAnnounceStartTxt(String firstScreenAnnounceStartTxt) {
        this.firstScreenAnnounceStartTxt = firstScreenAnnounceStartTxt;
    }

    public String getFirstScreenAnnounceEndTxt() {
        return firstScreenAnnounceEndTxt;
    }

    public void setFirstScreenAnnounceEndTxt(String firstScreenAnnounceEndTxt) {
        this.firstScreenAnnounceEndTxt = firstScreenAnnounceEndTxt;
    }

    public String getPassAnnounceStartTxt() {
        return passAnnounceStartTxt;
    }

    public void setPassAnnounceStartTxt(String passAnnounceStartTxt) {
        this.passAnnounceStartTxt = passAnnounceStartTxt;
    }

    public String getPassAnnounceEndTxt() {
        return passAnnounceEndTxt;
    }

    public void setPassAnnounceEndTxt(String passAnnounceEndTxt) {
        this.passAnnounceEndTxt = passAnnounceEndTxt;
    }

    public String getEntrRegistStartTxt() {
        return entrRegistStartTxt;
    }

    public void setEntrRegistStartTxt(String entrRegistStartTxt) {
        this.entrRegistStartTxt = entrRegistStartTxt;
    }

    public String getEntrRegistEndTxt() {
        return entrRegistEndTxt;
    }

    public void setEntrRegistEndTxt(String entrRegistEndTxt) {
        this.entrRegistEndTxt = entrRegistEndTxt;
    }

    public String getSupportDegreeNm() {
        return supportDegreeNm;
    }

    public void setSupportDegreeNm(String supportDegreeNm) {
        this.supportDegreeNm = supportDegreeNm;
    }

    public String getSupportDegreeEngNm() {
        return supportDegreeEngNm;
    }

    public void setSupportDegreeEngNm(String supportDegreeEngNm) {
        this.supportDegreeEngNm = supportDegreeEngNm;
    }

    public AfrmVo getAfrm() {
        AfrmVo target = new AfrmVo();
        BeanUtils.copyProperties(afrm, target);

        return target;
    }

    public void setAfrm(AfrmVo afrm) {
        BeanUtils.copyProperties(afrm, this.afrm);
    }

    public String getFirstResideRegistNo() {
        return firstResideRegistNo;
    }

    public void setFirstResideRegistNo(String firstResideRegistNo) {
        this.firstResideRegistNo = firstResideRegistNo;
    }

    public String getLastResideRegistNo() {
        return lastResideRegistNo;
    }

    public void setLastResideRegistNo(String lastResideRegistNo) {
        this.lastResideRegistNo = lastResideRegistNo;
    }

    public String getDisabilityProofFileGroupNo() {
        return disabilityProofFileGroupNo;
    }

    public void setDisabilityProofFileGroupNo(String disabilityProofFileGroupNo) {
        this.disabilityProofFileGroupNo = disabilityProofFileGroupNo;
    }

    public List<CommonFileVo> getDisabilityProofFileList() {
        return Collections.unmodifiableList(disabilityProofFileList);
    }

    public void setDisabilityProofFileList(List<CommonFileVo> disabilityProofFileList) {
        this.disabilityProofFileList = Collections.unmodifiableList(disabilityProofFileList);
    }

    public String getScreenNo() {
        return screenNo;
    }

    public void setScreenNo(String screenNo) {
        this.screenNo = screenNo;
    }

    public String getUserDisplayLastPassYn() {
        return userDisplayLastPassYn;
    }

    public void setUserDisplayLastPassYn(String userDisplayLastPassYn) {
        this.userDisplayLastPassYn = userDisplayLastPassYn;
    }

    public String getContinentCd() {
        return continentCd;
    }

    public void setContinentCd(String continentCd) {
        this.continentCd = continentCd;
    }

    public String getPassportNo() {
        return passportNo;
    }

    public void setPassportNo(String passportNo) {
        this.passportNo = passportNo;
    }

    public String getDomesticResidenceYn() {
        return domesticResidenceYn;
    }

    public void setDomesticResidenceYn(String domesticResidenceYn) {
        this.domesticResidenceYn = domesticResidenceYn;
    }

    public String getOverseasKoreansYn() {
        return overseasKoreansYn;
    }

    public void setOverseasKoreansYn(String overseasKoreansYn) {
        this.overseasKoreansYn = overseasKoreansYn;
    }

    public String getGmpYn() {
        return gmpYn;
    }

    public void setGmpYn(String gmpYn) {
        this.gmpYn = gmpYn;
    }

    public String getFinancialSupportYn() {
        return financialSupportYn;
    }

    public void setFinancialSupportYn(String financialSupportYn) {
        this.financialSupportYn = financialSupportYn;
    }

    public String getEngScoreExemptNationCd() {
        return engScoreExemptNationCd;
    }

    public void setEngScoreExemptNationCd(String engScoreExemptNationCd) {
        this.engScoreExemptNationCd = engScoreExemptNationCd;
    }

    public String getEngScoreExemptNationCdNm() {
        return engScoreExemptNationCdNm;
    }

    public void setEngScoreExemptNationCdNm(String engScoreExemptNationCdNm) {
        this.engScoreExemptNationCdNm = engScoreExemptNationCdNm;
    }

    public String getContinentNm() {
        return continentNm;
    }

    public void setContinentNm(String continentNm) {
        this.continentNm = continentNm;
    }

    public String getContinentEngNm() {
        return continentEngNm;
    }

    public void setContinentEngNm(String continentEngNm) {
        this.continentEngNm = continentEngNm;
    }

    public String getEngScoreExemptNationNm() {
        return engScoreExemptNationNm;
    }

    public void setEngScoreExemptNationNm(String engScoreExemptNationNm) {
        this.engScoreExemptNationNm = engScoreExemptNationNm;
    }

    public String getEngScoreExemptNationEngNm() {
        return engScoreExemptNationEngNm;
    }

    public void setEngScoreExemptNationEngNm(String engScoreExemptNationEngNm) {
        this.engScoreExemptNationEngNm = engScoreExemptNationEngNm;
    }

    public String getFirstForeignerRegistrationNo() {
        return firstForeignerRegistrationNo;
    }

    public void setFirstForeignerRegistrationNo(String firstForeignerRegistrationNo) {
        this.firstForeignerRegistrationNo = firstForeignerRegistrationNo;
    }

    public String getLastForeignerRegistrationNo() {
        return lastForeignerRegistrationNo;
    }

    public void setLastForeignerRegistrationNo(String lastForeignerRegistrationNo) {
        this.lastForeignerRegistrationNo = lastForeignerRegistrationNo;
    }

    public String getResideRegistNo() {
        return resideRegistNo;
    }

    public void setResideRegistNo(String resideRegistNo) {
        this.resideRegistNo = resideRegistNo;
        if (!"".equals(resideRegistNo)) {
            this.firstResideRegistNo = resideRegistNo.substring(0, 6);
            this.lastResideRegistNo = resideRegistNo.substring(6);
        }
    }

    public String getForeignerRegistrationNo() {
        return foreignerRegistrationNo;
    }

    public void setForeignerRegistrationNo(String foreignerRegistrationNo) {
        this.foreignerRegistrationNo = foreignerRegistrationNo;

        if (!"".equals(foreignerRegistrationNo)) {
            this.firstForeignerRegistrationNo = foreignerRegistrationNo.substring(0, 6);
            this.lastForeignerRegistrationNo = foreignerRegistrationNo.substring(6);
        }
    }

    public String getRecruitDegreeNm() {
        return recruitDegreeNm;
    }

    public void setRecruitDegreeNm(String recruitDegreeNm) {
        this.recruitDegreeNm = recruitDegreeNm;
    }

    public String getRecruitDegreeEngNm() {
        return recruitDegreeEngNm;
    }

    public void setRecruitDegreeEngNm(String recruitDegreeEngNm) {
        this.recruitDegreeEngNm = recruitDegreeEngNm;
    }

    public String getPlan1RequiredYn() {
        return plan1RequiredYn;
    }

    public void setPlan1RequiredYn(String plan1RequiredYn) {
        this.plan1RequiredYn = plan1RequiredYn;
    }

    public String getPlan2RequiredYn() {
        return plan2RequiredYn;
    }

    public void setPlan2RequiredYn(String plan2RequiredYn) {
        this.plan2RequiredYn = plan2RequiredYn;
    }

    public String getPlan3RequiredYn() {
        return plan3RequiredYn;
    }

    public void setPlan3RequiredYn(String plan3RequiredYn) {
        this.plan3RequiredYn = plan3RequiredYn;
    }

    public String getPlan4RequiredYn() {
        return plan4RequiredYn;
    }

    public void setPlan4RequiredYn(String plan4RequiredYn) {
        this.plan4RequiredYn = plan4RequiredYn;
    }

    public String getPlan5RequiredYn() {
        return plan5RequiredYn;
    }

    public void setPlan5RequiredYn(String plan5RequiredYn) {
        this.plan5RequiredYn = plan5RequiredYn;
    }
}