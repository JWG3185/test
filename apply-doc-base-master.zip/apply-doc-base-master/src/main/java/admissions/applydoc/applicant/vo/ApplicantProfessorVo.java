package admissions.applydoc.applicant.vo;

import admissions.common.vo.DataDefaultVo;

public class ApplicantProfessorVo extends DataDefaultVo {
    private String recruitYear = "";
    private String recruitPeriodCd = "";
    private String empNo = "";
    private String empNmKor = "";
    private String empNmEng = "";
    private String deptCd = "";
    private String deptNmKor = "";
    private String deptNmEng = "";
    private String recruitMajorCd = "";
    private String majorCd = "";
    private String majorNmKor = "";
    private String majorNmEng = "";
    private String year = "";
    private String termCd = "";
    private String remark = "";
    private String createNo = "";
    private String createDt = "";
    private String createIp = "";
    private String entryNo = "";
    private String entryDt = "";
    private String entryIp = "";
    private String course21 = "";
    private String course31 = "";
    private String course41 = "";
    private String teachStdDiv = "";
    private String campusSchoolCd = "";
    private String supportDegreeCd = "";

    public String getEmpNo() {
        return empNo;
    }

    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getTermCd() {
        return termCd;
    }

    public void setTermCd(String termCd) {
        this.termCd = termCd;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCreateNo() {
        return createNo;
    }

    public void setCreateNo(String createNo) {
        this.createNo = createNo;
    }

    public String getCreateDt() {
        return createDt;
    }

    public void setCreateDt(String createDt) {
        this.createDt = createDt;
    }

    public String getCreateIp() {
        return createIp;
    }

    public void setCreateIp(String createIp) {
        this.createIp = createIp;
    }

    public String getEntryNo() {
        return entryNo;
    }

    public void setEntryNo(String entryNo) {
        this.entryNo = entryNo;
    }

    public String getEntryDt() {
        return entryDt;
    }

    public void setEntryDt(String entryDt) {
        this.entryDt = entryDt;
    }

    public String getEntryIp() {
        return entryIp;
    }

    public void setEntryIp(String entryIp) {
        this.entryIp = entryIp;
    }

    public String getCourse21() {
        return course21;
    }

    public void setCourse21(String course21) {
        this.course21 = course21;
    }

    public String getCourse31() {
        return course31;
    }

    public void setCourse31(String course31) {
        this.course31 = course31;
    }

    public String getCourse41() {
        return course41;
    }

    public void setCourse41(String course41) {
        this.course41 = course41;
    }

    public String getTeachStdDiv() {
        return teachStdDiv;
    }

    public void setTeachStdDiv(String teachStdDiv) {
        this.teachStdDiv = teachStdDiv;
    }

    public String getEmpNmKor() {
        return empNmKor;
    }

    public void setEmpNmKor(String empNmKor) {
        this.empNmKor = empNmKor;
    }

    public String getEmpNmEng() {
        return empNmEng;
    }

    public void setEmpNmEng(String empNmEng) {
        this.empNmEng = empNmEng;
    }

    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    public String getDeptNmKor() {
        return deptNmKor;
    }

    public void setDeptNmKor(String deptNmKor) {
        this.deptNmKor = deptNmKor;
    }

    public String getDeptNmEng() {
        return deptNmEng;
    }

    public void setDeptNmEng(String deptNmEng) {
        this.deptNmEng = deptNmEng;
    }

    public String getRecruitMajorCd() {
        return recruitMajorCd;
    }

    public void setRecruitMajorCd(String recruitMajorCd) {
        this.recruitMajorCd = recruitMajorCd;
    }

    public String getMajorCd() {
        return majorCd;
    }

    public void setMajorCd(String majorCd) {
        this.majorCd = majorCd;
    }

    public String getMajorNmKor() {
        return majorNmKor;
    }

    public void setMajorNmKor(String majorNmKor) {
        this.majorNmKor = majorNmKor;
    }

    public String getMajorNmEng() {
        return majorNmEng;
    }

    public void setMajorNmEng(String majorNmEng) {
        this.majorNmEng = majorNmEng;
    }

    public String getCampusSchoolCd() {
        return campusSchoolCd;
    }

    public void setCampusSchoolCd(String campusSchoolCd) {
        this.campusSchoolCd = campusSchoolCd;
    }

    public String getRecruitYear() {
        return recruitYear;
    }

    public void setRecruitYear(String recruitYear) {
        this.recruitYear = recruitYear;
    }

    public String getRecruitPeriodCd() {
        return recruitPeriodCd;
    }

    public void setRecruitPeriodCd(String recruitPeriodCd) {
        this.recruitPeriodCd = recruitPeriodCd;
    }

    public String getSupportDegreeCd() {
        return supportDegreeCd;
    }

    public void setSupportDegreeCd(String supportDegreeCd) {
        this.supportDegreeCd = supportDegreeCd;
    }
}
