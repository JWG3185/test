package admissions.applydoc.applicant;

import admissions.applydoc.applicant.vo.*;
import admissions.applydoc.resultdocument.ResultDocumentService;
import admissions.system.code.CodeService;
import admissions.system.code.vo.CodeFormVo;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Controller
@RequestMapping("/applicant/")
public class ApplicantController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicantController.class);
    private static final String JSON_VIEW = "jsonView";

    @Autowired
    ApplicantService applicantService;

    @Autowired
    ResultDocumentService resultDocumentService;

    @Autowired
    CodeService codeService;

    @PostMapping("selectScreenBySupportNo.do")
    public ModelAndView selectSupportNo(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("screen", applicantService.selectScreenBySupportNo(formVo));
        return model;
    }

    /**
     * 전형 목록
     */
    @PostMapping("selectScreenList.do")
    public ModelAndView selectScreenList(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        model.addObject("screenList", applicantService.selectScreenList(formVo));
        model.addObject("preScreen", applicantService.selectPreScreenInfo(formVo));

        return model;
    }

    /**
     * 최종 승인 전형 목록
     */
    @PostMapping("selectPreScreenInfo.do")
    public ModelAndView selectPreScreenInfo(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        model.addObject("preScreenInfo", applicantService.selectPreScreenInfo(formVo));

        return model;
    }

    /**
     * 설문 질의 목록
     */
    @PostMapping("selectSurveyQstList.do")
    public ModelAndView selectSurveyQstList(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        List<ApplicantSurveyVo> surveyQstList = applicantService.selectSurveyQstList(formVo);
        model.addObject("surveyQstList", surveyQstList);

        List<ApplicantSurveyVo> surveyClsList = new ArrayList<ApplicantSurveyVo>();
        HashMap<String, String> hm = new HashMap<String, String>();
        for (ApplicantSurveyVo vo : surveyQstList) {
            if (!hm.containsKey(vo.getSurveyClassNo())) {
                hm.put(vo.getSurveyClassNo(), vo.getSurveyClassNm());
                surveyClsList.add(vo);
            }
        }
        model.addObject("surveyClsList", surveyClsList);

        if (surveyQstList.size() > 0) {
            formVo.setSurveyNo(surveyQstList.get(0).getSurveyNo());
            List<ApplicantSurveyAnswerVo> answerList = applicantService.selectSurveyAnswerList(formVo);
            model.addObject("answerList", answerList);
        }

        return model;
    }

    /**
     * 설문 답변 저장
     */
    @PostMapping("saveSurvey.do")
    public ModelAndView saveSurvey(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        applicantService.saveSurvey(formVo);
        return model;
    }

    /**
     * STEP.2 지원자 정보 저장
     */
    @PostMapping("saveApplicant.do")
    public ModelAndView saveApplicant(@RequestBody ApplicantVo applicantVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("saveApplicant", applicantService.saveApplicant(applicantVo));
        return model;
    }


    /**
     * 지원서
     */
    @PostMapping("selectApplicant.do")
    public ModelAndView selectApplicant(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        UserVo user = applicantService.selectUserInfo(formVo);
        model.addObject("user", user);

        ApplicantVo applicant = applicantService.selectApplicant(formVo);
        model.addObject("applicant", applicant);

        CodeFormVo codeFormVo = new CodeFormVo();
        codeFormVo.setUseYn("Y");

        codeFormVo.setComClassCd("CONTINENT_CD");
        model.addObject("continentCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("EMPLOYMENT_CATEGORY");
        model.addObject("employmentCategoryList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("NATION_CD");
        model.addObject("nationCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("NATION_TEL_NO");
        model.addObject("nationTelList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("ADD_TEL_RELATE_CD");
        model.addObject("relateCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("MILL_CD");
        model.addObject("millCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("DISABILITY_GRADE_CD");
        model.addObject("disabilityCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("ENG_SCORE_DEFER_NATION_CD");
        model.addObject("engUseNationCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("ENG_EXAM_CD");
        model.addObject("engExamCdList", codeService.selectList(codeFormVo));

        model.addObject("belongCdList", codeService.selectDeptList(codeFormVo));

        codeFormVo.setComClassCd("ETC_DIV_CD");
        model.addObject("etcDivCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("CAREER_SHAPE_CD");
        model.addObject("careerShapeCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("SCH_CAREER_DIV_CD");
        model.addObject("schCareerDivCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("ENTR_DIV_CD");
        model.addObject("entrDivCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("GRADUATE_DIV_CD");
        model.addObject("graduateDivCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("SUPPORT_DEGREE_CD");
        model.addObject("supportDegreeCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("DEGREE_DIV_CD");
        model.addObject("degreeDivCdList", codeService.selectList(codeFormVo));

        codeFormVo.setComClassCd("DISABILITY_DIV_CD");
        model.addObject("disabilityDivCdList", codeService.selectList(codeFormVo));

        return model;
    }

    @PostMapping("selectFinalApplicantData.do")
    public ModelAndView selectFinalApplicantData(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        UserVo user = applicantService.selectUserInfo(formVo);
        model.addObject("user", user);

        formVo.setDocDivCd("1");
        model.addObject("applicant", applicantService.selectApplicant(formVo));
        model.addObject("afrm", resultDocumentService.selectApplicantAfrm(formVo));
        model.addObject("planList", applicantService.selectPlanList(formVo));
        model.addObject("submitDocList", applicantService.selectSubmitDocList(formVo));
        model.addObject("medicalQstList", applicantService.selectMedicalQstList(formVo));
        model.addObject("rcmnderList", applicantService.selectRcmnderList(formVo));

        CodeFormVo codeFormVo = new CodeFormVo();

        codeFormVo.setComClassCd("MILL_CD");
        model.addObject("millCdList", codeService.selectList(codeFormVo));

        return model;
    }

    /**
     * 전공 목록
     */
    @PostMapping("selectMajorDept.do")
    public ModelAndView selectMajorDept(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        model.addObject("majorDeptList", applicantService.selectMajorDept(formVo));
        model.addObject("majorList", applicantService.selectMajor(formVo));

        return model;
    }

    /**
     * 전공 목록
     */
    @PostMapping("selectMajor.do")
    public ModelAndView selectMajor(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("majorList", applicantService.selectMajor(formVo));
        return model;
    }

    /**
     * 전공 목록
     */
    @PostMapping("selectCompanyMajor.do")
    public ModelAndView selectCompanyMajor(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        model.addObject("majorList", applicantService.selectCompanyMajor(formVo));

        return model;
    }

    @PostMapping("selectPlanList.do")
    public ModelAndView selectPlan(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("planList", applicantService.selectPlanList(formVo));
        return model;
    }

    @PostMapping("saveApplicantPlan.do")
    public ModelAndView saveApplicantPlan(@RequestBody ApplicantVo applicantVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        applicantService.saveApplicantPlan(applicantVo);
        return model;
    }

    @PostMapping("selectDocument.do")
    public ModelAndView selectDocument(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());

        formVo.setDocDivCd("1");

        model.addObject("applicant", applicantService.selectApplicant(formVo));
        model.addObject("submitDocList", applicantService.selectSubmitDocList(formVo));
        model.addObject("rcmnderList", applicantService.selectRcmnderList(formVo));

        return model;
    }

    @PostMapping("saveDocument.do")
    public ModelAndView saveDocument(@RequestBody ApplicantVo applciantVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        applicantService.saveApplicantDocument(applciantVo);
        return model;
    }

    @PostMapping("selectRemnderList.do")
    public ModelAndView selectRemnderList(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("rcmnderList", applicantService.selectRcmnderList(formVo));
        return model;
    }

    @PostMapping("sendRcmnderMail.do")
    public ModelAndView sendRemnderMail(@RequestBody ApplicantRcmnderVo rcmnderVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("rcmnder", applicantService.sendRemnderMail(rcmnderVo));
        return model;
    }

    @PostMapping("deleteRemnder.do")
    public ModelAndView deleteRemnderMail(@RequestBody ApplicantRcmnderVo rcmnderVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        applicantService.deleteRemnder(rcmnderVo);
        return model;
    }

    @PostMapping("saveSubmit.do")
    public ModelAndView saveSubmit(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        applicantService.saveSubmit(formVo);
        return model;
    }

    @PostMapping("checkServerTime.do")
    public ModelAndView checkServerTime(@RequestBody ApplicantFormVo formVo) {
        ModelAndView model = new ModelAndView(new MappingJackson2JsonView());
        model.addObject("serverInfo", applicantService.checkServerTime(formVo));
        return model;
    }

    @PostMapping("downloadPdf.do")
    public void downloadPdf(HttpServletRequest request, HttpServletResponse response, @RequestBody ApplicantVo vo) throws IOException {
        final File file = applicantService.downloadPdf(vo);
        final int fileSize = Long.valueOf(file.length()).intValue();

        if (file.exists() && file.isFile()) {
            InputStream is = null;

            try {
                is = Files.newInputStream(file.toPath(), StandardOpenOption.READ);

                IOUtils.copy(is, response.getOutputStream());

                String mimeType = "application/zip";
                if (file.getName().endsWith(".pdf")) {
                    mimeType = "application/pdf";
                }

                response.setContentType(mimeType);
                response.setContentLength(fileSize);
                response.setHeader("Content-Disposition", "inline;");
                response.setHeader("Content-Transfer-Encoding", "binary");
                response.getOutputStream().flush();
                response.getOutputStream().close();
            } catch (IOException e) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error(e.getMessage(), e);
                }
            } finally {
                if (is != null) {
                    is.close();
                }
            }
        }
    }
}
