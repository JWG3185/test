create table TB_COM_BLOCK_IP
(
    BLOCK_NO                NUMBER        not null
        constraint TB_COM_BLOCK_IP_PK
            primary key,
    BLOCK_NM                VARCHAR2(500) not null,
    START_IP                VARCHAR2(100) not null,
    END_IP                  VARCHAR2(100) not null,
    USE_YN                  VARCHAR2(1)   not null,
    DESCRIPT_CONTENTS       VARCHAR2(4000),
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null
)
comment on table TB_COM_BLOCK_IP is '공통 차단 IP'
comment on column TB_COM_BLOCK_IP.BLOCK_NO is '차단 번호'
comment on column TB_COM_BLOCK_IP.BLOCK_NM is '차단 명'
comment on column TB_COM_BLOCK_IP.START_IP is '시작 IP'
comment on column TB_COM_BLOCK_IP.END_IP is '종료 IP'
comment on column TB_COM_BLOCK_IP.USE_YN is '사용 여부'
comment on column TB_COM_BLOCK_IP.DESCRIPT_CONTENTS is '설명 내용'
comment on column TB_COM_BLOCK_IP.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_BLOCK_IP.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_BLOCK_IP.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_BLOCK_IP.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_BLOCK_IP.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_BLOCK_IP.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_BLOCK_IP.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_BLOCK_IP.LAST_UPDATE_DATE is '최종 수정 일시'

create table TB_COM_CLASS_CODE
(
    COM_CLASS_CD            VARCHAR2(40)  not null
        constraint TB_COM_CLASS_CODE_PK
        primary key,
    COM_CLASS_NM            VARCHAR2(100) not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null,
    COM_GROUP1_NM           VARCHAR2(100) default NULL,
    COM_GROUP2_NM           VARCHAR2(100) default NULL,
    COM_GROUP3_NM           VARCHAR2(100) default NULL
)
    comment on table TB_COM_CLASS_CODE is '공통 분류 [코드]'
comment on column TB_COM_CLASS_CODE.COM_CLASS_CD is '공통 분류 코드'
comment on column TB_COM_CLASS_CODE.COM_CLASS_NM is '공통 분류 명'
comment on column TB_COM_CLASS_CODE.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_CLASS_CODE.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_CLASS_CODE.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_CLASS_CODE.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_CLASS_CODE.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_CLASS_CODE.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_CLASS_CODE.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_CLASS_CODE.LAST_UPDATE_DATE is '최종 수정 일시'
comment on column TB_COM_CLASS_CODE.COM_GROUP1_NM is '공통 그룹1 명'
comment on column TB_COM_CLASS_CODE.COM_GROUP2_NM is '공통 그룹2 명'
comment on column TB_COM_CLASS_CODE.COM_GROUP3_NM is '공통 그룹3 명'

create table TB_COM_CODE
(
    COM_CLASS_CD            VARCHAR2(40)  not null
        constraint COM_CLASS_CODE_COM_CODE_FK
        references TB_COM_CLASS_CODE,
    COM_CD                  VARCHAR2(40)  not null,
    CD_NM                   VARCHAR2(200) not null,
    CD_ENG_NM               VARCHAR2(200),
    SORT_ORDER              NUMBER(10)    not null,
    CONNECT_CLASS_CD        VARCHAR2(40),
    CONNECT_COM_CD          VARCHAR2(40),
    USE_YN                  VARCHAR2(1)   not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null,
    COM_GROUP1_CD           VARCHAR2(60) default NULL,
    COM_GROUP2_CD           VARCHAR2(60) default NULL,
    COM_GROUP3_CD           VARCHAR2(60) default NULL,
    constraint TB_COM_CODE_PK
        primary key (COM_CLASS_CD, COM_CD)
)
    comment on table TB_COM_CODE is '공통 [코드]'
comment on column TB_COM_CODE.COM_CLASS_CD is '공통 분류 코드'
comment on column TB_COM_CODE.COM_CD is '공통 코드'
comment on column TB_COM_CODE.CD_NM is '코드 명'
comment on column TB_COM_CODE.CD_ENG_NM is '코드 영문 명'
comment on column TB_COM_CODE.SORT_ORDER is '정렬 순서'
comment on column TB_COM_CODE.CONNECT_CLASS_CD is '연계 분류 코드'
comment on column TB_COM_CODE.CONNECT_COM_CD is '연계 공통 코드'
comment on column TB_COM_CODE.USE_YN is '사용 여부'
comment on column TB_COM_CODE.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_CODE.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_CODE.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_CODE.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_CODE.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_CODE.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_CODE.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_CODE.LAST_UPDATE_DATE is '최종 수정 일시'
comment on column TB_COM_CODE.COM_GROUP1_CD is '공통 그룹1 코드'
comment on column TB_COM_CODE.COM_GROUP2_CD is '공통 그룹2 코드'
comment on column TB_COM_CODE.COM_GROUP3_CD is '공통 그룹3 코드'

create table TB_COM_FILE_GROUP
(
    FILE_GROUP_NO           NUMBER(10)    not null
        constraint TB_COM_FILE_GROUP_PK
        primary key,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null
)
    comment on table TB_COM_FILE_GROUP is '공통 파일 그룹'
comment on column TB_COM_FILE_GROUP.FILE_GROUP_NO is '파일 그룹 번호'
comment on column TB_COM_FILE_GROUP.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_FILE_GROUP.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_FILE_GROUP.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_FILE_GROUP.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_FILE
(
    FILE_NO                 NUMBER(10)    not null
        constraint TB_COM_FILE_PK
        primary key,
    FILE_GROUP_NO           NUMBER(10)    not null
        constraint COM_FILE_GROUP_COM_FILE_FK
        references TB_COM_FILE_GROUP,
    FILE_NM                 VARCHAR2(300) not null,
    FILE_EXTENSION_NM       VARCHAR2(20)  not null,
    SERVER_FILE_SAVE_PATH   VARCHAR2(500) not null,
    SERVER_FILE_SAVE_NM     VARCHAR2(300) not null,
    FILE_SIZE               NUMBER(10)    not null,
    FILE_SIZE_NM            VARCHAR2(100) not null,
    MIME_TYPE_NM            VARCHAR2(100) not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    SERVER_FILE_SAVE_IP     VARCHAR2(100) not null,
    VERIFY_FILE             VARCHAR2(100),
    OLD_PATH                VARCHAR2(200)
)
    comment on table TB_COM_FILE is '공통 파일'
comment on column TB_COM_FILE.FILE_NO is '파일 번호'
comment on column TB_COM_FILE.FILE_GROUP_NO is '파일 그룹 번호'
comment on column TB_COM_FILE.FILE_NM is '파일 명'
comment on column TB_COM_FILE.FILE_EXTENSION_NM is '파일 확장자 명'
comment on column TB_COM_FILE.SERVER_FILE_SAVE_PATH is '서버 파일 저장 경로'
comment on column TB_COM_FILE.SERVER_FILE_SAVE_NM is '서버 파일 저장 명'
comment on column TB_COM_FILE.FILE_SIZE is '파일 크기'
comment on column TB_COM_FILE.FILE_SIZE_NM is '파일 크기 명'
comment on column TB_COM_FILE.MIME_TYPE_NM is 'MIME TYPE 명'
comment on column TB_COM_FILE.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_FILE.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_FILE.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_FILE.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_FILE.SERVER_FILE_SAVE_IP is '서버 파일 저장 IP'

create table TB_COM_INTERNAL_IP
(
    INTERNAL_NO             NUMBER        not null
        constraint TB_COM_INTERNAL_IP_PK
            primary key,
    INTERNAL_NM             VARCHAR2(500) not null,
    START_IP                VARCHAR2(100) not null,
    END_IP                  VARCHAR2(100) not null,
    USE_YN                  VARCHAR2(1)   not null,
    DESCRIPT_CONTENTS       VARCHAR2(4000),
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null
)
    comment on table TB_COM_INTERNAL_IP is '공통 내부 IP'
comment on column TB_COM_INTERNAL_IP.INTERNAL_NO is '내부 번호'
comment on column TB_COM_INTERNAL_IP.INTERNAL_NM is '내부 명'
comment on column TB_COM_INTERNAL_IP.START_IP is '시작 IP'
comment on column TB_COM_INTERNAL_IP.END_IP is '종료 IP'
comment on column TB_COM_INTERNAL_IP.USE_YN is '사용 여부'
comment on column TB_COM_INTERNAL_IP.DESCRIPT_CONTENTS is '설명 내용'
comment on column TB_COM_INTERNAL_IP.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_INTERNAL_IP.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_INTERNAL_IP.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_INTERNAL_IP.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_INTERNAL_IP.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_INTERNAL_IP.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_INTERNAL_IP.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_INTERNAL_IP.LAST_UPDATE_DATE is '최종 수정 일시'

create table TB_COM_INTERNAL_IP_EX_USER
(
    USER_ID                 VARCHAR2(100) not null
        constraint TB_COM_INTERNAL_IP_EX_USER_PK
        primary key,
    START_DT                VARCHAR2(8),
    END_DT                  VARCHAR2(8),
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null
)
    comment on table TB_COM_INTERNAL_IP_EX_USER is '공통 내부 IP 제외 사용자'
comment on column TB_COM_INTERNAL_IP_EX_USER.USER_ID is '사용자 ID'
comment on column TB_COM_INTERNAL_IP_EX_USER.START_DT is '시작 일자'
comment on column TB_COM_INTERNAL_IP_EX_USER.END_DT is '종료 일자'
comment on column TB_COM_INTERNAL_IP_EX_USER.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_INTERNAL_IP_EX_USER.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_INTERNAL_IP_EX_USER.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_INTERNAL_IP_EX_USER.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_INTERNAL_IP_EX_USER.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_INTERNAL_IP_EX_USER.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_INTERNAL_IP_EX_USER.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_INTERNAL_IP_EX_USER.LAST_UPDATE_DATE is '최종 수정 일시'

create table TB_COM_MENU
(
    MENU_NO                 NUMBER(10)    not null
        constraint TB_COM_MENU_PK
        primary key,
    UPPER_MENU_NO           NUMBER(10)    not null,
    MENU_NM                 VARCHAR2(100) not null,
    MENU_ENG_NM             VARCHAR2(100),
    MENU_DIV_CD             VARCHAR2(2)   not null,
    SORT_ORDER              NUMBER(10)    not null,
    MENU_LINK_ADDRESS       VARCHAR2(500),
    USE_YN                  VARCHAR2(1),
    DISPLAY_YN              VARCHAR2(1),
    ICON_CD                 VARCHAR2(10),
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null
)
    comment on table TB_COM_MENU is '공통 메뉴'
comment on column TB_COM_MENU.MENU_NO is '메뉴 번호'
comment on column TB_COM_MENU.UPPER_MENU_NO is '상위 메뉴 번호'
comment on column TB_COM_MENU.MENU_NM is '메뉴 명'
comment on column TB_COM_MENU.MENU_ENG_NM is '메뉴 영문 명'
comment on column TB_COM_MENU.MENU_DIV_CD is '메뉴 구분 코드'
comment on column TB_COM_MENU.SORT_ORDER is '정렬 순서'
comment on column TB_COM_MENU.MENU_LINK_ADDRESS is '메뉴 링크 주소'
comment on column TB_COM_MENU.USE_YN is '사용 여부'
comment on column TB_COM_MENU.DISPLAY_YN is '표시 여부'
comment on column TB_COM_MENU.ICON_CD is '아이콘 코드'
comment on column TB_COM_MENU.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_MENU.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_MENU.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_MENU.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_MENU.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_MENU.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_MENU.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_MENU.LAST_UPDATE_DATE is '최종 수정 일시'

create table TB_COM_MENU_FUNC
(
    MENU_NO                 NUMBER(10)    not null
        constraint COM_MENU_COM_MENU_FUNC_FK
        references TB_COM_MENU,
    FUNC_NO                 NUMBER(10)    not null,
    FUNC_NM                 VARCHAR2(100) not null,
    SORT_ORDER              NUMBER(10)    not null,
    USE_YN                  VARCHAR2(1),
    DISPLAY_YN              VARCHAR2(1),
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null,
    constraint TB_COM_MENU_FUNC_PK
        primary key (MENU_NO, FUNC_NO)
)
    comment on table TB_COM_MENU_FUNC is '공통 메뉴 기능'
comment on column TB_COM_MENU_FUNC.MENU_NO is '메뉴 번호'
comment on column TB_COM_MENU_FUNC.FUNC_NO is '기능 번호'
comment on column TB_COM_MENU_FUNC.FUNC_NM is '기능 명'
comment on column TB_COM_MENU_FUNC.SORT_ORDER is '정렬 순서'
comment on column TB_COM_MENU_FUNC.USE_YN is '사용 여부'
comment on column TB_COM_MENU_FUNC.DISPLAY_YN is '표시 여부'
comment on column TB_COM_MENU_FUNC.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_MENU_FUNC.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_MENU_FUNC.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_MENU_FUNC.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_MENU_FUNC.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_MENU_FUNC.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_MENU_FUNC.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_MENU_FUNC.LAST_UPDATE_DATE is '최종 수정 일시'

create table TB_COM_ROLE
(
    ROLE_CD                 VARCHAR2(40)  not null
        constraint TB_COM_ROLE_PK
        primary key,
    ROLE_NM                 VARCHAR2(40)  not null,
    INTERNAL_IP_YN          VARCHAR2(1),
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null
)
    comment on table TB_COM_ROLE is '공통 권한'
comment on column TB_COM_ROLE.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE.ROLE_NM is '권한 명'
comment on column TB_COM_ROLE.INTERNAL_IP_YN is '내부 IP 여부'
comment on column TB_COM_ROLE.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_ROLE.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_ROLE.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_ROLE.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_ROLE.LAST_UPDATE_DATE is '최종 수정 일시'

create table TB_COM_ROLE_MENU
(
    ROLE_CD                 VARCHAR2(40)  not null
        constraint COM_ROLE_COM_ROLE_MENU_FK
        references TB_COM_ROLE,
    MENU_NO                 NUMBER(10)    not null
        constraint COM_MENU_COM_ROLE_MENU_FK
        references TB_COM_MENU,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_ROLE_MENU_PK
        primary key (ROLE_CD, MENU_NO)
)
    comment on table TB_COM_ROLE_MENU is '공통 권한 메뉴'
comment on column TB_COM_ROLE_MENU.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE_MENU.MENU_NO is '메뉴 번호'
comment on column TB_COM_ROLE_MENU.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE_MENU.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE_MENU.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE_MENU.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_ROLE_MENU_FUNC
(
    ROLE_CD                 VARCHAR2(40)  not null,
    MENU_NO                 NUMBER(10)    not null,
    FUNC_NO                 NUMBER(10)    not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_ROLE_MENU_FUNC_PK
        primary key (ROLE_CD, MENU_NO, FUNC_NO),
    constraint COM_MENU_FUNC_COM_ROLE_MENU_FU
        foreign key (MENU_NO, FUNC_NO) references TB_COM_MENU_FUNC,
    constraint COM_ROLE_MENU_COM_ROLE_MENU_FU
        foreign key (ROLE_CD, MENU_NO) references TB_COM_ROLE_MENU
)
    comment on table TB_COM_ROLE_MENU_FUNC is '공통 권한 메뉴 기능'
comment on column TB_COM_ROLE_MENU_FUNC.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE_MENU_FUNC.MENU_NO is '메뉴 번호'
comment on column TB_COM_ROLE_MENU_FUNC.FUNC_NO is '기능 번호'
comment on column TB_COM_ROLE_MENU_FUNC.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE_MENU_FUNC.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE_MENU_FUNC.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE_MENU_FUNC.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_ROLE_MENU_FUNC_LOG
(
    LOG_DATE                DATE          not null,
    ROW_STATUS_CD           VARCHAR2(6)   not null,
    ROLE_CD                 VARCHAR2(40)  not null,
    MENU_NO                 NUMBER(10)    not null,
    FUNC_NO                 NUMBER(10)    not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_ROLE_MENU_FUNC_LOG_PK
        primary key (LOG_DATE, ROW_STATUS_CD, ROLE_CD, MENU_NO, FUNC_NO)
)
    comment on table TB_COM_ROLE_MENU_FUNC_LOG is '공통 권한 메뉴 기능 로그'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.LOG_DATE is '로그 일시'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.ROW_STATUS_CD is 'ROW 상태 코드'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.MENU_NO is '메뉴 번호'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.FUNC_NO is '기능 번호'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE_MENU_FUNC_LOG.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_ROLE_MENU_LOG
(
    LOG_DATE                DATE          not null,
    ROW_STATUS_CD           VARCHAR2(6)   not null,
    ROLE_CD                 VARCHAR2(40)  not null,
    MENU_NO                 NUMBER(10)    not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_ROLE_MENU_LOG_PK
        primary key (LOG_DATE, ROW_STATUS_CD, ROLE_CD, MENU_NO)
)
    comment on table TB_COM_ROLE_MENU_LOG is '공통 권한 메뉴 로그'
comment on column TB_COM_ROLE_MENU_LOG.LOG_DATE is '로그 일시'
comment on column TB_COM_ROLE_MENU_LOG.ROW_STATUS_CD is 'ROW 상태 코드'
comment on column TB_COM_ROLE_MENU_LOG.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE_MENU_LOG.MENU_NO is '메뉴 번호'
comment on column TB_COM_ROLE_MENU_LOG.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE_MENU_LOG.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE_MENU_LOG.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE_MENU_LOG.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_ROLE_USER
(
    ROLE_CD                 VARCHAR2(40)  not null
        constraint COM_ROLE_COM_ROLE_USER_FK
        references TB_COM_ROLE,
    USER_ID                 VARCHAR2(100) not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_ROLE_USER_PK
        primary key (ROLE_CD, USER_ID)
)
    comment on table TB_COM_ROLE_USER is '공통 권한 사용자'
comment on column TB_COM_ROLE_USER.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE_USER.USER_ID is '사용자 ID'
comment on column TB_COM_ROLE_USER.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE_USER.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE_USER.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE_USER.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_ROLE_USER_LOG
(
    LOG_DATE                DATE          not null,
    ROW_STATUS_CD           VARCHAR2(6)   not null,
    ROLE_CD                 VARCHAR2(40)  not null,
    USER_ID                 VARCHAR2(100) not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_ROLE_USER_LOG_PK
        primary key (LOG_DATE, ROW_STATUS_CD, ROLE_CD, USER_ID)
)
    comment on table TB_COM_ROLE_USER_LOG is '공통 권한 사용자 로그'
comment on column TB_COM_ROLE_USER_LOG.LOG_DATE is '로그 일시'
comment on column TB_COM_ROLE_USER_LOG.ROW_STATUS_CD is 'ROW 상태 코드'
comment on column TB_COM_ROLE_USER_LOG.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE_USER_LOG.USER_ID is '사용자 ID'
comment on column TB_COM_ROLE_USER_LOG.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE_USER_LOG.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE_USER_LOG.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE_USER_LOG.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_FILE_LOG
(
    LOG_DATE                DATE          not null,
    ROW_STATUS_CD           VARCHAR2(6)   not null,
    FILE_NO                 NUMBER(10)    not null,
    FILE_GROUP_NO           NUMBER(10)    not null,
    FILE_NM                 VARCHAR2(300) not null,
    FILE_EXTENSION_NM       VARCHAR2(20)  not null,
    SERVER_FILE_SAVE_PATH   VARCHAR2(500) not null,
    SERVER_FILE_SAVE_NM     VARCHAR2(300) not null,
    FILE_SIZE               NUMBER(10)    not null,
    FILE_SIZE_NM            VARCHAR2(100) not null,
    MIME_TYPE_NM            VARCHAR2(100) not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_FILE_LOG_PK
        primary key (LOG_DATE, ROW_STATUS_CD, FILE_NO)
)
    comment on table TB_COM_FILE_LOG is '공통 파일 로그'
comment on column TB_COM_FILE_LOG.LOG_DATE is '로그 일시'
comment on column TB_COM_FILE_LOG.ROW_STATUS_CD is 'ROW 상태 코드'
comment on column TB_COM_FILE_LOG.FILE_NO is '파일 번호'
comment on column TB_COM_FILE_LOG.FILE_GROUP_NO is '파일 그룹 번호'
comment on column TB_COM_FILE_LOG.FILE_NM is '파일 명'
comment on column TB_COM_FILE_LOG.FILE_EXTENSION_NM is '파일 확장자 명'
comment on column TB_COM_FILE_LOG.SERVER_FILE_SAVE_PATH is '서버 파일 저장 경로'
comment on column TB_COM_FILE_LOG.SERVER_FILE_SAVE_NM is '서버 파일 저장 명'
comment on column TB_COM_FILE_LOG.FILE_SIZE is '파일 크기'
comment on column TB_COM_FILE_LOG.FILE_SIZE_NM is '파일 크기 명'
comment on column TB_COM_FILE_LOG.MIME_TYPE_NM is 'MIME TYPE 명'
comment on column TB_COM_FILE_LOG.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_FILE_LOG.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_FILE_LOG.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_FILE_LOG.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_LOGIN_LOG
(
    LOGIN_LOG_NO        NUMBER        not null
        constraint TB_COM_LOGIN_LOG_PK
            primary key,
    LOGIN_DT            VARCHAR2(8)   not null,
    LOGIN_TMS           VARCHAR2(6)   not null,
    LOGIN_ID            VARCHAR2(100) not null,
    LOGIN_IP            VARCHAR2(100) not null,
    LOGIN_YN            VARCHAR2(1)   not null,
    LOGIN_RSLT_CONTENTS VARCHAR2(4000),
    LOGIN_HEADER_INFO   VARCHAR2(4000)
)
    comment on table TB_COM_LOGIN_LOG is '공통 로그인 로그'
comment on column TB_COM_LOGIN_LOG.LOGIN_LOG_NO is '로그인 로그 번호'
comment on column TB_COM_LOGIN_LOG.LOGIN_DT is '로그인 일자'
comment on column TB_COM_LOGIN_LOG.LOGIN_TMS is '로그인 시분초'
comment on column TB_COM_LOGIN_LOG.LOGIN_ID is '로그인 ID'
comment on column TB_COM_LOGIN_LOG.LOGIN_IP is '로그인 IP'
comment on column TB_COM_LOGIN_LOG.LOGIN_YN is '로그인 여부'
comment on column TB_COM_LOGIN_LOG.LOGIN_RSLT_CONTENTS is '로그인 결과 내용'
comment on column TB_COM_LOGIN_LOG.LOGIN_HEADER_INFO is '로그인 HEADER 정보'

create table TB_COM_EMAIL_CERT
(
    EMAIL_ADDRESS           VARCHAR2(100) not null,
    EMAIL_CERT_CD           VARCHAR2(10)  not null,
    CERT_VALID_DATE         DATE          not null,
    CERT_YN                 VARCHAR2(1)   not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    constraint TB_COM_EMAIL_CERT_PK
        primary key (EMAIL_ADDRESS)
)
    comment on table TB_COM_EMAIL_CERT is '공통 이메일 인증'
comment on column TB_COM_EMAIL_CERT.EMAIL_ADDRESS is '이메일 주소'
comment on column TB_COM_EMAIL_CERT.EMAIL_CERT_CD is '이메일 인증 코드'
comment on column TB_COM_EMAIL_CERT.CERT_VALID_DATE is '인증 유효 일시'
comment on column TB_COM_EMAIL_CERT.CERT_YN is '인증 여부'
comment on column TB_COM_EMAIL_CERT.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_EMAIL_CERT.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_EMAIL_CERT.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_EMAIL_CERT.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_EMAIL_CERT.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_EMAIL_CERT.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_EMAIL_CERT.LAST_UPDATE_DATE is '최종 수정 일시'
comment on column TB_COM_EMAIL_CERT.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'

create table TB_COM_TRANSFER_ALIM_TALK
(
    ALIM_TALK_TRANSFER_NO        NUMBER         not null
        constraint TB_COM_TRANSFER_ALIM_TALK_PK
            primary key,
    TEMPLATE_CD                  VARCHAR2(5)    not null,
    RECEIVE_TEL_NATION_CD        VARCHAR2(3)    not null,
    RECEIVE_TEL_NO               VARCHAR2(20)   not null,
    ALIM_TALK_HIGHLIGHT_CONTENTS VARCHAR2(100),
    MSG_CONTENTS                 VARCHAR2(1000) not null,
    FAILOVER_YN                  VARCHAR2(1)    not null,
    FAILOVER_CONTENTS            VARCHAR2(4000),
    SEND_RESERVE_TIMEZONE        VARCHAR2(30),
    SEND_RESERVE_DATE            DATE,
    SEND_YN                      VARCHAR2(1)    not null,
    SEND_DATE                    DATE,
    SEND_REQUEST_ID              VARCHAR2(100),
    SEND_REQUEST_DATE            DATE,
    SEND_MSG_ID                  VARCHAR2(100),
    FIRST_REGIST_USER_ID         VARCHAR2(100)  not null,
    FIRST_REGIST_USER_IP         VARCHAR2(100)  not null,
    FIRST_REGIST_PROGRAM_ID      VARCHAR2(100)  not null,
    FIRST_REGIST_DATE            DATE           not null
)
    comment on table TB_COM_TRANSFER_ALIM_TALK is '공통 전송 ALIM TALK'
comment on column TB_COM_TRANSFER_ALIM_TALK.ALIM_TALK_TRANSFER_NO is 'ALIM TALK 전송 번호'
comment on column TB_COM_TRANSFER_ALIM_TALK.TEMPLATE_CD is '템플릿 코드'
comment on column TB_COM_TRANSFER_ALIM_TALK.RECEIVE_TEL_NATION_CD is '수신 전화 국가 코드'
comment on column TB_COM_TRANSFER_ALIM_TALK.RECEIVE_TEL_NO is '수신 전화 번호'
comment on column TB_COM_TRANSFER_ALIM_TALK.ALIM_TALK_HIGHLIGHT_CONTENTS is 'ALIM TALK HIGHLIGHT 내용'
comment on column TB_COM_TRANSFER_ALIM_TALK.MSG_CONTENTS is '메세지 내용'
comment on column TB_COM_TRANSFER_ALIM_TALK.FAILOVER_YN is 'FAILOVER 여부'
comment on column TB_COM_TRANSFER_ALIM_TALK.FAILOVER_CONTENTS is 'FAILOVER 내용'
comment on column TB_COM_TRANSFER_ALIM_TALK.SEND_RESERVE_TIMEZONE is '발신 예약 TIMEZONE'
comment on column TB_COM_TRANSFER_ALIM_TALK.SEND_RESERVE_DATE is '발신 예약 일시'
comment on column TB_COM_TRANSFER_ALIM_TALK.SEND_YN is '발신 여부'
comment on column TB_COM_TRANSFER_ALIM_TALK.SEND_DATE is '발신 일시'
comment on column TB_COM_TRANSFER_ALIM_TALK.SEND_REQUEST_ID is '발신 요청 ID'
comment on column TB_COM_TRANSFER_ALIM_TALK.SEND_REQUEST_DATE is '발신 요청 일시'
comment on column TB_COM_TRANSFER_ALIM_TALK.SEND_MSG_ID is '발신 메시지 ID'
comment on column TB_COM_TRANSFER_ALIM_TALK.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_TRANSFER_ALIM_TALK.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_TRANSFER_ALIM_TALK.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_TRANSFER_ALIM_TALK.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_TRANSFER_EMAIL
(
    EMAIL_TRANSFER_NO       NUMBER        not null
        constraint TB_COM_TRANSFER_EMAIL_PK
            primary key,
    SENDER_EMAIL_ADDRESS    VARCHAR2(100) not null,
    SENDER_NM               VARCHAR2(100) not null,
    EMAIL_TITLE             VARCHAR2(300) not null,
    EMAIL_CONTENTS          CLOB          not null,
    MULTIMAIL_YN            VARCHAR2(1)   not null,
    RECEIVER_CNT            NUMBER(10)    not null,
    SEND_RESERVE_DATE       DATE,
    SEND_YN                 VARCHAR2(1)   not null,
    SEND_DATE               DATE,
    SEND_REQUEST_ID         VARCHAR2(100),
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null
)
    comment on table TB_COM_TRANSFER_EMAIL is '공통 전송 이메일'
comment on column TB_COM_TRANSFER_EMAIL.EMAIL_TRANSFER_NO is '이메일 전송 번호'
comment on column TB_COM_TRANSFER_EMAIL.SENDER_EMAIL_ADDRESS is '발신자 이메일 주소'
comment on column TB_COM_TRANSFER_EMAIL.SENDER_NM is '발신자 명'
comment on column TB_COM_TRANSFER_EMAIL.EMAIL_TITLE is '이메일 제목'
comment on column TB_COM_TRANSFER_EMAIL.EMAIL_CONTENTS is '이메일 내용'
comment on column TB_COM_TRANSFER_EMAIL.MULTIMAIL_YN is '단체메일 여부'
comment on column TB_COM_TRANSFER_EMAIL.RECEIVER_CNT is '수신자 수'
comment on column TB_COM_TRANSFER_EMAIL.SEND_RESERVE_DATE is '발신 예약 일시'
comment on column TB_COM_TRANSFER_EMAIL.SEND_YN is '발신 여부'
comment on column TB_COM_TRANSFER_EMAIL.SEND_DATE is '발신 일시'
comment on column TB_COM_TRANSFER_EMAIL.SEND_REQUEST_ID is '발신 요청 ID'
comment on column TB_COM_TRANSFER_EMAIL.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_TRANSFER_EMAIL.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_TRANSFER_EMAIL.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_TRANSFER_EMAIL.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_TRANSFER_EMAIL_RECEIVER
(
    EMAIL_TRANSFER_NO       NUMBER        not null
        constraint COM_TRANSFER_EMAIL_COM_TRANSFE
            references TB_COM_TRANSFER_EMAIL,
    RECEIVER_NO             VARCHAR2(20)  not null,
    RECEIVER_EMAIL_ADDRESS  VARCHAR2(100) not null,
    RECEIVER_NM             VARCHAR2(100) not null,
    RECEIVE_TYPE_CD         VARCHAR2(2)   not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_TRANSFER_EMAIL_RECEIVER
        primary key (EMAIL_TRANSFER_NO, RECEIVER_NO)
)
    comment on table TB_COM_TRANSFER_EMAIL_RECEIVER is '공통 전송 이메일 수신자'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.EMAIL_TRANSFER_NO is '이메일 전송 번호'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.RECEIVER_NO is '수신자 번호'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.RECEIVER_EMAIL_ADDRESS is '수신자 이메일 주소'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.RECEIVER_NM is '수신자 명'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.RECEIVE_TYPE_CD is '수신 유형 코드'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_TRANSFER_EMAIL_RECEIVER.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_TRANSFER_SMS
(
    SMS_TRANSFER_NO         NUMBER         not null
        constraint TB_COM_TRANSFER_SMS_PK
            primary key,
    SMS_DIV_CD              VARCHAR2(10)   not null,
    RECEIVE_TEL_NATION_CD   VARCHAR2(3)    not null,
    RECEIVE_TEL_NO          VARCHAR2(20)   not null,
    SEND_TEL_NO             VARCHAR2(20)   not null,
    MSG_CONTENTS            VARCHAR2(1000) not null,
    SEND_RESERVE_TIMEZONE   VARCHAR2(30),
    SEND_RESERVE_DATE       DATE,
    SEND_YN                 VARCHAR2(1)    not null,
    SEND_DATE               DATE,
    SEND_REQUEST_ID         VARCHAR2(100),
    SEND_REQUEST_DATE       DATE,
    FIRST_REGIST_USER_IP    VARCHAR2(100)  not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100)  not null,
    FIRST_REGIST_DATE       DATE           not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100)  not null
)
    comment on table TB_COM_TRANSFER_SMS is '공통 전송 SMS'
comment on column TB_COM_TRANSFER_SMS.SMS_TRANSFER_NO is 'SMS 전송 번호'
comment on column TB_COM_TRANSFER_SMS.SMS_DIV_CD is 'SMS 구분 코드'
comment on column TB_COM_TRANSFER_SMS.RECEIVE_TEL_NATION_CD is '수신 전화 국가 코드'
comment on column TB_COM_TRANSFER_SMS.RECEIVE_TEL_NO is '수신 전화 번호'
comment on column TB_COM_TRANSFER_SMS.SEND_TEL_NO is '발신 전화 번호'
comment on column TB_COM_TRANSFER_SMS.MSG_CONTENTS is '메세지 내용'
comment on column TB_COM_TRANSFER_SMS.SEND_RESERVE_TIMEZONE is '발신 예약 TIMEZONE'
comment on column TB_COM_TRANSFER_SMS.SEND_RESERVE_DATE is '발신 예약 일시'
comment on column TB_COM_TRANSFER_SMS.SEND_YN is '발신 여부'
comment on column TB_COM_TRANSFER_SMS.SEND_DATE is '발신 일시'
comment on column TB_COM_TRANSFER_SMS.SEND_REQUEST_ID is '발신 요청 ID'
comment on column TB_COM_TRANSFER_SMS.SEND_REQUEST_DATE is '발신 요청 일시'
comment on column TB_COM_TRANSFER_SMS.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_TRANSFER_SMS.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_TRANSFER_SMS.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_TRANSFER_SMS.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'

create table TB_COM_SMS_CERT
(
    MOBILE_NO               VARCHAR2(100) not null,
    MOBILE_CERT_NO          NUMBER(10)    not null,
    USER_ID                 VARCHAR2(100) not null,
    MOBILE_CERT_CD          VARCHAR2(10)  not null,
    CERT_VALID_DATE         DATE          not null,
    CERT_YN                 VARCHAR2(1)   not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    constraint TB_COM_SMS_CERT_PK
        primary key (MOBILE_NO, MOBILE_CERT_NO)
)
    comment on table TB_COM_SMS_CERT is '공통 SMS 인증'
comment on column TB_COM_SMS_CERT.MOBILE_NO is '휴대 전화 번호'
comment on column TB_COM_SMS_CERT.MOBILE_CERT_NO is '휴대 전화 인증 번호'
comment on column TB_COM_SMS_CERT.USER_ID is '사용자 ID'
comment on column TB_COM_SMS_CERT.MOBILE_CERT_CD is '휴대 전화 인증 코드'
comment on column TB_COM_SMS_CERT.CERT_VALID_DATE is '인증 유효 일시'
comment on column TB_COM_SMS_CERT.CERT_YN is '인증 여부'
comment on column TB_COM_SMS_CERT.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_SMS_CERT.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_SMS_CERT.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_SMS_CERT.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_SMS_CERT.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_SMS_CERT.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_SMS_CERT.LAST_UPDATE_DATE is '최종 수정 일시'
comment on column TB_COM_SMS_CERT.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'

create table TB_COM_ROLE_USER_EMP_LOG
(
    LOG_DATE                DATE          not null,
    ROW_STATUS_CD           VARCHAR2(6)   not null,
    ROLE_CD                 VARCHAR2(40)  not null,
    EMP_NO                  VARCHAR2(100) not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_ROLE_USER_EMP_LOG_PK
        primary key (LOG_DATE, ROW_STATUS_CD, ROLE_CD, EMP_NO)
)
    comment on table TB_COM_ROLE_USER_EMP_LOG is '공통 권한 사용자 EMP 로그'
comment on column TB_COM_ROLE_USER_EMP_LOG.LOG_DATE is '로그 일시'
comment on column TB_COM_ROLE_USER_EMP_LOG.ROW_STATUS_CD is 'ROW 상태 코드'
comment on column TB_COM_ROLE_USER_EMP_LOG.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE_USER_EMP_LOG.EMP_NO is 'EMP 번호'
comment on column TB_COM_ROLE_USER_EMP_LOG.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE_USER_EMP_LOG.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE_USER_EMP_LOG.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE_USER_EMP_LOG.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_ROLE_USER_EMP
(
    ROLE_CD                 VARCHAR2(40)  not null
        constraint COM_ROLE_COM_ROLE_USER_EMP_FK
        references TB_COM_ROLE,
    EMP_NO                  VARCHAR2(20)  not null,
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    constraint TB_COM_ROLE_USER_EMP_PK
        primary key (ROLE_CD, EMP_NO)
)
    comment on table TB_COM_ROLE_USER_EMP is '공통 권한 사용자 EMP'
comment on column TB_COM_ROLE_USER_EMP.ROLE_CD is '권한 코드'
comment on column TB_COM_ROLE_USER_EMP.EMP_NO is 'EMP 번호'
comment on column TB_COM_ROLE_USER_EMP.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_ROLE_USER_EMP.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_ROLE_USER_EMP.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_ROLE_USER_EMP.FIRST_REGIST_DATE is '최초 등록 일시'

create table TB_COM_USER
(
    USER_ID                 VARCHAR2(100) not null
        constraint TB_COM_USER_PK
        primary key,
    USER_NM                 VARCHAR2(40),
    ENG_FIRST_NM            VARCHAR2(30),
    ENG_MIDDLE_NM           VARCHAR2(30),
    ENG_FAMILY_NM           VARCHAR2(30),
    USER_PASSWORD           VARCHAR2(500) not null,
    COUNTRY_CD              VARCHAR2(3),
    MOBILE_NO               VARCHAR2(20),
    EMAIL_ADDRESS           VARCHAR2(100) not null,
    BIRTH_DT                VARCHAR2(8),
    INDIVIDUALINFO_AGREE_YN VARCHAR2(1)   not null,
    MARKETING_AGREE_YN      VARCHAR2(1)   not null,
    NAVER_CONNECT           VARCHAR2(100),
    KAKAO_CONNECT           VARCHAR2(100),
    GOOGLE_CONNECT          VARCHAR2(100),
    FIRST_REGIST_USER_ID    VARCHAR2(100) not null,
    FIRST_REGIST_USER_IP    VARCHAR2(100) not null,
    FIRST_REGIST_PROGRAM_ID VARCHAR2(100) not null,
    FIRST_REGIST_DATE       DATE          not null,
    LAST_UPDATE_USER_ID     VARCHAR2(100) not null,
    LAST_UPDATE_USER_IP     VARCHAR2(100) not null,
    LAST_UPDATE_PROGRAM_ID  VARCHAR2(100) not null,
    LAST_UPDATE_DATE        DATE          not null
)
    comment on table TB_COM_USER is '공통 사용자'
comment on column TB_COM_USER.USER_ID is '사용자 ID'
comment on column TB_COM_USER.USER_NM is '사용자 명'
comment on column TB_COM_USER.ENG_FIRST_NM is '영문 FIRST 명'
comment on column TB_COM_USER.ENG_MIDDLE_NM is '영문 MIDDLE 명'
comment on column TB_COM_USER.ENG_FAMILY_NM is '영문 FAMILY 명'
comment on column TB_COM_USER.USER_PASSWORD is '사용자 비밀번호'
comment on column TB_COM_USER.COUNTRY_CD is '국적 코드'
comment on column TB_COM_USER.MOBILE_NO is '휴대 전화 번호'
comment on column TB_COM_USER.EMAIL_ADDRESS is '이메일 주소'
comment on column TB_COM_USER.BIRTH_DT is '생일 일자'
comment on column TB_COM_USER.INDIVIDUALINFO_AGREE_YN is '개인정보 동의 여부'
comment on column TB_COM_USER.MARKETING_AGREE_YN is '마케팅 동의 여부'
comment on column TB_COM_USER.NAVER_CONNECT is '네이버 연동'
comment on column TB_COM_USER.KAKAO_CONNECT is '카카오 연동'
comment on column TB_COM_USER.GOOGLE_CONNECT is '구글 연동'
comment on column TB_COM_USER.FIRST_REGIST_USER_ID is '최초 등록 사용자 ID'
comment on column TB_COM_USER.FIRST_REGIST_USER_IP is '최초 등록 사용자 IP'
comment on column TB_COM_USER.FIRST_REGIST_PROGRAM_ID is '최초 등록 프로그램 ID'
comment on column TB_COM_USER.FIRST_REGIST_DATE is '최초 등록 일시'
comment on column TB_COM_USER.LAST_UPDATE_USER_ID is '최종 수정 사용자 ID'
comment on column TB_COM_USER.LAST_UPDATE_USER_IP is '최종 수정 사용자 IP'
comment on column TB_COM_USER.LAST_UPDATE_PROGRAM_ID is '최종 수정 프로그램 ID'
comment on column TB_COM_USER.LAST_UPDATE_DATE is '최종 수정 일시'

